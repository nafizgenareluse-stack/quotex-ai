import express, { Request, Response } from 'express';
import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import liveRouter from './server-live/router.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Maximum payload size for high-resolution mobile screenshots
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ limit: '25mb', extended: true }));

// Express JSON body-parser error handler to prevent HTML error responses
app.use((err: any, req: Request, res: Response, next: express.NextFunction) => {
  if (err && (err.type === 'entity.too.large' || err.status === 413)) {
    res.status(413).json({
      error: 'আপলোড করা ছবির ফাইল অত্যন্ত বড়। অনুগ্রহ করে ছোট চার্ট স্ক্রিনশট নির্বাচন করুন।',
    });
    return;
  }
  if (err instanceof SyntaxError && 'body' in err) {
    res.status(400).json({
      error: 'অনুরোধের JSON পে-লোড সঠিক নয়।',
    });
    return;
  }
  next(err);
});

// Initialize GoogleGenAI SDK with server-side API Key
function getGenAI(): { ai: GoogleGenAI | null; apiKey: string } {
  const effectiveKey = process.env.GEMINI_API_KEY || '';
  if (!effectiveKey) return { ai: null, apiKey: '' };
  return {
    ai: new GoogleGenAI({
      apiKey: effectiveKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    }),
    apiKey: effectiveKey,
  };
}

const initialClient = getGenAI();
const apiKey = initialClient.apiKey;
const ai = initialClient.ai;

const SUPPORTED_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const CANDIDATE_MODELS = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
const MAX_IMAGE_BYTES = 20 * 1024 * 1024; // 20MB
const REQUEST_TIMEOUT_MS = 25000; // 25-second server-side timeout to safely fit within 30s target

/**
 * Health check endpoint
 */
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(apiKey),
    models: CANDIDATE_MODELS,
    timestamp: Date.now(),
  });
});

/**
 * Helper to validate and clean base64 image
 */
function validateAndCleanBase64(
  imageBase64: string,
  rawMimeType: string,
  label: string
): { cleanBase64: string; effectiveMime: string } {
  const normalizedMime = rawMimeType.toLowerCase().trim();
  const effectiveMime = normalizedMime === 'image/jpg' ? 'image/jpeg' : normalizedMime;
  if (!SUPPORTED_MIME_TYPES.has(effectiveMime)) {
    throw new Error(`অসমর্থিত ${label} ফরম্যাট (${rawMimeType})। শুধুমাত্র JPEG, PNG, এবং WebP ফরম্যাট সমর্থিত।`);
  }
  const cleanBase64 = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const approximateByteSize = Math.round((cleanBase64.length * 3) / 4);
  if (approximateByteSize > MAX_IMAGE_BYTES) {
    throw new Error(`${label} ফাইলের আকার (${(approximateByteSize / (1024 * 1024)).toFixed(1)} MB) ১৫ মেগাবাইট সীমা অতিক্রম করেছে।`);
  }
  return { cleanBase64, effectiveMime };
}

/**
 * Chart analysis handler with Multi-Timeframe, Confluence, Risk Filters, and Self-Review
 */
const handleAnalyzeChart = async (req: Request, res: Response): Promise<void> => {
  const startTime = Date.now();

  try {
    const {
      imageBase64,
      mimeType = 'image/png',
      higherTfImageBase64,
      higherTfMimeType = 'image/png',
    } = req.body;

    // 1. Validate primary image (Entry chart)
    if (!imageBase64 || typeof imageBase64 !== 'string') {
      res.status(400).json({
        error: 'কোনো এন্ট্রি চার্ট ছবি পাওয়া যায়নি। অনুগ্রহ করে একটি চার্ট স্ক্রিনশট নির্বাচন করুন।',
      });
      return;
    }

    const { cleanBase64, effectiveMime } = validateAndCleanBase64(
      imageBase64,
      mimeType,
      'এন্ট্রি চার্ট'
    );

    // 2. Validate optional higher timeframe image
    let cleanHigherTfBase64: string | null = null;
    let effectiveHigherTfMime: string = 'image/png';
    if (higherTfImageBase64 && typeof higherTfImageBase64 === 'string') {
      const htfParsed = validateAndCleanBase64(
        higherTfImageBase64,
        higherTfMimeType,
        'বড় টাইমফ্রেম চার্ট'
      );
      cleanHigherTfBase64 = htfParsed.cleanBase64;
      effectiveHigherTfMime = htfParsed.effectiveMime;
    }

    // 3. Verify API Key availability
    const { ai: currentAi, apiKey: currentApiKey } = getGenAI();
    if (!currentAi || !currentApiKey) {
      res.status(503).json({
        error: 'সার্ভার এনভায়রনমেন্টে জেমিনি এপিআই কি (GEMINI_API_KEY) কনফিগার করা নেই। অনুগ্রহ করে সেটিংসে API Key যুক্ত করুন।',
      });
      return;
    }

    const hasHigherTf = Boolean(cleanHigherTfBase64);

    const systemInstruction = `You are a cautious, disciplined financial candlestick chart vision analyst and technical risk assessor.
When given screenshot(s) of financial candlestick charts (Quotex or similar trading platforms), analyze the visible price action and estimate whether the NEXT candle after the latest visible candle on the entry chart is more likely to be UP, DOWN, or NO TRADE.

ABSOLUTE REQUIREMENTS & CONFLUENCE VOTING RULES:
1. Examine ONLY what is visibly supported by the uploaded screenshot(s). Never invent prices, asset names, timeframe tags, candle values, or indicators (e.g. RSI, MACD, Volume) that cannot be clearly read.
2. Distinguish clearly between:
   - The current candle forming (if incomplete).
   - The latest completed visible candle.
   - The next candle that has not yet formed (the target of this estimate).
${hasHigherTf ? `3. MULTI-TIMEFRAME ANALYSIS:
   - Image 1 = Entry Chart (smaller timeframe).
   - Image 2 = Higher Timeframe Chart.
   Evaluate the major trend and key S/R levels on the Higher Timeframe Chart and vote "UP", "DOWN", or "NEUTRAL" in htf_vote. Use the Entry Chart for precise timing and immediate price action.` : ''}
4. CONFLUENCE VOTING FACTORS (Each votes "UP", "DOWN", or "NEUTRAL"):
   - Trend (trend_vote): Higher highs/lows for UP, lower highs/lows for DOWN, sideways/unclear for NEUTRAL.
   - Pattern & Wick Rejection (pattern_vote): Bullish engulfing, strong lower wick rejection for UP; bearish engulfing, strong upper wick rejection for DOWN; indecisive for NEUTRAL.
   - Support/Resistance & Price Action (sr_vote): Bounce from confirmed support/breakout for UP; rejection from confirmed resistance for DOWN; mid-range for NEUTRAL.
   ${hasHigherTf ? '- Higher Timeframe (htf_vote): Overall higher TF trend bias ("UP", "DOWN", or "NEUTRAL").' : ''}
   - Indicators (indicator_vote): Only if at least one indicator is legibly visible (RSI, MACD, Moving Average, Bollinger Bands). If none visible, leave indicators_visible as empty array and indicator_vote as "NEUTRAL".
5. LEVEL QUALITY & MOMENTUM OBSERVATIONS (Do not invent):
   - level_touch_count: How many times current S/R was tested ("1", "2", "3+", or "UNKNOWN").
   - level_strength: "STRONG", "MODERATE", "WEAK", or "UNKNOWN".
   - momentum: "INCREASING", "DECREASING", "FLAT", or "UNKNOWN" based on candle body progression. Shrinking bodies indicate exhaustion.
   - breakout_type: "REAL", "FAKE_SUSPECTED", or "NONE". If FAKE_SUSPECTED, note it in summary or conflicting_evidence.
6. RISK & MARKET ENVIRONMENT:
   - market_condition: "TRENDING", "RANGING", or "CHOPPY".
   - near_key_level: "RESISTANCE", "SUPPORT", or "NONE" (is current price directly at an immediate key barrier?).
7. LANGUAGE REQUIREMENT:
   সব বর্ণনামূলক টেক্সট (summary, observations, supporting_evidence, conflicting_evidence, limitations, confidence_note, votes_reasoning, indicators_visible) সহজ বাংলায় লিখবে; JSON-এর enum মান (UP, DOWN, NO TRADE, UPTREND, DOWNTREND, SIDEWAYS, UNCLEAR, GOOD, LIMITED, POOR, LOW, MODERATE, HIGH, TRENDING, RANGING, CHOPPY, RESISTANCE, SUPPORT, NONE, STRONG, MODERATE, WEAK, INCREASING, DECREASING, FLAT, REAL, FAKE_SUSPECTED, ভোটের জন্য UP, DOWN, NEUTRAL) ইংরেজিতেই রাখবে।
8. Return strictly valid JSON adhering to the specified schema.`;

    const promptText = `Analyze this candlestick chart screenshot${hasHigherTf ? 's (Entry Chart and Higher Timeframe Chart)' : ''}.
Evaluate:
1. Chart legibility, image quality, and visible timeframe/asset.
2. Trend vote (trend_vote: UP, DOWN, or NEUTRAL).
3. Candlestick pattern / wick rejection vote (pattern_vote: UP, DOWN, or NEUTRAL).
4. Support & Resistance / price action vote (sr_vote: UP, DOWN, or NEUTRAL).
${hasHigherTf ? '5. Higher timeframe vote (htf_vote: UP, DOWN, or NEUTRAL).' : ''}
6. Clearly visible indicators (RSI, MACD, MA, etc.) if any, and indicator_vote (UP, DOWN, or NEUTRAL).
7. Level touch count, level strength, candle momentum (increasing/decreasing/flat), and breakout status.
8. Market condition (TRENDING, RANGING, CHOPPY) and proximity to immediate key level (RESISTANCE, SUPPORT, NONE).
9. Concise votes_reasoning in Bengali (1 line per factor).
10. Final next-candle estimate (UP, DOWN, or NO TRADE) and summary in clear Bengali.`;

    // Prepare contents array for Gemini
    const contentParts: any[] = [];
    if (cleanHigherTfBase64) {
      contentParts.push(
        { text: '【ছবি ১: এন্ট্রি চার্ট (ছোট টাইমফ্রেম)】' },
        {
          inlineData: {
            mimeType: effectiveMime,
            data: cleanBase64,
          },
        },
        { text: '【ছবি ২: বড় টাইমফ্রেম চার্ট (ঐচ্ছিক)】' },
        {
          inlineData: {
            mimeType: effectiveHigherTfMime,
            data: cleanHigherTfBase64,
          },
        }
      );
    } else {
      contentParts.push({
        inlineData: {
          mimeType: effectiveMime,
          data: cleanBase64,
        },
      });
    }
    contentParts.push({ text: promptText });

    // Primary Vision Analysis
    const executeVisionAnalysis = async () => {
      let lastError: any = null;

      for (const modelName of CANDIDATE_MODELS) {
        try {
          const config: any = {
            systemInstruction,
            temperature: 0.15,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                direction: {
                  type: Type.STRING,
                  description: 'Direction estimate for next candle: UP, DOWN, or NO TRADE',
                },
                trend_vote: {
                  type: Type.STRING,
                  description: 'Factor 1 Trend vote: UP, DOWN, or NEUTRAL',
                },
                pattern_vote: {
                  type: Type.STRING,
                  description: 'Factor 2 Pattern / wick rejection vote: UP, DOWN, or NEUTRAL',
                },
                sr_vote: {
                  type: Type.STRING,
                  description: 'Factor 3 Support/Resistance & price action vote: UP, DOWN, or NEUTRAL',
                },
                htf_vote: {
                  type: Type.STRING,
                  description: 'Factor 4 Higher timeframe trend vote: UP, DOWN, or NEUTRAL (if HTF provided)',
                },
                indicator_vote: {
                  type: Type.STRING,
                  description: 'Factor 5 Indicator vote: UP, DOWN, or NEUTRAL (if visible)',
                },
                indicators_visible: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'List of clearly visible indicators and their read states in Bengali',
                },
                votes_reasoning: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: '1-line Bengali reasoning for each factor vote',
                },
                summary: {
                  type: Type.STRING,
                  description: 'Concise explanation of the estimate in Bengali based only on visible evidence',
                },
                trend: {
                  type: Type.STRING,
                  description: 'Visible trend: UPTREND, DOWNTREND, SIDEWAYS, or UNCLEAR',
                },
                observations: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Specific candlestick and structural observations in Bengali visibly present in the screenshot',
                },
                supporting_evidence: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Visible evidence in Bengali that supports the directional estimate',
                },
                conflicting_evidence: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Contradictory evidence, counter-trend risks, or uncertainties in Bengali',
                },
                image_quality: {
                  type: Type.STRING,
                  description: 'Quality of the uploaded screenshot: GOOD, LIMITED, or POOR',
                },
                timeframe: {
                  type: Type.STRING,
                  description: 'Visible chart timeframe (e.g. 1M, 5S, 1H) or UNKNOWN if unreadable',
                },
                confidence_label: {
                  type: Type.STRING,
                  description: 'Uncalibrated alignment label: LOW, MODERATE, or HIGH',
                },
                confidence_note: {
                  type: Type.STRING,
                  description: 'Clear statement in Bengali that this is an uncalibrated visual assessment',
                },
                limitations: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: 'Important limitations in Bengali of this particular static screenshot',
                },
                level_touch_count: {
                  type: Type.STRING,
                  description: 'Touch count of active S/R level (e.g. "1", "2", "3+", or "UNKNOWN")',
                },
                level_strength: {
                  type: Type.STRING,
                  description: 'Strength of current level: STRONG, MODERATE, WEAK, or UNKNOWN',
                },
                momentum: {
                  type: Type.STRING,
                  description: 'Candle momentum over last 5-10 candles: INCREASING, DECREASING, FLAT, or UNKNOWN',
                },
                breakout_type: {
                  type: Type.STRING,
                  description: 'Breakout classification: REAL, FAKE_SUSPECTED, or NONE',
                },
                market_condition: {
                  type: Type.STRING,
                  description: 'Overall market structure: TRENDING, RANGING, or CHOPPY',
                },
                near_key_level: {
                  type: Type.STRING,
                  description: 'Price proximity to key level: RESISTANCE, SUPPORT, or NONE',
                },
              },
              required: [
                'direction',
                'trend_vote',
                'pattern_vote',
                'sr_vote',
                'summary',
                'trend',
                'observations',
                'supporting_evidence',
                'conflicting_evidence',
                'image_quality',
                'timeframe',
                'confidence_label',
                'confidence_note',
                'limitations',
                'level_strength',
                'momentum',
                'breakout_type',
                'market_condition',
                'near_key_level',
              ],
            },
          };

          if (modelName === 'gemini-3.8-flash') {
            config.thinkingConfig = {
              thinkingLevel: ThinkingLevel.LOW,
            };
          }

          const response = await currentAi.models.generateContent({
            model: modelName,
            contents: {
              parts: contentParts,
            },
            config,
          });

          return response;
        } catch (err: any) {
          lastError = err;
          console.warn(`Vision model ${modelName} attempt failed:`, err?.message || err);
        }
      }

      throw lastError || new Error('All vision models are currently unavailable.');
    };

    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => {
        reject(new Error('TIMEOUT_EXCEEDED'));
      }, 26000);
    });

    const response = await Promise.race([executeVisionAnalysis(), timeoutPromise]);

    const textOutput = response.text || '';
    if (!textOutput) {
      throw new Error('Empty response received from vision model.');
    }

    let cleanJsonText = textOutput.trim();
    if (cleanJsonText.startsWith('```')) {
      cleanJsonText = cleanJsonText.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
    }

    const parsedJson = JSON.parse(cleanJsonText);

    // Normalize image quality
    let image_quality: 'GOOD' | 'LIMITED' | 'POOR' = 'LIMITED';
    const rawQual = String(parsedJson.image_quality || '').toUpperCase().trim();
    if (rawQual === 'GOOD') image_quality = 'GOOD';
    else if (rawQual === 'POOR') image_quality = 'POOR';

    // Normalize trend
    let trend: 'UPTREND' | 'DOWNTREND' | 'SIDEWAYS' | 'UNCLEAR' = 'UNCLEAR';
    const rawTrend = String(parsedJson.trend || '').toUpperCase().trim();
    if (rawTrend === 'UPTREND') trend = 'UPTREND';
    else if (rawTrend === 'DOWNTREND') trend = 'DOWNTREND';
    else if (rawTrend === 'SIDEWAYS') trend = 'SIDEWAYS';

    // Normalize confidence label
    let confidence_label: 'LOW' | 'MODERATE' | 'HIGH' = 'LOW';
    const rawConf = String(parsedJson.confidence_label || '').toUpperCase().trim();
    if (rawConf === 'HIGH') confidence_label = 'HIGH';
    else if (rawConf === 'MODERATE') confidence_label = 'MODERATE';

    // Helper to sanitize vote
    const sanitizeVote = (val: any): 'UP' | 'DOWN' | 'NEUTRAL' => {
      const v = String(val || '').toUpperCase().trim();
      if (v === 'UP') return 'UP';
      if (v === 'DOWN') return 'DOWN';
      return 'NEUTRAL';
    };

    const trend_vote = sanitizeVote(parsedJson.trend_vote);
    const pattern_vote = sanitizeVote(parsedJson.pattern_vote);
    const sr_vote = sanitizeVote(parsedJson.sr_vote);

    // Update 1: HTF vote
    let htf_vote: 'UP' | 'DOWN' | 'NEUTRAL' | undefined = undefined;
    if (hasHigherTf && parsedJson.htf_vote) {
      htf_vote = sanitizeVote(parsedJson.htf_vote);
    }

    // Update 3: Indicators
    const indicators_visible: string[] = Array.isArray(parsedJson.indicators_visible)
      ? parsedJson.indicators_visible.map(String).filter((s: string) => s.trim().length > 0)
      : [];


    let indicator_vote: 'UP' | 'DOWN' | 'NEUTRAL' | undefined = undefined;
    if (indicators_visible.length > 0 && parsedJson.indicator_vote) {
      indicator_vote = sanitizeVote(parsedJson.indicator_vote);
    }

    // Update 4: Level quality & momentum
    let level_strength: 'STRONG' | 'MODERATE' | 'WEAK' | 'UNKNOWN' = 'UNKNOWN';
    const rawStrength = String(parsedJson.level_strength || '').toUpperCase().trim();
    if (['STRONG', 'MODERATE', 'WEAK'].includes(rawStrength)) {
      level_strength = rawStrength as any;
    }

    let momentum: 'INCREASING' | 'DECREASING' | 'FLAT' | 'UNKNOWN' = 'UNKNOWN';
    const rawMomentum = String(parsedJson.momentum || '').toUpperCase().trim();
    if (['INCREASING', 'DECREASING', 'FLAT'].includes(rawMomentum)) {
      momentum = rawMomentum as any;
    }

    let breakout_type: 'REAL' | 'FAKE_SUSPECTED' | 'NONE' = 'NONE';
    const rawBreakout = String(parsedJson.breakout_type || '').toUpperCase().trim();
    if (['REAL', 'FAKE_SUSPECTED'].includes(rawBreakout)) {
      breakout_type = rawBreakout as any;
    }

    const level_touch_count = String(parsedJson.level_touch_count || 'UNKNOWN');

    // Update 5: Market condition & Key level
    let market_condition: 'TRENDING' | 'RANGING' | 'CHOPPY' = 'RANGING';
    const rawMarket = String(parsedJson.market_condition || '').toUpperCase().trim();
    if (rawMarket === 'TRENDING') market_condition = 'TRENDING';
    else if (rawMarket === 'CHOPPY') market_condition = 'CHOPPY';

    let near_key_level: 'RESISTANCE' | 'SUPPORT' | 'NONE' = 'NONE';
    const rawKeyLevel = String(parsedJson.near_key_level || '').toUpperCase().trim();
    if (rawKeyLevel === 'RESISTANCE') near_key_level = 'RESISTANCE';
    else if (rawKeyLevel === 'SUPPORT') near_key_level = 'SUPPORT';

    // UPDATE 3: Confluence voting calculation
    // Participating factors: Trend, Pattern, S/R (always) + HTF (if present) + Indicator (if present)
    const participatingFactors: { name: string; vote: 'UP' | 'DOWN' | 'NEUTRAL' }[] = [
      { name: 'ট্রেন্ড', vote: trend_vote },
      { name: 'প্যাটার্ন', vote: pattern_vote },
      { name: 'S/R', vote: sr_vote },
    ];

    if (htf_vote) {
      participatingFactors.push({ name: 'বড় টাইমফ্রেম', vote: htf_vote });
    }

    if (indicator_vote) {
      participatingFactors.push({ name: 'ইন্ডিকেটর', vote: indicator_vote });
    }

    const N = participatingFactors.length;
    // Required agreement threshold: ceil(2/3 * N) -> 3: 2, 4: 3, 5: 4
    const threshold = Math.ceil((2 / 3) * N);

    const upVotes = participatingFactors.filter((f) => f.vote === 'UP').length;
    const downVotes = participatingFactors.filter((f) => f.vote === 'DOWN').length;
    const neutralVotes = participatingFactors.filter((f) => f.vote === 'NEUTRAL').length;

    let computedDirection: 'UP' | 'DOWN' | 'NO TRADE' = 'NO TRADE';
    if (image_quality === 'POOR') {
      computedDirection = 'NO TRADE';
    } else if (upVotes >= threshold) {
      computedDirection = 'UP';
    } else if (downVotes >= threshold) {
      computedDirection = 'DOWN';
    } else {
      computedDirection = 'NO TRADE';
    }

    // Confidence alignment rules:
    // All participating agreed: can be HIGH
    // Any opposite vote exists: cap confidence at MODERATE
    if (
      (computedDirection === 'UP' && downVotes > 0) ||
      (computedDirection === 'DOWN' && upVotes > 0)
    ) {
      if (confidence_label === 'HIGH') {
        confidence_label = 'MODERATE';
      }
    }

    const limitations: string[] = Array.isArray(parsedJson.limitations)
      ? parsedJson.limitations.map(String)
      : [];

    if (image_quality === 'POOR' && computedDirection === 'NO TRADE') {
      limitations.unshift(
        'ছবির মান অস্পষ্ট বা ত্রুটিপূর্ণ (POOR) হওয়ায় কনফ্লুয়েন্স নিয়মানুযায়ী NO TRADE সিদ্ধান্ত দেওয়া হয়েছে।'
      );
    }

    // UPDATE 5: Strict risk rules enforced in code
    if (market_condition === 'CHOPPY') {
      computedDirection = 'NO TRADE';
      limitations.unshift(
        'বাজার অত্যন্ত চপি/এলোমেলো (CHOPPY) হওয়ায় ঝুঁকির কঠোর নিয়মে ট্রেড বাতিল (NO TRADE) করা হয়েছে।'
      );
    }

    if (computedDirection === 'UP' && near_key_level === 'RESISTANCE') {
      computedDirection = 'NO TRADE';
      limitations.unshift(
        'মূল্য তাৎক্ষণিক প্রধান রেজিস্ট্যান্সের (RESISTANCE) খুব কাছে অবস্থান করায় UP এন্ট্রি বিপজ্জনক বিধায় NO TRADE নির্ধারণ করা হয়েছে।'
      );
    }

    if (computedDirection === 'DOWN' && near_key_level === 'SUPPORT') {
      computedDirection = 'NO TRADE';
      limitations.unshift(
        'মূল্য তাৎক্ষণিক প্রধান সাপোর্টের (SUPPORT) খুব কাছে অবস্থান করায় DOWN এন্ট্রি বিপজ্জনক বিধায় NO TRADE নির্ধারণ করা হয়েছে।'
      );
    }

    if (breakout_type === 'FAKE_SUSPECTED') {
      limitations.unshift('ব্রেকআউটটি ফেকআউট (Fake Breakout) হওয়ার আশঙ্কা রয়েছে।');
    }

    // UPDATE 2: Self-Review Phase (দ্বিতীয় ধাপ - নিজেকে যাচাই)
    const elapsedMs = Date.now() - startTime;
    let counter_argument: string | undefined = undefined;
    let review_verdict: 'KEPT' | 'DOWNGRADED' | 'NO_TRADE' | 'SKIPPED' = 'SKIPPED';

    // Only proceed to review if elapsed time <= 14000ms
    if (elapsedMs <= 14000) {
      try {
        const reviewTimeoutMs = Math.min(6500, Math.max(2000, 22000 - elapsedMs));

        const reviewSystemInstruction = `You are a skeptical, strict financial market risk auditor.
Your job is to audit the initial technical analysis and formulate the strongest counter-argument against the initial bias.
RULES:
1. Provide the single strongest counter-argument in 1-2 lines of simple Bengali (counter_argument).
2. Choose verdict strictly from: "KEPT", "DOWNGRADED", or "NO_TRADE".
   - "KEPT": Initial decision is solid with no fatal flaws.
   - "DOWNGRADED": Noticeable counter-risk exists; downgrade confidence by one level.
   - "NO_TRADE": High-risk trap, major conflicting wick, or lack of momentum makes it unsafe.
3. You can NEVER reverse direction (cannot turn UP into DOWN or DOWN into UP). You can NEVER change NO TRADE into UP or DOWN.
4. Return strictly valid JSON adhering to the specified schema.`;

        const reviewPrompt = `Initial Analysis Result:
Direction: ${computedDirection}
Confidence: ${confidence_label}
Summary: ${parsedJson.summary}
Trend: ${trend}
Votes: ${participatingFactors.map((p) => `${p.name}: ${p.vote}`).join(', ')}
Market: ${market_condition}
Key Level Proximity: ${near_key_level}

Audit this decision. Give the strongest counter-argument in 1-2 lines in Bengali and return verdict ("KEPT", "DOWNGRADED", or "NO_TRADE").`;

        const reviewSchema = {
          type: Type.OBJECT,
          properties: {
            counter_argument: {
              type: Type.STRING,
              description: 'Strongest counter-argument against initial estimate in 1-2 lines in Bengali',
            },
            verdict: {
              type: Type.STRING,
              description: 'Audit verdict: KEPT, DOWNGRADED, or NO_TRADE',
            },
          },
          required: ['counter_argument', 'verdict'],
        };

        const executeReview = async () => {
          const modelName = CANDIDATE_MODELS[0] || 'gemini-3.1-flash-lite';
          const reviewConfig: any = {
            systemInstruction: reviewSystemInstruction,
            temperature: 0.1,
            responseMimeType: 'application/json',
            responseSchema: reviewSchema,
          };
          if (modelName === 'gemini-3.8-flash') {
            reviewConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }
          return await currentAi.models.generateContent({
            model: modelName,
            contents: {
              parts: [...contentParts.filter((p) => p.inlineData), { text: reviewPrompt }],
            },
            config: reviewConfig,
          });
        };

        const reviewTimeoutPromise = new Promise<never>((_, reject) => {
          setTimeout(() => reject(new Error('REVIEW_TIMEOUT')), reviewTimeoutMs);
        });

        const reviewResponse = await Promise.race([executeReview(), reviewTimeoutPromise]);
        const reviewText = reviewResponse.text || '';
        let cleanReviewJson = reviewText.trim();
        if (cleanReviewJson.startsWith('```')) {
          cleanReviewJson = cleanReviewJson.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
        }

        const parsedReview = JSON.parse(cleanReviewJson);
        counter_argument = String(parsedReview.counter_argument || '');
        const rawVerdict = String(parsedReview.verdict || '').toUpperCase().trim();

        if (rawVerdict === 'NO_TRADE') {
          if (computedDirection !== 'NO TRADE') {
            computedDirection = 'NO TRADE';
            limitations.unshift('দ্বিতীয় ধাপের আত্ম-পর্যালোচনায় অতিরিক্ত ঝুঁকি চিহ্নিত হওয়ায় সিদ্ধান্ত NO TRADE করা হয়েছে।');
          }
          review_verdict = 'NO_TRADE';
        } else if (rawVerdict === 'DOWNGRADED') {
          review_verdict = 'DOWNGRADED';
          if (confidence_label === 'HIGH') confidence_label = 'MODERATE';
          else if (confidence_label === 'MODERATE') confidence_label = 'LOW';
        } else {
          review_verdict = 'KEPT';
        }
      } catch (reviewErr) {
        console.warn('Review phase timed out or bypassed, continuing with primary result:', reviewErr);
        review_verdict = 'SKIPPED';
      }
    } else {
      review_verdict = 'SKIPPED';
      limitations.unshift('সময়স্বল্পতার কারণে দ্বিতীয় ধাপের পর্যালোচনা বাদ দেওয়া হয়েছে।');
    }

    const votes_reasoning: string[] = Array.isArray(parsedJson.votes_reasoning)
      ? parsedJson.votes_reasoning.map(String)
      : [];

    const normalizedAnalysis = {
      direction: computedDirection,
      trend_vote,
      pattern_vote,
      sr_vote,
      htf_vote,
      indicator_vote,
      indicators_visible,
      votes_reasoning,
      counter_argument,
      review_verdict,
      level_touch_count,
      level_strength,
      momentum,
      breakout_type,
      market_condition,
      near_key_level,
      summary: String(parsedJson.summary || 'বিশ্লেষণ সম্পন্ন হয়েছে।'),
      trend,
      observations: Array.isArray(parsedJson.observations)
        ? parsedJson.observations.map(String)
        : [],
      supporting_evidence: Array.isArray(parsedJson.supporting_evidence)
        ? parsedJson.supporting_evidence.map(String)
        : [],
      conflicting_evidence: Array.isArray(parsedJson.conflicting_evidence)
        ? parsedJson.conflicting_evidence.map(String)
        : [],
      image_quality,
      timeframe: String(parsedJson.timeframe || 'UNKNOWN'),
      confidence_label,
      confidence_note:
        String(parsedJson.confidence_note || 'অসমর্থিত ভিজ্যুয়াল মূল্যায়ন, এটি নিশ্চিত সাফল্যের সম্ভাবনা নয়।'),
      limitations,
    };

    res.json({
      success: true,
      analysis: normalizedAnalysis,
      timestamp: Date.now(),
    });
  } catch (error: any) {
    console.error('Server chart analysis error:', error);

    if (error?.message === 'TIMEOUT_EXCEEDED') {
      res.status(504).json({
        error: 'বিশ্লেষণের সময়সীমা (২৫ সেকেন্ড) অতিক্রম করেছে। ভিশন মডেল প্রক্রিয়া করতে অতিরিক্ত সময় নিয়েছে। অনুগ্রহ করে স্পষ্ট ও ক্রপ করা চার্ট স্ক্রিনশট দিয়ে পুনরায় চেষ্টা করুন।',
      });
      return;
    }

    let errorMsg = error?.message || 'চার্ট স্ক্রিনশট বিশ্লেষণ ব্যর্থ হয়েছে।';
    try {
      const parsed = JSON.parse(errorMsg);
      if (parsed?.error?.message) {
        errorMsg = parsed.error.message;
      }
    } catch {
      // not JSON
    }

    res.status(500).json({
      error: errorMsg,
    });
  }
};

// Mount analyze endpoint on both /api/analyze and /api/analyze-chart for backwards compatibility
app.post('/api/analyze', handleAnalyzeChart);
app.post('/api/analyze-chart', handleAnalyzeChart);

// Mount live trading API endpoints (OTCharts & engine)
app.use('/api/live', liveRouter);

// Ensure any unmatched /api/* route returns JSON instead of falling through to Vite's HTML middleware
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({
    error: `API route ${req.method} ${req.path} not found.`,
  });
});

/**
 * Setup Vite dev server middlewares or static dist serving in production
 */
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Quotex AI server running at http://0.0.0.0:${PORT} [${isDev ? 'development' : 'production'}]`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server start error:', err);
  process.exit(1);
});
