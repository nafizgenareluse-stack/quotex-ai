# Quotex Screenshot Predictor AI — Virtual Trading Lab

An educational, mobile-first web application designed for mobile and desktop browsers that analyzes user-uploaded Quotex candlestick chart screenshots using server-side Gemini vision models, delivers structured technical analysis and directional bias (UP, DOWN, or NO TRADE), and allows safe paper-trading simulation with a virtual balance, verifiable settlement, and historical CSV replay.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The application is strictly educational. It never connects to live Quotex trading accounts, executes real broker orders, or claims guaranteed market profits. All balances and payouts are 100% simulated.

- **Confirmed Decision 1 (Upload Flow)**: Direct upload via Android device gallery or camera capture (no mock chart presets cluttering the upload interface).
- **Confirmed Decision 2 (Localization)**: Bengali as the default interface language, with an instant one-tap toggle in the header/settings to full English.
- **Confirmed Decision 3 (Historical Replay)**: Bundled sample OTC and Forex candlestick CSV datasets (e.g., EUR/USD OTC, USD/INR OTC) for immediate backtesting and settlement verification, plus custom CSV file import.
- **Confirmed Decision 4 (Server-Side Vision AI)**: Server-side Gemini 3.8 Flash API endpoint via Express to ensure strict environment key security without client exposure.

---

## 1. Overview & Core Concept

- **What It Does**: Users upload a candlestick chart screenshot from Quotex (or take a photo). Before running the AI, the app validates image quality and prompts the user to confirm essential chart metadata (asset pair, timeframe, OTC status, expiry preference). The server analyzes the image with Gemini 3.8 Flash using structured JSON output, reporting observable chart features, support/resistance, candlestick structure, uncertainty, and an actionable bias: **UP**, **DOWN**, or **NO TRADE**. Users can then execute virtual paper trades using a $1,000 simulated balance.
- **Target Audience / Persona**: Retail traders, learners, and technical analysis students evaluating price action patterns and learning risk management without capital risk.
- **Key Value**: Replaces blind guesswork with structured multi-factor technical analysis, explicit uncertainty reporting, no-trade discipline, and strict simulated settlement verification.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Dashboard & Overview**: View virtual balance ($1,000 starting), total simulated trades, win rate (from verified trades), net P&L, recent trade badges, and a Reset Demo button with confirmation dialog.
2. **Chart Analysis Flow**:
   - Tap "Analyze" from bottom navigation.
   - Select chart image from gallery or capture with camera.
   - Review thumbnail preview with file size and format validation.
   - Open Chart Confirmation dialog: confirm asset pair (e.g. `EUR/USD OTC`), timeframe (e.g. `1m`, `5m`), simulated expiry (e.g. `1 min`, `5 min`), and whether the chart is current or historical.
   - Tap "Analyze Chart" to invoke the server-side Gemini vision engine with animated progress states.
   - View structured prediction card: bias (UP / DOWN / NO TRADE), uncalibrated model estimate, technical observations, contradictions, key price levels, and data limitations.
3. **Virtual Paper Trading Flow**:
   - One-tap "Simulate Trade" pre-filled with the analyzed direction, stake (default $1, adjustable), payout % (default 80%, adjustable), and simulated expiry.
   - Instant trade creation saved into local storage with status "Awaiting Verification".
4. **Settlement & Outcome Verification**:
   - Because a screenshot is static, trades do not automatically settle based solely on a timer.
   - Users resolve trades by either:
     a) Entering the observed settlement reference price at expiry;
     b) Or utilizing the Historical Replay engine where subsequent candle prices are known.
   - Upon verification, balance updates atomically: Win (+$0.80 net on $1 stake @ 80%), Loss (-$1.00), Draw ($0 net).
5. **Historical Replay Lab**:
   - Choose bundled sample pairs (e.g. EUR/USD OTC 1M, GBP/USD OTC 5M) or upload a custom OHLCV CSV.
   - Step candle-by-candle through historical price action without lookahead bias.
   - Backtest simulated predictions against subsequent candles to calculate verifiable accuracy.
6. **Analytics & History**:
   - Comprehensive trade history ledger with search, filtering by outcome (Win, Loss, Draw, Pending), and CSV/JSON export & import.
   - Performance metrics: Win rate % with sample size, Maximum Drawdown, NO TRADE count, and asset breakdown.

### Visual Identity & Theme

- **Aesthetic Direction**: High-contrast, dark institutional trading console tailored for OLED mobile displays and desktop viewports.
- **Color Palette**:
  - Background Canvas: `#0B1220` (Deep midnight navy)
  - Card Surfaces: `#131E30` (Subtle blue-slate container)
  - Hairline Borders: `#1E2D45` (1px clean contrast divider)
  - Uptrend / Primary Green: `#20C997` (Crisp mint emerald for UP / Win / Positive P&L)
  - Downtrend Red: `#FF5C70` (High-visibility coral red for DOWN / Loss / Risk warnings)
  - Accent / Focus Blue: `#4DA3FF` (Quotex brand blue for active tabs & primary CTAs)
  - Neutral Text: `#F4F7FB` (High-contrast bright text)
  - Muted Text: `#94A3B8` (Slate secondary captions & units)
- **Typography & Ergonomics**:
  - Display & Headings: `Plus Jakarta Sans` or modern system sans with tight tracking.
  - Metrics & Data: `font-mono tabular-nums` for balances, percentages, timestamps, and strike prices.
  - Zero-Pill Metadata Discipline: Metadata rendered with clean unboxed text and `·` or `/` separators.
  - Mobile Thumb Zone: 5-destination bottom navigation bar with 48px touch targets, fixed within the 15% sticky viewport cap.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Server-Side Gemini API Proxy**:
  - *Approach*: Implement an Express backend endpoint `/api/analyze-chart` that receives the image payload, calls `@google/genai` using `gemini-3.8-flash` with a strict `responseSchema`, and forwards the structured JSON to the client.
  - *Why*: Adheres to platform requirements by keeping `GEMINI_API_KEY` protected on the server, avoiding any client-side exposure.
- **Decision 2: Verifiable Settlement Engine Over Blind Timers**:
  - *Approach*: Static screenshots lack live price feeds. Instead of fabricating random price ticks or auto-settling when a timer runs down, trades are created in an `awaiting_verification` state. Users verify trades by supplying the final reference price or running historical CSV backtests.
  - *Why*: Maintains intellectual honesty and financial data integrity, preventing misleading illusions of "guaranteed bot trading".
- **Decision 3: Zero Real Broker Connectivity**:
  - *Approach*: No user login, no Quotex credentials, no real deposit/withdrawal APIs. Clear Bengali/English disclaimers on every view.
- **Decision 4: Local Persistence with IndexedDB & LocalStorage**:
  - *Approach*: Persistent storage for virtual wallet balance, trade ledger, and historical sessions with JSON export/import and demo reset.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CLIENT / MOBILE WEB APP                         │
│                                                                        │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────────┐  │
│  │   Top App Bar    │  │  Language Switch │  │  Virtual Demo Wallet │  │
│  │ (Title, Status)  │  │   (BN ⇄ EN)      │  │  ($1,000 Balance)    │  │
│  └─────────┬────────┘  └─────────┬────────┘  └──────────┬───────────┘  │
│            │                     │                      │              │
│  ┌─────────▼─────────────────────▼──────────────────────▼───────────┐  │
│  │                         VIEW ROUTER                              │  │
│  │  ┌───────────────┐ ┌───────────────┐ ┌────────────────────────┐  │  │
│  │  │   Dashboard   │ │ Analyze Chart │ │  Demo Trades & Ledger  │  │  │
│  │  └───────────────┘ └───────┬───────┘ └────────────────────────┘  │  │
│  │  ┌───────────────┐ ┌───────▼───────┐                              │  │
│  │  │ Replay & CSV  │ │ History & P&L │                              │  │
│  │  └───────────────┘ └───────────────┘                              │  │
│  └────────────────────────────┬─────────────────────────────────────┘  │
│                               │                                        │
│  ┌────────────────────────────▼─────────────────────────────────────┐  │
│  │              Bottom Navigation (Touch Ergonomics)                │  │
│  │        [Dashboard] [Analyze] [Trades] [Replay] [History]         │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────────┬────────────────────────────────────────┘
                                │ POST /api/analyze-chart
                                ▼
┌────────────────────────────────────────────────────────────────────────┐
│                       SERVER (server.ts / Express)                     │
│                                                                        │
│   • Multer / Body-parser (Base64 image validation & size check)        │
│   • GoogleGenAI SDK (`gemini-3.8-flash`) with structured schema        │
│   • Secure `GEMINI_API_KEY` handling from environment                  │
└────────────────────────────────────────────────────────────────────────┘
```

### Core Data Models

- **ChartAnalysisRecord**:
  - `id`: string (UUID)
  - `timestamp`: number
  - `assetPair`: string (e.g. "EUR/USD (OTC)")
  - `timeframe`: string (e.g. "1m")
  - `prediction`: "UP" | "DOWN" | "NO_TRADE"
  - `confidenceScore`: number (0-100, labeled as uncalibrated model estimate)
  - `visiblePrice`: number | null
  - `trendDirection`: "BULLISH" | "BEARISH" | "SIDEWAYS" | "UNCLEAR"
  - `supportLevels`: string[]
  - `resistanceLevels`: string[]
  - `supportingFactors`: string[]
  - `contradictingFactors`: string[]
  - `limitations`: string[]
  - `imageQuality`: "GOOD" | "FAIR" | "BLURRY_OR_LOW_RESOLUTION"
  - `thumbnailDataUrl`: string
- **VirtualTrade**:
  - `id`: string
  - `analysisId`: string | null
  - `assetPair`: string
  - `direction`: "UP" | "DOWN"
  - `stake`: number
  - `payoutPercent`: number (e.g. 80)
  - `expiryDuration`: string (e.g. "1m")
  - `createdAt`: number
  - `expiresAt`: number
  - `entryPrice`: number | null
  - `settlementPrice`: number | null
  - `status`: "AWAITING_VERIFICATION" | "WON" | "LOST" | "DRAW"
  - `pnl`: number (positive, negative, or 0)
  - `settledAt`: number | null
  - `notes`: string
- **WalletState**:
  - `virtualBalance`: number (initial 1,000.00)
  - `initialBalance`: 1000.00
  - `totalTrades`: number
  - `totalWins`: number
  - `totalLosses`: number
  - `totalDraws`: number

---

## 5. Implementation Roadmap

1. **Server Setup**: Create `server.ts` with Express, configuring the `/api/analyze-chart` endpoint using `@google/genai` and `gemini-3.8-flash`. Update `package.json` with scripts for full-stack Vite + Express execution.
2. **Types & Localization**: Define full TypeScript interfaces, translation dictionaries (Bengali & English), and state management stores.
3. **Core Shell & Navigation**: Construct the mobile-first dashboard layout with `#0B1220` dark theme, top app bar with language toggle and demo balance indicator, and bottom navigation bar.
4. **Screenshot Upload & Confirmation**: Implement mobile photo capture, file picker, validation (size/format), and the pre-analysis metadata confirmation modal.
5. **Gemini Vision Analysis & Results**: Integrate the analysis API, animated scanning UI, and the detailed technical prediction card with UP/DOWN/NO TRADE badges, support/resistance, and risk disclaimers.
6. **Virtual Trading Simulator**: Build the local paper-trading engine with customizable stakes, payout %, and manual/replay settlement verification.
7. **Historical Replay Backtesting**: Implement CSV parser and chronological candle stepping with preloaded OTC/Forex datasets to verify outcomes.
8. **Analytics, Export & Reset**: Implement the performance metrics dashboard (win rate with sample size, max drawdown, asset breakdown) and local data persistence with export/import and demo reset.
