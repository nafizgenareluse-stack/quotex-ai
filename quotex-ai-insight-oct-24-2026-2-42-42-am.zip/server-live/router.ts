import { Router, Request, Response } from 'express';
import { liveRateLimiter } from './rate-limiter.js';
import { fetchOtchartsCandles } from './otcharts.js';
import { generateLiveSignal } from './engine.js';
import { runWalkForwardBacktest } from './backtest.js';
import { explainLiveSignal } from './gemini-explain.js';

const router = Router();

// Apply rate limiter to all live routes (20 requests/minute per client IP)
router.use(liveRateLimiter);

const SUPPORTED_SYMBOLS = [
  { symbol: 'EURUSD_otc', name: 'EUR/USD (OTC)' },
  { symbol: 'GBPUSD_otc', name: 'GBP/USD (OTC)' },
  { symbol: 'USDJPY_otc', name: 'USD/JPY (OTC)' },
  { symbol: 'AUDUSD_otc', name: 'AUD/USD (OTC)' },
  { symbol: 'USDCAD_otc', name: 'USD/CAD (OTC)' },
  { symbol: 'EURGBP_otc', name: 'EUR/GBP (OTC)' },
  { symbol: 'EURJPY_otc', name: 'EUR/JPY (OTC)' },
  { symbol: 'GBPJPY_otc', name: 'GBP/JPY (OTC)' },
];

/**
 * GET /api/live/symbols
 */
router.get('/symbols', (req: Request, res: Response) => {
  res.json({
    symbols: SUPPORTED_SYMBOLS,
    defaultSymbol: 'EURUSD_otc',
    timeframes: [
      { tf: 60, label: '1 মিনিট (60s)' },
      { tf: 300, label: '5 মিনিট (300s)' },
    ],
  });
});

/**
 * GET /api/live/candles
 */
router.get('/candles', async (req: Request, res: Response) => {
  try {
    const symbol = ((req.query.symbol as string) || 'EURUSD_otc').trim();
    const tf = parseInt((req.query.tf as string) || '60', 10);
    const limit = Math.min(250, parseInt((req.query.limit as string) || '100', 10));

    const result = await fetchOtchartsCandles({ symbol, tf, limit });
    res.json(result);
  } catch (err: any) {
    res.status(500).json({
      error: err?.message || 'ক্যান্ডেল ডেটা লোড করতে ব্যর্থ হয়েছে।',
    });
  }
});

/**
 * GET /api/live/signal
 */
router.get('/signal', async (req: Request, res: Response) => {
  try {
    const symbol = ((req.query.symbol as string) || 'EURUSD_otc').trim();
    const tf = parseInt((req.query.tf as string) || '60', 10);

    // Fetch primary timeframe closed candles (request 100 to guarantee >= 60 closed)
    const { candles, dataStatus } = await fetchOtchartsCandles({
      symbol,
      tf,
      limit: 100,
    });

    // Optionally fetch higher timeframe candles (e.g. 5x TF) for factor 5
    let htfCandles: any = undefined;
    const htfSeconds = tf * 5;
    try {
      const htfResult = await fetchOtchartsCandles({
        symbol,
        tf: htfSeconds,
        limit: 40,
      });
      if (htfResult.candles.length >= 20) {
        htfCandles = htfResult.candles;
      }
    } catch {
      // Silently continue without HTF if unavailable or rate limited
    }

    const signal = generateLiveSignal(candles, symbol, tf, dataStatus, htfCandles);
    res.json(signal);
  } catch (err: any) {
    res.status(500).json({
      error: err?.message || 'লাইভ সিগন্যাল বিশ্লেষণ করতে ব্যর্থ হয়েছে।',
    });
  }
});

/**
 * GET /api/live/backtest
 */
router.get('/backtest', async (req: Request, res: Response) => {
  try {
    const symbol = ((req.query.symbol as string) || 'EURUSD_otc').trim();
    const tf = parseInt((req.query.tf as string) || '60', 10);
    const limit = Math.min(250, parseInt((req.query.limit as string) || '150', 10));

    const { candles, dataStatus } = await fetchOtchartsCandles({
      symbol,
      tf,
      limit,
    });

    const payload = runWalkForwardBacktest(symbol, tf, candles, dataStatus);
    res.json(payload);
  } catch (err: any) {
    res.status(500).json({
      error: err?.message || 'ব্যাকটেস্ট সম্পন্ন করতে ব্যর্থ হয়েছে।',
    });
  }
});

/**
 * POST /api/live/explain
 */
router.post('/explain', async (req: Request, res: Response) => {
  try {
    const { signal } = req.body;
    if (!signal) {
      res.status(400).json({ error: 'সিগন্যাল ডেটা প্রদান করা হয়নি।' });
      return;
    }

    const result = await explainLiveSignal(signal);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({
      error: err?.message || 'এআই ব্যাখ্যা সম্পন্ন করা সম্ভব হয়নি।',
    });
  }
});

export default router;
