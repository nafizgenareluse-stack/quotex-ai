import { GoogleGenAI } from '@google/genai';
import { LiveSignalResult } from './types.js';

const CANDIDATE_MODELS = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-flash-latest'];

export async function explainLiveSignal(
  signal: LiveSignalResult,
  apiKey?: string
): Promise<{ explanation: string; counterArgument: string }> {
  const effectiveKey = apiKey || process.env.GEMINI_API_KEY || '';

  if (!effectiveKey) {
    return {
      explanation: `এই সিগন্যালটি অ্যালগরিদমিক নিয়মে তৈরি হয়েছে (ডিরেকশন: ${signal.direction}, আত্মবিশ্বাস: ${signal.confidence})। এআই ব্যাখ্যার জন্য GEMINI_API_KEY কনফিগার করা আবশ্যক।`,
      counterArgument: 'বাজার সর্বদাই পরিবর্তনশীল, তাই যেকোনো ট্রেডে সঠিক মানি ম্যানেজমেন্ট ও স্টপ-লজিক মেনে চলা আবশ্যক।',
    };
  }

  const ai = new GoogleGenAI({
    apiKey: effectiveKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const prompt = `তুমি একজন সিনিয়র কোয়ান্ট ও প্রাইস অ্যাকশন ট্রেডিং অ্যানালিস্ট।
আমাদের কোয়ান্ট অ্যালগরিদম বাস্তব ক্যান্ডেল ডেটা ও গাণিতিক ইন্ডিকেটর বিশ্লেষণ করে একটি লাইভ সিগন্যাল জেনারেট করেছে।
তোমার দায়িত্ব হলো সম্পূর্ণ শিক্ষামূলক ও স্পষ্ট সহজ বাংলায় এই গাণিতিক ফলাফলের একটি গভীর ব্যাখ্যা এবং সবচেয়ে শক্তিশালী বিপরীত যুক্তি (Counter-argument / Risk) প্রদান করা।

গুরুত্বপূর্ণ নিয়ম:
১. তুমি অ্যালগরিদমের নির্ধারিত ডিরেকশন (${signal.direction}) বা আত্মবিশ্বাস (${signal.confidence}) পরিবর্তন করতে পারবে না। শুধু এর গাণিতিক পেছনের কারণ ব্যাখ্যা করবে।
২. উত্তর সম্পূর্ণ বাংলায় হতে হবে। তবে UP, DOWN, NO TRADE, RSI, EMA, MACD, ATR, Support, Resistance শব্দগুলো প্রয়োজনে স্বাভাবিকভাবে ব্যবহার করা যাবে।
৩. আউটপুট অবশ্যই নিচের ফরম্যাটে দুটি পরিষ্কার অংশে দিতে হবে:
[EXPLANATION]
(এখানে ৩-৫ বাক্যে ইন্ডিকেটরগুলোর পারস্পরিক সম্পর্ক ও প্রাইস অ্যাকশনের ব্যাখ্যা দাও)
[COUNTER_ARGUMENT]
(এখানে ২-৩ বাক্যে এই ট্রেডটির সম্ভাব্য সবচেয়ে বড় ঝুঁকি বা বিপরীত যুক্তি তুলে ধরো, যেমন রেজিস্ট্যান্সের সান্নিধ্য, ওভারবট/ওভারসোল্ড বা ভলিউম ল্যাক)

--- ইনপুট ডেটা ---
অ্যাসেট: ${signal.symbol} (টাইমফ্রেম: ${signal.tf}s)
সিগন্যাল: ${signal.direction}
আত্মবিশ্বাস: ${signal.confidence}
মার্কেট কন্ডিশন: ${signal.market_condition} (Efficiency Ratio: ${signal.indicators.efficiencyRatio})
কাউন্টার ট্রেন্ড: ${signal.counter_trend ? 'হ্যাঁ (বিপজ্জনক)' : 'না (ট্রেন্ড-অনুকূল)'}
ভোট ও যুক্তি:
${signal.votesReasoning.join('\n')}
ইন্ডিকেটর মান:
- EMA20: ${signal.indicators.ema20}, EMA50: ${signal.indicators.ema50}
- RSI (14): ${signal.indicators.rsi14}
- MACD Line: ${signal.indicators.macdLine}, Signal: ${signal.indicators.macdSignal}, Hist: ${signal.indicators.macdHist}
- Bollinger Bandwidth: ${signal.indicators.bbBandwidth} (Upper: ${signal.indicators.bbUpper}, Lower: ${signal.indicators.bbLower})
- ATR (14): ${signal.indicators.atr14}
লেভেল:
- নিকটবর্তী সাপোর্ট: ${signal.levels.nearestSupport ?? 'নেই'} (টাচ: ${signal.levels.supportTouches})
- নিকটবর্তী রেজিস্ট্যান্স: ${signal.levels.nearestResistance ?? 'নেই'} (টাচ: ${signal.levels.resistanceTouches})
${signal.noTradeReason ? `NO TRADE কারণ: ${signal.noTradeReason}` : ''}
`;

  let lastError: any = null;

  for (const model of CANDIDATE_MODELS) {
    try {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          temperature: 0.2,
        },
      });

      const text = response.text || '';
      let explanation = '';
      let counterArgument = '';

      if (text.includes('[COUNTER_ARGUMENT]')) {
        const parts = text.split('[COUNTER_ARGUMENT]');
        explanation = parts[0].replace('[EXPLANATION]', '').trim();
        counterArgument = parts[1].trim();
      } else if (text.includes('[EXPLANATION]')) {
        explanation = text.replace('[EXPLANATION]', '').trim();
        counterArgument = 'নিকটবর্তী এস/আর লেভেল ও ভোলাটিলিটি হঠাৎ বদলে গেলে এই ট্রেডের ফল ভিন্ন হতে পারে।';
      } else {
        explanation = text.trim();
        counterArgument = 'মার্কেট দ্রুত পরিবর্তনশীল; অপ্রত্যাশিত মোমেন্টাম রিভার্সালের সম্ভাবনা থাকে।';
      }

      return {
        explanation: explanation || 'ইন্ডিকেটর ও প্রাইস অ্যাকশনের সমন্বয়ে অ্যালগরিদম এই সিদ্ধান্ত নিয়েছে।',
        counterArgument: counterArgument || 'যেকোনো প্রতিকূল ক্যান্ডেল মোমেন্টাম এই সেটআপের কার্যকারিতা ব্যাহত করতে পারে।',
      };
    } catch (err: any) {
      lastError = err;
      console.warn(`Live Gemini explain attempt with model ${model} failed:`, err?.message || err);
    }
  }

  return {
    explanation: `অ্যালগরিদমিক বিশ্লেষণ অনুযায়ী ${signal.symbol}-এ ${signal.direction} সিগন্যাল তৈরি হয়েছে (কনফিডেন্স: ${signal.confidence})। ইন্ডিকেটর সারিবদ্ধতা ও এস/আর পজিশন পর্যবেক্ষণ করুন।`,
    counterArgument: `প্রযুক্তিগত কারণে এআই ব্যাখ্যা তৈরি করা যায়নি (${lastError?.message || 'Gemini API unavailable'})। ম্যানুয়ালি চার্ট নিশ্চিত করে ট্রেড নিন।`,
  };
}
