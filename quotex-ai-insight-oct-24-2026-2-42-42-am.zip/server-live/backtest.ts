import {
  NormalizedCandle,
  DataStatus,
  BacktestDatasetResult,
  BacktestGroupStat,
  BacktestResultPayload,
} from './types.js';
import { generateLiveSignal, MIN_CLOSED_CANDLES } from './engine.js';

interface BacktestStepResult {
  stepIndex: number;
  direction: 'UP' | 'DOWN' | 'NO TRADE';
  confidence: 'LOW' | 'MODERATE' | 'HIGH';
  agreementCount: number;
  market_condition: 'TRENDING' | 'RANGING' | 'CHOPPY';
  counter_trend: boolean;
  actualOutcome: 'UP' | 'DOWN' | 'DRAW';
  isCorrect: boolean;
  isDraw: boolean;
}

function calculateWinRate(correct: number, wrong: number): number | null {
  const decisive = correct + wrong;
  if (decisive === 0) return null;
  return Number(((correct / decisive) * 100).toFixed(1));
}

function buildGroupStats(
  steps: BacktestStepResult[],
  groupKeyFn: (step: BacktestStepResult) => string | null,
  knownLabels: string[]
): BacktestGroupStat[] {
  const statsMap: Record<string, { total: number; correct: number; wrong: number; draw: number }> = {};

  for (const label of knownLabels) {
    statsMap[label] = { total: 0, correct: 0, wrong: 0, draw: 0 };
  }

  for (const step of steps) {
    if (step.direction === 'NO TRADE') continue;
    const label = groupKeyFn(step);
    if (!label) continue;
    if (!statsMap[label]) {
      statsMap[label] = { total: 0, correct: 0, wrong: 0, draw: 0 };
    }
    statsMap[label].total++;
    if (step.isDraw) {
      statsMap[label].draw++;
    } else if (step.isCorrect) {
      statsMap[label].correct++;
    } else {
      statsMap[label].wrong++;
    }
  }

  return Object.keys(statsMap).map((label) => {
    const item = statsMap[label];
    return {
      label,
      total: item.total,
      correct: item.correct,
      wrong: item.wrong,
      draw: item.draw,
      winRate: calculateWinRate(item.correct, item.wrong),
    };
  });
}

function aggregateDataset(
  name: string,
  totalCandles: number,
  steps: BacktestStepResult[]
): BacktestDatasetResult {
  let upCount = 0;
  let downCount = 0;
  let noTradeCount = 0;
  let correctCount = 0;
  let wrongCount = 0;
  let drawCount = 0;

  for (const s of steps) {
    if (s.direction === 'NO TRADE') {
      noTradeCount++;
    } else if (s.direction === 'UP') {
      upCount++;
      if (s.isDraw) drawCount++;
      else if (s.isCorrect) correctCount++;
      else wrongCount++;
    } else if (s.direction === 'DOWN') {
      downCount++;
      if (s.isDraw) drawCount++;
      else if (s.isCorrect) correctCount++;
      else wrongCount++;
    }
  }

  const tradedSteps = steps.filter((s) => s.direction !== 'NO TRADE');

  const byConfidence = buildGroupStats(
    tradedSteps,
    (s) => s.confidence,
    ['HIGH', 'MODERATE', 'LOW']
  );

  const byDirection = buildGroupStats(
    tradedSteps,
    (s) => s.direction,
    ['UP', 'DOWN']
  );

  const byAgreement = buildGroupStats(
    tradedSteps,
    (s) => `${s.agreementCount}/4 একমত`,
    ['4/4 একমত', '3/4 একমত', '2/4 একমত']
  );

  const byMarketCondition = buildGroupStats(
    tradedSteps,
    (s) => (s.market_condition === 'TRENDING' ? 'ট্রেন্ডিং' : s.market_condition === 'RANGING' ? 'রেঞ্জিং' : 'চপি'),
    ['ট্রেন্ডিং', 'রেঞ্জিং', 'চপি']
  );

  const byTrendAlignment = buildGroupStats(
    tradedSteps,
    (s) => (s.counter_trend ? 'কাউন্টার-ট্রেন্ড' : 'ট্রেন্ড-অনুকূল'),
    ['ট্রেন্ড-অনুকূল', 'কাউন্টার-ট্রেন্ড']
  );

  return {
    name,
    totalCandles,
    totalSignals: upCount + downCount,
    upCount,
    downCount,
    noTradeCount,
    correctCount,
    wrongCount,
    drawCount,
    winRate: calculateWinRate(correctCount, wrongCount),
    byConfidence,
    byDirection,
    byAgreement,
    byMarketCondition,
    byTrendAlignment,
  };
}

/**
 * Execute a Walk-Forward Backtest across closed candlestick history.
 * Slices from MIN_CLOSED_CANDLES up to (N - 1), testing each next candle outcome.
 */
export function runWalkForwardBacktest(
  symbol: string,
  tf: number,
  candles: NormalizedCandle[],
  dataStatus: DataStatus
): BacktestResultPayload {
  const total = candles.length;
  if (total < MIN_CLOSED_CANDLES + 5) {
    const emptyDataset = (name: string): BacktestDatasetResult => ({
      name,
      totalCandles: total,
      totalSignals: 0,
      upCount: 0,
      downCount: 0,
      noTradeCount: 0,
      correctCount: 0,
      wrongCount: 0,
      drawCount: 0,
      winRate: null,
      byConfidence: [],
      byDirection: [],
      byAgreement: [],
      byMarketCondition: [],
      byTrendAlignment: [],
    });

    return {
      symbol,
      tf,
      totalCandlesReceived: total,
      development: emptyDataset('ডেভেলপমেন্ট (৭০%)'),
      outOfSample: emptyDataset('আউট-অব-স্যাম্পল (৩০%)'),
      overallWinRate: null,
      dataStatus,
    };
  }

  const allSteps: BacktestStepResult[] = [];

  // We test from index 59 to total - 2 (since target is i + 1)
  const startIndex = MIN_CLOSED_CANDLES - 1;
  const endIndex = total - 2;

  for (let i = startIndex; i <= endIndex; i++) {
    const historySlice = candles.slice(0, i + 1);
    const targetCandle = candles[i + 1];

    // Determine actual candle outcome
    let actualOutcome: 'UP' | 'DOWN' | 'DRAW' = 'DRAW';
    if (targetCandle.close > targetCandle.open) {
      actualOutcome = 'UP';
    } else if (targetCandle.close < targetCandle.open) {
      actualOutcome = 'DOWN';
    } else {
      actualOutcome = 'DRAW';
    }

    // Run engine signal generation
    const signal = generateLiveSignal(historySlice, symbol, tf, dataStatus);

    let agreementCount = 0;
    if (signal.direction === 'UP' || signal.direction === 'DOWN') {
      const v = signal.votes;
      if (v.trend_vote === signal.direction) agreementCount++;
      if (v.pattern_vote === signal.direction) agreementCount++;
      if (v.sr_vote === signal.direction) agreementCount++;
      if (v.indicator_vote === signal.direction) agreementCount++;
    }

    const isDraw = actualOutcome === 'DRAW';
    const isCorrect = signal.direction !== 'NO TRADE' && !isDraw && signal.direction === actualOutcome;

    allSteps.push({
      stepIndex: i,
      direction: signal.direction,
      confidence: signal.confidence,
      agreementCount,
      market_condition: signal.market_condition,
      counter_trend: signal.counter_trend,
      actualOutcome,
      isCorrect,
      isDraw,
    });
  }

  // Split steps into 70% Development and 30% Out-of-Sample
  const totalSteps = allSteps.length;
  const devStepCount = Math.floor(totalSteps * 0.7);

  const devSteps = allSteps.slice(0, devStepCount);
  const oosSteps = allSteps.slice(devStepCount);

  const development = aggregateDataset('ডেভেলপমেন্ট সেট (৭০%)', devSteps.length, devSteps);
  const outOfSample = aggregateDataset('আউট-অব-স্যাম্পল ভ্যালিডেশন (৩০%)', oosSteps.length, oosSteps);

  const totalCorrect = development.correctCount + outOfSample.correctCount;
  const totalWrong = development.wrongCount + outOfSample.wrongCount;
  const overallWinRate = calculateWinRate(totalCorrect, totalWrong);

  return {
    symbol,
    tf,
    totalCandlesReceived: total,
    development,
    outOfSample,
    overallWinRate,
    dataStatus,
  };
}
