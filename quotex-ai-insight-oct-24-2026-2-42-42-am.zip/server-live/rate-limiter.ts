import { Request, Response, NextFunction } from 'express';

interface RateLimitRecord {
  timestamps: number[];
}

const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS = 20;
const ipStore = new Map<string, RateLimitRecord>();

// Cleanup stale records every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [ip, record] of ipStore.entries()) {
    record.timestamps = record.timestamps.filter((t) => now - t < WINDOW_MS);
    if (record.timestamps.length === 0) {
      ipStore.delete(ip);
    }
  }
}, 5 * 60 * 1000);

export function liveRateLimiter(req: Request, res: Response, next: NextFunction): void {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() ||
    req.socket.remoteAddress ||
    'unknown-ip';

  const now = Date.now();
  let record = ipStore.get(clientIp);

  if (!record) {
    record = { timestamps: [] };
    ipStore.set(clientIp, record);
  }

  // Filter timestamps within current 60s window
  record.timestamps = record.timestamps.filter((t) => now - t < WINDOW_MS);

  if (record.timestamps.length >= MAX_REQUESTS) {
    res.status(429).json({
      error: 'অনুরোধের সীমা অতিক্রম করেছে। প্রতি মিনিটে সর্বোচ্চ ২০টি অনুরোধ অনুমোদিত। একটু পরে আবার চেষ্টা করুন।',
    });
    return;
  }

  record.timestamps.push(now);
  next();
}
