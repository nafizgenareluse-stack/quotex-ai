export interface NormalizedCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface DataStatus {
  fieldsFound: string[];
  candleCount: number;
  lastClosedCandleTime: number;
  otchartsRequestsCount: number;
}

export interface LiveIndicators {
  ema20: number;
  ema50: number;
  rsi14: number;
  macdLine: number;
  macdSignal: number;
  macdHist: number;
  atr14: number;
  bbUpper: number;
  bbMiddle: number;
  bbLower: number;
  bbBandwidth: number;
  efficiencyRatio: number;
}

export interface LevelInfo {
  nearestSupport: number | null;
  nearestResistance: number | null;
  supportTouches: number;
  resistanceTouches: number;
}

export interface LiveVotes {
  trend_vote: 'UP' | 'DOWN' | 'NEUTRAL';
  pattern_vote: 'UP' | 'DOWN' | 'NEUTRAL';
  sr_vote: 'UP' | 'DOWN' | 'NEUTRAL';
  indicator_vote: 'UP' | 'DOWN' | 'NEUTRAL';
  htf_vote?: 'UP' | 'DOWN' | 'NEUTRAL';
}

export interface LiveSignalResult {
  id: string;
  symbol: string;
  tf: number;
  direction: 'UP' | 'DOWN' | 'NO TRADE';
  confidence: 'LOW' | 'MODERATE' | 'HIGH';
  votes: LiveVotes;
  votesReasoning: string[];
  indicators: LiveIndicators;
  levels: LevelInfo;
  market_condition: 'TRENDING' | 'RANGING' | 'CHOPPY';
  counter_trend: boolean;
  noTradeReason?: string;
  signalCandleTime: number;
  targetCandleTime: number;
  targetCloseTime: number;
  createdAt: number;
  dataStatus: DataStatus;
}

export interface BacktestGroupStat {
  label: string;
  total: number;
  correct: number;
  wrong: number;
  draw: number;
  winRate: number | null;
}

export interface BacktestDatasetResult {
  name: string;
  totalCandles: number;
  totalSignals: number;
  upCount: number;
  downCount: number;
  noTradeCount: number;
  correctCount: number;
  wrongCount: number;
  drawCount: number;
  winRate: number | null;
  byConfidence: BacktestGroupStat[];
  byDirection: BacktestGroupStat[];
  byAgreement: BacktestGroupStat[];
  byMarketCondition: BacktestGroupStat[];
  byTrendAlignment: BacktestGroupStat[];
}

export interface BacktestResultPayload {
  symbol: string;
  tf: number;
  totalCandlesReceived: number;
  development: BacktestDatasetResult;
  outOfSample: BacktestDatasetResult;
  overallWinRate: number | null;
  dataStatus: DataStatus;
}
