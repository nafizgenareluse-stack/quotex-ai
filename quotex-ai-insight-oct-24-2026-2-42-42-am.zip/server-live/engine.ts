import {
  NormalizedCandle,
  LiveIndicators,
  LevelInfo,
  LiveVotes,
  LiveSignalResult,
  DataStatus,
} from './types.js';

// Configuration thresholds as named constants
export const MIN_CLOSED_CANDLES = 60;
export const EMA_FAST_PERIOD = 20;
export const EMA_SLOW_PERIOD = 50;
export const RSI_PERIOD = 14;
export const MACD_FAST_PERIOD = 12;
export const MACD_SLOW_PERIOD = 26;
export const MACD_SIGNAL_PERIOD = 9;
export const ATR_PERIOD = 14;
export const BOLLINGER_PERIOD = 20;
export const BOLLINGER_STD_DEV = 2;
export const KAUFMAN_PERIOD = 20;

export const ER_TRENDING_THRESHOLD = 0.30;
export const ER_CHOPPY_THRESHOLD = 0.15;
export const LEVEL_PROXIMITY_ATR_MULTIPLIER = 0.5; // 0.5 * ATR

/**
 * Exponential Moving Average (EMA) calculation
 */
export function calculateEMA(values: number[], period: number): number[] {
  if (values.length < period) return [];
  const k = 2 / (period + 1);
  const ema: number[] = new Array(values.length).fill(0);

  // Initial SMA for the first period
  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += values[i];
  }
  ema[period - 1] = sum / period;

  for (let i = period; i < values.length; i++) {
    ema[i] = values[i] * k + ema[i - 1] * (1 - k);
  }

  return ema;
}

/**
 * Relative Strength Index (RSI) using Wilder's Smoothing
 */
export function calculateRSI(closes: number[], period: number = RSI_PERIOD): number[] {
  if (closes.length <= period) return [];
  const rsi: number[] = new Array(closes.length).fill(50);

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) gains += diff;
    else losses += Math.abs(diff);
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  rsi[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? Math.abs(diff) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    if (avgLoss === 0) {
      rsi[i] = 100;
    } else {
      const rs = avgGain / avgLoss;
      rsi[i] = 100 - 100 / (1 + rs);
    }
  }

  return rsi;
}

/**
 * MACD (12, 26, 9) calculation
 */
export function calculateMACD(
  closes: number[],
  fast: number = MACD_FAST_PERIOD,
  slow: number = MACD_SLOW_PERIOD,
  signal: number = MACD_SIGNAL_PERIOD
): { macdLine: number; signalLine: number; hist: number; prevHist: number } {
  const emaFast = calculateEMA(closes, fast);
  const emaSlow = calculateEMA(closes, slow);

  const macdValues: number[] = [];
  const macdIndices: number[] = [];

  for (let i = slow - 1; i < closes.length; i++) {
    macdValues.push(emaFast[i] - emaSlow[i]);
    macdIndices.push(i);
  }

  const signalEMA = calculateEMA(macdValues, signal);

  const len = macdValues.length;
  const currMacd = macdValues[len - 1] || 0;
  const currSignal = signalEMA[len - 1] || 0;
  const currHist = currMacd - currSignal;

  const prevMacd = macdValues[len - 2] || 0;
  const prevSignal = signalEMA[len - 2] || 0;
  const prevHist = prevMacd - prevSignal;

  return {
    macdLine: Number(currMacd.toFixed(5)),
    signalLine: Number(currSignal.toFixed(5)),
    hist: Number(currHist.toFixed(5)),
    prevHist: Number(prevHist.toFixed(5)),
  };
}

/**
 * Average True Range (ATR 14)
 */
export function calculateATR(candles: NormalizedCandle[], period: number = ATR_PERIOD): number[] {
  if (candles.length < period + 1) return [];

  const tr: number[] = [candles[0].high - candles[0].low];
  for (let i = 1; i < candles.length; i++) {
    const h = candles[i].high;
    const l = candles[i].low;
    const prevC = candles[i - 1].close;
    const trueRange = Math.max(h - l, Math.abs(h - prevC), Math.abs(l - prevC));
    tr.push(trueRange);
  }

  const atr: number[] = new Array(candles.length).fill(0);
  let trSum = 0;
  for (let i = 0; i < period; i++) {
    trSum += tr[i];
  }
  atr[period - 1] = trSum / period;

  for (let i = period; i < candles.length; i++) {
    atr[i] = (atr[i - 1] * (period - 1) + tr[i]) / period;
  }

  return atr;
}

/**
 * Bollinger Bands (20, 2)
 */
export function calculateBollinger(
  closes: number[],
  period: number = BOLLINGER_PERIOD,
  mult: number = BOLLINGER_STD_DEV
): { upper: number; middle: number; lower: number; bandwidth: number } {
  if (closes.length < period) {
    const c = closes[closes.length - 1] || 0;
    return { upper: c, middle: c, lower: c, bandwidth: 0 };
  }

  const slice = closes.slice(closes.length - period);
  const middle = slice.reduce((acc, v) => acc + v, 0) / period;

  const variance = slice.reduce((acc, v) => acc + Math.pow(v - middle, 2), 0) / period;
  const stdDev = Math.sqrt(variance);

  const upper = middle + mult * stdDev;
  const lower = middle - mult * stdDev;
  const bandwidth = middle > 0 ? (upper - lower) / middle : 0;

  return {
    upper: Number(upper.toFixed(5)),
    middle: Number(middle.toFixed(5)),
    lower: Number(lower.toFixed(5)),
    bandwidth: Number(bandwidth.toFixed(5)),
  };
}

/**
 * Kaufman Efficiency Ratio (ER)
 */
export function calculateEfficiencyRatio(closes: number[], period: number = KAUFMAN_PERIOD): number {
  if (closes.length < period + 1) return 0.2;

  const lastIdx = closes.length - 1;
  const totalChange = Math.abs(closes[lastIdx] - closes[lastIdx - period]);

  let sumVolatility = 0;
  for (let i = lastIdx - period + 1; i <= lastIdx; i++) {
    sumVolatility += Math.abs(closes[i] - closes[i - 1]);
  }

  if (sumVolatility === 0) return 1;
  return Number((totalChange / sumVolatility).toFixed(4));
}

/**
 * Swing Highs and Lows cluster grouping
 */
export function findSwingLevels(
  candles: NormalizedCandle[],
  pivotWindow: number = 3,
  lookback: number = 50,
  atr: number
): { nearestSupport: number | null; nearestResistance: number | null; supportTouches: number; resistanceTouches: number } {
  const start = Math.max(0, candles.length - lookback);
  const relevant = candles.slice(start);
  const currentPrice = candles[candles.length - 1].close;
  const clusterTolerance = Math.max(0.0001, atr * 0.35);

  const swingHighs: number[] = [];
  const swingLows: number[] = [];

  for (let i = pivotWindow; i < relevant.length - pivotWindow; i++) {
    const high = relevant[i].high;
    const low = relevant[i].low;

    let isHigh = true;
    let isLow = true;

    for (let j = 1; j <= pivotWindow; j++) {
      if (relevant[i - j].high >= high || relevant[i + j].high >= high) isHigh = false;
      if (relevant[i - j].low <= low || relevant[i + j].low <= low) isLow = false;
    }

    if (isHigh) swingHighs.push(high);
    if (isLow) swingLows.push(low);
  }

  // Count touches for a level
  const countTouches = (level: number) => {
    let touches = 0;
    for (const c of relevant) {
      if (Math.abs(c.high - level) <= clusterTolerance || Math.abs(c.low - level) <= clusterTolerance) {
        touches++;
      }
    }
    return Math.max(1, touches);
  };

  // Find nearest resistance above current price
  const resistances = swingHighs.filter((h) => h > currentPrice).sort((a, b) => a - b);
  const nearestResistance = resistances.length > 0 ? Number(resistances[0].toFixed(5)) : null;
  const resistanceTouches = nearestResistance ? countTouches(nearestResistance) : 0;

  // Find nearest support below current price
  const supports = swingLows.filter((l) => l < currentPrice).sort((a, b) => b - a);
  const nearestSupport = supports.length > 0 ? Number(supports[0].toFixed(5)) : null;
  const supportTouches = nearestSupport ? countTouches(nearestSupport) : 0;

  return {
    nearestSupport,
    nearestResistance,
    supportTouches,
    resistanceTouches,
  };
}

/**
 * Primary Signal Engine executing deterministic indicator calculations and confluence rules
 */
export function generateLiveSignal(
  candles: NormalizedCandle[],
  symbol: string,
  tf: number,
  dataStatus: DataStatus,
  htfCandles?: NormalizedCandle[]
): LiveSignalResult {
  const signalId = `live_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  if (candles.length < MIN_CLOSED_CANDLES) {
    return {
      id: signalId,
      symbol,
      tf,
      direction: 'NO TRADE',
      confidence: 'LOW',
      votes: {
        trend_vote: 'NEUTRAL',
        pattern_vote: 'NEUTRAL',
        sr_vote: 'NEUTRAL',
        indicator_vote: 'NEUTRAL',
      },
      votesReasoning: ['পর্যাপ্ত বন্ধ ক্যান্ডেল নেই (ন্যূনতম ৬০টি প্রয়োজন)'],
      indicators: {
        ema20: 0,
        ema50: 0,
        rsi14: 50,
        macdLine: 0,
        macdSignal: 0,
        macdHist: 0,
        atr14: 0,
        bbUpper: 0,
        bbMiddle: 0,
        bbLower: 0,
        bbBandwidth: 0,
        efficiencyRatio: 0,
      },
      levels: {
        nearestSupport: null,
        nearestResistance: null,
        supportTouches: 0,
        resistanceTouches: 0,
      },
      market_condition: 'CHOPPY',
      counter_trend: false,
      noTradeReason: `পর্যাপ্ত বন্ধ ক্যান্ডেল নেই (ন্যূনতম ${MIN_CLOSED_CANDLES}টি প্রয়োজন, পাওয়া গেছে ${candles.length}টি)।`,
      signalCandleTime: candles[candles.length - 1]?.time || 0,
      targetCandleTime: (candles[candles.length - 1]?.time || 0) + tf,
      targetCloseTime: (candles[candles.length - 1]?.time || 0) + 2 * tf,
      createdAt: Date.now(),
      dataStatus,
    };
  }

  const closes = candles.map((c) => c.close);
  const lastIdx = candles.length - 1;
  const lastCandle = candles[lastIdx];
  const prevCandle = candles[lastIdx - 1];
  const currentPrice = lastCandle.close;

  // 1. Calculate Technical Indicators
  const ema20Arr = calculateEMA(closes, EMA_FAST_PERIOD);
  const ema50Arr = calculateEMA(closes, EMA_SLOW_PERIOD);
  const ema20 = Number(ema20Arr[lastIdx].toFixed(5));
  const ema20Prev = Number(ema20Arr[lastIdx - 1].toFixed(5));
  const ema50 = Number(ema50Arr[lastIdx].toFixed(5));

  const rsiArr = calculateRSI(closes, RSI_PERIOD);
  const rsi14 = Number(rsiArr[lastIdx].toFixed(2));

  const macd = calculateMACD(closes);
  const atrArr = calculateATR(candles, ATR_PERIOD);
  const atr14 = Number((atrArr[lastIdx] || 0.0005).toFixed(5));

  const bb = calculateBollinger(closes);
  const efficiencyRatio = calculateEfficiencyRatio(closes, KAUFMAN_PERIOD);

  // 2. Market Condition Evaluation
  let market_condition: 'TRENDING' | 'RANGING' | 'CHOPPY' = 'RANGING';
  if (efficiencyRatio >= ER_TRENDING_THRESHOLD) {
    market_condition = 'TRENDING';
  } else if (efficiencyRatio < ER_CHOPPY_THRESHOLD) {
    market_condition = 'CHOPPY';
  }

  // 3. Support & Resistance Swing Detection
  const levels = findSwingLevels(candles, 3, 50, atr14);

  // 4. Calculate Factor 1: Trend Vote
  let trend_vote: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
  let trendReason = 'ট্রেন্ড অনির্ধারিত';
  if (currentPrice > ema20 && ema20 > ema50 && ema20 > ema20Prev) {
    trend_vote = 'UP';
    trendReason = 'দাম > EMA20 > EMA50 এবং EMA20 ঊর্ধ্বমুখী (বুলিশ ট্রেন্ড)';
  } else if (currentPrice < ema20 && ema20 < ema50 && ema20 < ema20Prev) {
    trend_vote = 'DOWN';
    trendReason = 'দাম < EMA20 < EMA50 এবং EMA20 নিম্নমুখী (বেয়ারিশ ট্রেন্ড)';
  } else {
    trendReason = 'EMA সারিবদ্ধতা স্পষ্ট নয় বা পার্শ্বমুখী';
  }

  // 5. Calculate Factor 2: Candlestick Pattern Vote
  let pattern_vote: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
  let patternReason = 'কোনো জোরালো রিভার্সাল বা এনগালফিং প্যাটার্ন নেই';

  const cRange = lastCandle.high - lastCandle.low;
  const cBody = Math.abs(lastCandle.close - lastCandle.open);
  const cUpperWick = lastCandle.high - Math.max(lastCandle.open, lastCandle.close);
  const cLowerWick = Math.min(lastCandle.open, lastCandle.close) - lastCandle.low;

  const isBullishEngulfing =
    prevCandle.close < prevCandle.open &&
    lastCandle.close > lastCandle.open &&
    lastCandle.close >= prevCandle.open &&
    lastCandle.open <= prevCandle.close;

  const isBearishEngulfing =
    prevCandle.close > prevCandle.open &&
    lastCandle.close < lastCandle.open &&
    lastCandle.close <= prevCandle.open &&
    lastCandle.open >= prevCandle.close;

  const isHammer = cRange > 0 && cLowerWick >= 0.5 * cRange && cUpperWick <= 0.2 * cRange && cBody <= 0.35 * cRange;
  const isShootingStar = cRange > 0 && cUpperWick >= 0.5 * cRange && cLowerWick <= 0.2 * cRange && cBody <= 0.35 * cRange;

  if (isBullishEngulfing) {
    pattern_vote = 'UP';
    patternReason = 'বুলিশ এনগালফিং প্যাটার্ন গঠিত হয়েছে';
  } else if (isHammer) {
    pattern_vote = 'UP';
    patternReason = 'হ্যামার / পিন বার (নিচ থেকে জোরালো উইক রিজেকশন)';
  } else if (isBearishEngulfing) {
    pattern_vote = 'DOWN';
    patternReason = 'বেয়ারিশ এনগালফিং প্যাটার্ন গঠিত হয়েছে';
  } else if (isShootingStar) {
    pattern_vote = 'DOWN';
    patternReason = 'শুটিং স্টার (উপর থেকে তীব্র উইক রিজেকশন)';
  }

  // 6. Calculate Factor 3: Support / Resistance & Price Action Vote
  let sr_vote: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
  let srReason = 'মূল্য কোনো তাৎক্ষণিক প্রধান লেভেলে সাড়া দেয়নি';
  const proximityThreshold = LEVEL_PROXIMITY_ATR_MULTIPLIER * atr14;

  const nearSupport = levels.nearestSupport !== null && Math.abs(currentPrice - levels.nearestSupport) <= proximityThreshold;
  const nearResistance = levels.nearestResistance !== null && Math.abs(currentPrice - levels.nearestResistance) <= proximityThreshold;

  if (nearSupport && cLowerWick >= 0.3 * cRange) {
    sr_vote = 'UP';
    srReason = `সাপোর্ট (${levels.nearestSupport}) থেকে নিচমুখী রিজেকশন বাউন্স (স্পর্শ: ${levels.supportTouches})`;
  } else if (nearResistance && cUpperWick >= 0.3 * cRange) {
    sr_vote = 'DOWN';
    srReason = `রেজিস্ট্যান্স (${levels.nearestResistance}) থেকে উপরমুখী রিজেকশন (স্পর্শ: ${levels.resistanceTouches})`;
  } else if (levels.nearestResistance !== null && currentPrice > levels.nearestResistance && prevCandle.close > levels.nearestResistance) {
    sr_vote = 'UP';
    srReason = 'রেজিস্ট্যান্সের উপরে ব্রেকআউট হোল্ড করছে';
  } else if (levels.nearestSupport !== null && currentPrice < levels.nearestSupport && prevCandle.close < levels.nearestSupport) {
    sr_vote = 'DOWN';
    srReason = 'সাপোর্টের নিচে ব্রেকডাউন বজায় রয়েছে';
  }

  // 7. Calculate Factor 4: Indicators Vote (RSI + MACD Histogram)
  let indicator_vote: 'UP' | 'DOWN' | 'NEUTRAL' = 'NEUTRAL';
  let indicatorReason = 'ইন্ডিকেটরসমূহ নিরপেক্ষ বা মিশ্র';

  if (rsi14 >= 50 && rsi14 <= 70 && macd.hist > 0 && macd.hist >= macd.prevHist) {
    indicator_vote = 'UP';
    indicatorReason = `RSI=${rsi14} (বুলিশ জোন) এবং MACD হিস্টোগ্রাম ধনাত্মক ও ক্রমবর্ধমান`;
  } else if (rsi14 <= 50 && rsi14 >= 30 && macd.hist < 0 && macd.hist <= macd.prevHist) {
    indicator_vote = 'DOWN';
    indicatorReason = `RSI=${rsi14} (বেয়ারিশ জোন) এবং MACD হিস্টোগ্রাম ঋণাত্মক ও নিম্নমুখী`;
  } else if (rsi14 > 70) {
    indicatorReason = `RSI=${rsi14} অতিরিক্ত ক্রয় (Overbought), সতর্কাবস্থা`;
  } else if (rsi14 < 30) {
    indicatorReason = `RSI=${rsi14} অতিরিক্ত বিক্রয় (Oversold), সতর্কাবস্থা`;
  }

  // 8. Optional Factor 5: Higher Timeframe Vote
  let htf_vote: 'UP' | 'DOWN' | 'NEUTRAL' | undefined = undefined;
  let htfReason: string | undefined = undefined;
  if (htfCandles && htfCandles.length >= 20) {
    const htfCloses = htfCandles.map((c) => c.close);
    const htfEma20 = calculateEMA(htfCloses, 20);
    const htfEma50 = calculateEMA(htfCloses, Math.min(50, htfCloses.length));
    const htfLastIdx = htfCandles.length - 1;
    const htfPrice = htfCloses[htfLastIdx];
    const htfE20 = htfEma20[htfLastIdx];
    const htfE50 = htfEma50[htfLastIdx];

    if (htfPrice > htfE20 && htfE20 > htfE50) {
      htf_vote = 'UP';
      htfReason = 'বড় টাইমফ্রেমে সামগ্রিক বুলিশ ট্রেন্ড বজায় রয়েছে';
    } else if (htfPrice < htfE20 && htfE20 < htfE50) {
      htf_vote = 'DOWN';
      htfReason = 'বড় টাইমফ্রেমে সামগ্রিক বেয়ারিশ ট্রেন্ড বজায় রয়েছে';
    } else {
      htf_vote = 'NEUTRAL';
      htfReason = 'বড় টাইমফ্রেম পার্শ্বমুখী বা অনিশ্চিত';
    }
  }

  // 9. Confluence (Two-Thirds Agreement Rule)
  const participatingVotes: { factor: string; vote: 'UP' | 'DOWN' | 'NEUTRAL' }[] = [
    { factor: 'ট্রেন্ড', vote: trend_vote },
    { factor: 'প্যাটার্ন', vote: pattern_vote },
    { factor: 'S/R', vote: sr_vote },
    { factor: 'ইন্ডিকেটর', vote: indicator_vote },
  ];

  if (htf_vote !== undefined) {
    participatingVotes.push({ factor: 'বড় টাইমফ্রেম', vote: htf_vote });
  }

  const N = participatingVotes.length; // 4 or 5
  const threshold = Math.ceil((2 / 3) * N); // 4 -> 3, 5 -> 4

  const upVotes = participatingVotes.filter((v) => v.vote === 'UP').length;
  const downVotes = participatingVotes.filter((v) => v.vote === 'DOWN').length;

  let direction: 'UP' | 'DOWN' | 'NO TRADE' = 'NO TRADE';
  let confidence: 'LOW' | 'MODERATE' | 'HIGH' = 'LOW';
  let noTradeReason: string | undefined = undefined;

  if (upVotes >= threshold) {
    direction = 'UP';
  } else if (downVotes >= threshold) {
    direction = 'DOWN';
  } else {
    direction = 'NO TRADE';
    noTradeReason = `কনফ্লুয়েন্স অর্জিত হয়নি (${N}-এর মধ্যে সম্মত ভোট: ${Math.max(upVotes, downVotes)}, প্রয়োজন: ${threshold})।`;
  }

  // Confidence assignment
  if (direction !== 'NO TRADE') {
    const isAllAgreed = (direction === 'UP' && upVotes === N) || (direction === 'DOWN' && downVotes === N);
    const hasOpposite = (direction === 'UP' && downVotes > 0) || (direction === 'DOWN' && upVotes > 0);

    if (isAllAgreed) {
      confidence = 'HIGH';
    } else if (hasOpposite) {
      confidence = 'MODERATE';
    } else {
      confidence = 'MODERATE';
    }
  }

  // 10. Strict Risk Rules (Code-enforced)
  if (market_condition === 'CHOPPY') {
    direction = 'NO TRADE';
    confidence = 'LOW';
    noTradeReason = 'বাজার অত্যন্ত চপি/এলোমেলো (Efficiency Ratio < ০.১৫), ঝুঁকি এড়াতে NO TRADE ঘোষণা করা হয়েছে।';
  } else if (direction === 'UP' && levels.nearestResistance !== null && Math.abs(currentPrice - levels.nearestResistance) <= proximityThreshold) {
    direction = 'NO TRADE';
    confidence = 'LOW';
    noTradeReason = `দাম তাৎক্ষণিক প্রধান রেজিস্ট্যান্সের (${levels.nearestResistance}) খুব কাছে অবস্থান করায় UP এন্ট্রি বিপজ্জনক বিধায় NO TRADE।`;
  } else if (direction === 'DOWN' && levels.nearestSupport !== null && Math.abs(currentPrice - levels.nearestSupport) <= proximityThreshold) {
    direction = 'NO TRADE';
    confidence = 'LOW';
    noTradeReason = `দাম তাৎক্ষণিক প্রধান সাপোর্টের (${levels.nearestSupport}) খুব কাছে অবস্থান করায় DOWN এন্ট্রি বিপজ্জনক বিধায় NO TRADE।`;
  }

  // Counter trend flag
  let counter_trend = false;
  if (direction !== 'NO TRADE' && trend_vote !== 'NEUTRAL' && trend_vote !== direction) {
    counter_trend = true;
  }

  const votesReasoning: string[] = [
    `১. ট্রেন্ড: ${trendReason}`,
    `২. প্যাটার্ন: ${patternReason}`,
    `৩. S/R: ${srReason}`,
    `৪. ইন্ডিকেটর: ${indicatorReason}`,
  ];
  if (htfReason) {
    votesReasoning.push(`৫. বড় টাইমফ্রেম: ${htfReason}`);
  }

  const votes: LiveVotes = {
    trend_vote,
    pattern_vote,
    sr_vote,
    indicator_vote,
    htf_vote,
  };

  const indicators: LiveIndicators = {
    ema20,
    ema50,
    rsi14,
    macdLine: macd.macdLine,
    macdSignal: macd.signalLine,
    macdHist: macd.hist,
    atr14,
    bbUpper: bb.upper,
    bbMiddle: bb.middle,
    bbLower: bb.lower,
    bbBandwidth: bb.bandwidth,
    efficiencyRatio,
  };

  return {
    id: signalId,
    symbol,
    tf,
    direction,
    confidence,
    votes,
    votesReasoning,
    indicators,
    levels,
    market_condition,
    counter_trend,
    noTradeReason,
    signalCandleTime: lastCandle.time,
    targetCandleTime: lastCandle.time + tf,
    targetCloseTime: lastCandle.time + 2 * tf,
    createdAt: Date.now(),
    dataStatus,
  };
}
