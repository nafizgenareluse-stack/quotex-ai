import { NormalizedCandle, DataStatus } from './types.js';

export const OTCHARTS_BASE_URL = 'https://otcharts.com/v1';
export const DEFAULT_TF_SECONDS = 60; // Configurable constant: 60s
export const OTCHARTS_SYMBOLS_PATH = ''; // Configurable constant: empty default as per README instructions
export const FALLBACK_SYMBOLS = ['EURUSD_otc', 'GBPUSD_otc', 'USDJPY_otc'];

// Global server in-memory counter for requests made to OTCharts
let otchartsRequestsCount = 0;

export function getOtchartsRequestsCount(): number {
  return otchartsRequestsCount;
}

interface CacheEntry {
  candles: NormalizedCandle[];
  rawFields: string[];
  lastClosedCandleTime: number;
  timestamp: number;
}

// 15-second in-memory cache to conserve weekly 1500 request quota
const memoryCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 15 * 1000;

export interface FetchCandlesOptions {
  symbol: string;
  tf: number;
  limit: number;
}

export interface FetchCandlesResult {
  candles: NormalizedCandle[];
  dataStatus: DataStatus;
}

/**
 * Fetch and normalize candles from OTCharts API with 15s in-memory caching and strict validation
 */
export async function fetchOtchartsCandles(
  options: FetchCandlesOptions
): Promise<FetchCandlesResult> {
  const { symbol, tf, limit } = options;
  const cacheKey = `${symbol.toUpperCase()}:${tf}:${limit}`;
  const now = Date.now();

  const cached = memoryCache.get(cacheKey);
  if (cached && now - cached.timestamp < CACHE_TTL_MS) {
    return {
      candles: cached.candles,
      dataStatus: {
        fieldsFound: cached.rawFields,
        candleCount: cached.candles.length,
        lastClosedCandleTime: cached.lastClosedCandleTime,
        otchartsRequestsCount,
      },
    };
  }

  const apiKey = process.env.OTCHARTS_API_KEY || '';
  if (!apiKey) {
    throw new Error('OTCHARTS_API_KEY পরিবেশ চলকে সেট করা নেই। সার্ভার সেটিংসে API কী যুক্ত করুন।');
  }

  const url = `${OTCHARTS_BASE_URL}/candles?venue=quotex&symbol=${encodeURIComponent(
    symbol
  )}&tf=${tf}&limit=${limit}`;

  otchartsRequestsCount++;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

  let response: globalThis.Response;
  try {
    response = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        Accept: 'application/json',
      },
      signal: controller.signal,
    });
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err?.name === 'AbortError' || err?.message?.includes('aborted')) {
      throw new Error('OTCharts সার্ভারে সংযোগের সময়সীমা (১০ সেকেন্ড) অতিক্রম করেছে।');
    }
    throw new Error(`OTCharts সংযোগে নেটওয়ার্ক ত্রুটি: ${err?.message || 'অজানা ত্রুটি'}`);
  } finally {
    clearTimeout(timeoutId);
  }

  if (response.status === 401 || response.status === 403) {
    throw new Error('OTCharts API কী ভুল বা অননুমোদিত (৪০১/৪০৩)। অনুগ্রহ করে আপনার OTCharts API কী যাচাই করুন।');
  }

  if (response.status === 429) {
    throw new Error('OTCharts API কোটা শেষ বা রেট লিমিট অতিক্রম করেছে (৪২৯)। পরে চেষ্টা করুন।');
  }

  if (!response.ok) {
    throw new Error(`OTCharts সার্ভার ত্রুটি প্রদান করেছে (HTTP ${response.status}: ${response.statusText})`);
  }

  let rawJson: any;
  try {
    rawJson = await response.json();
  } catch {
    throw new Error('OTCharts থেকে প্রাপ্ত ডেটা সঠিক JSON নয় (অপ্রত্যাশিত ফরম্যাট)।');
  }

  // Handle potential envelope formats: array directly, or { candles: [] }, or { data: [] }
  let rawList: any[] = [];
  if (Array.isArray(rawJson)) {
    rawList = rawJson;
  } else if (rawJson && Array.isArray(rawJson.candles)) {
    rawList = rawJson.candles;
  } else if (rawJson && Array.isArray(rawJson.data)) {
    rawList = rawJson.data;
  } else if (rawJson && Array.isArray(rawJson.result)) {
    rawList = rawJson.result;
  } else {
    throw new Error('OTCharts থেকে অপ্রত্যাশিত ফরম্যাটের ডেটা পাওয়া গেছে (কোনো ক্যান্ডেল তালিকা মেলেনি)।');
  }

  if (rawList.length === 0) {
    throw new Error(`OTCharts থেকে ${symbol} এর জন্য কোনো ক্যান্ডেল ডেটা পাওয়া যায়নি।`);
  }

  // Inspect first candle's fields
  const firstItem = rawList[0];
  const rawFields = typeof firstItem === 'object' && firstItem !== null ? Object.keys(firstItem) : [];

  const normalizedList: NormalizedCandle[] = [];

  for (const item of rawList) {
    if (!item || typeof item !== 'object') continue;

    // Time field detection
    let rawTime = item.time ?? item.t ?? item.timestamp ?? item.Date ?? item.date;
    if (rawTime === undefined) continue;

    let timeNum = typeof rawTime === 'string' ? Number(new Date(rawTime).getTime() / 1000) : Number(rawTime);
    if (isNaN(timeNum)) continue;

    // If milliseconds (> 1e12), convert to seconds
    if (timeNum > 1e12) {
      timeNum = Math.floor(timeNum / 1000);
    }

    // Open, High, Low, Close detection
    const rawOpen = item.open ?? item.o;
    const rawHigh = item.high ?? item.h;
    const rawLow = item.low ?? item.l;
    const rawClose = item.close ?? item.c;

    if (rawClose === undefined) continue;

    const close = Number(rawClose);
    if (isNaN(close)) continue;

    // Check if open, high, low exist. If missing, we must NOT invent them!
    if (rawOpen === undefined || rawHigh === undefined || rawLow === undefined) {
      throw new Error('ডেটায় open/high/low পাওয়া যায়নি, ক্যান্ডেল-প্যাটার্ন বিশ্লেষণ সম্ভব নয়।');
    }

    const open = Number(rawOpen);
    const high = Number(rawHigh);
    const low = Number(rawLow);

    if (isNaN(open) || isNaN(high) || isNaN(low)) {
      throw new Error('ডেটায় open/high/low সংখ্যামান হিসেবে পাওয়া যায়নি, ক্যান্ডেল বিশ্লেষণ সম্ভব নয়।');
    }

    const volume = Number(item.volume ?? item.v ?? 0) || 0;

    normalizedList.push({
      time: timeNum,
      open,
      high,
      low,
      close,
      volume,
    });
  }

  if (normalizedList.length === 0) {
    throw new Error('ক্যান্ডেল ডেটা পার্স করার পর কোনো বৈধ ক্যান্ডেল পাওয়া যায়নি।');
  }

  // Sort chronologically ascending
  normalizedList.sort((a, b) => a.time - b.time);

  // Deduplicate by time
  const deduplicated: NormalizedCandle[] = [];
  const seenTimes = new Set<number>();
  for (const c of normalizedList) {
    if (!seenTimes.has(c.time)) {
      seenTimes.add(c.time);
      deduplicated.push(c);
    }
  }

  // Closed candle rule: (candle.time + tf) <= serverNowSeconds
  const serverNowSeconds = Math.floor(Date.now() / 1000);
  const closedCandles = deduplicated.filter((c) => c.time + tf <= serverNowSeconds);

  if (closedCandles.length === 0) {
    throw new Error('এখনো কোনো বন্ধ ক্যান্ডেল প্রস্তুত হয়নি। পরবর্তী ক্যান্ডেল বন্ধ হওয়া পর্যন্ত অপেক্ষা করুন।');
  }

  const lastClosed = closedCandles[closedCandles.length - 1];
  const lastClosedTime = lastClosed.time + tf;

  // Stale data check: if last closed candle is older than 3 * tf
  if (serverNowSeconds - lastClosedTime > 3 * tf) {
    throw new Error(
      `ডেটা হালনাগাদ নয় (শেষ বন্ধ ক্যান্ডেল ৩×tf-এর বেশি পুরোনো)। শেষ প্রাপ্ত সময়: ${new Date(
        lastClosedTime * 1000
      ).toLocaleTimeString('bn-BD')}`
    );
  }

  // Cache normalized result
  memoryCache.set(cacheKey, {
    candles: closedCandles,
    rawFields,
    lastClosedCandleTime: lastClosedTime,
    timestamp: now,
  });

  return {
    candles: closedCandles,
    dataStatus: {
      fieldsFound: rawFields,
      candleCount: closedCandles.length,
      lastClosedCandleTime: lastClosedTime,
      otchartsRequestsCount,
    },
  };
}
