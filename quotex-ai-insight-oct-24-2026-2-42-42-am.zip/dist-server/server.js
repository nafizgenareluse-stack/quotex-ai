// server.ts
import express from "express";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
dotenv.config();
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var app = express();
var PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3e3;
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ limit: "25mb", extended: true }));
app.use((err, req, res, next) => {
  if (err && (err.type === "entity.too.large" || err.status === 413)) {
    res.status(413).json({
      error: "\u0986\u09AA\u09B2\u09CB\u09A1 \u0995\u09B0\u09BE \u099B\u09AC\u09BF\u09B0 \u09AB\u09BE\u0987\u09B2 \u0985\u09A4\u09CD\u09AF\u09A8\u09CD\u09A4 \u09AC\u09A1\u09BC\u0964 \u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u099B\u09CB\u099F \u099A\u09BE\u09B0\u09CD\u099F \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09B6\u099F \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8\u0964"
    });
    return;
  }
  if (err instanceof SyntaxError && "body" in err) {
    res.status(400).json({
      error: "\u0985\u09A8\u09C1\u09B0\u09CB\u09A7\u09C7\u09B0 JSON \u09AA\u09C7-\u09B2\u09CB\u09A1 \u09B8\u09A0\u09BF\u0995 \u09A8\u09AF\u09BC\u0964"
    });
    return;
  }
  next(err);
});
var apiKey = process.env.GEMINI_API_KEY || "";
var ai = apiKey ? new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build"
    }
  }
}) : null;
var SUPPORTED_MIME_TYPES = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp"]);
var CANDIDATE_MODELS = ["gemini-3.1-flash-lite", "gemini-3.8-flash", "gemini-flash-latest"];
var MAX_IMAGE_BYTES = 20 * 1024 * 1024;
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: Boolean(apiKey),
    models: CANDIDATE_MODELS,
    timestamp: Date.now()
  });
});
function validateAndCleanBase64(imageBase64, rawMimeType, label) {
  const normalizedMime = rawMimeType.toLowerCase().trim();
  const effectiveMime = normalizedMime === "image/jpg" ? "image/jpeg" : normalizedMime;
  if (!SUPPORTED_MIME_TYPES.has(effectiveMime)) {
    throw new Error(`\u0985\u09B8\u09AE\u09B0\u09CD\u09A5\u09BF\u09A4 ${label} \u09AB\u09B0\u09AE\u09CD\u09AF\u09BE\u099F (${rawMimeType})\u0964 \u09B6\u09C1\u09A7\u09C1\u09AE\u09BE\u09A4\u09CD\u09B0 JPEG, PNG, \u098F\u09AC\u0982 WebP \u09AB\u09B0\u09AE\u09CD\u09AF\u09BE\u099F \u09B8\u09AE\u09B0\u09CD\u09A5\u09BF\u09A4\u0964`);
  }
  const cleanBase64 = imageBase64.includes(",") ? imageBase64.split(",")[1] : imageBase64;
  const approximateByteSize = Math.round(cleanBase64.length * 3 / 4);
  if (approximateByteSize > MAX_IMAGE_BYTES) {
    throw new Error(`${label} \u09AB\u09BE\u0987\u09B2\u09C7\u09B0 \u0986\u0995\u09BE\u09B0 (${(approximateByteSize / (1024 * 1024)).toFixed(1)} MB) \u09E7\u09EB \u09AE\u09C7\u0997\u09BE\u09AC\u09BE\u0987\u099F \u09B8\u09C0\u09AE\u09BE \u0985\u09A4\u09BF\u0995\u09CD\u09B0\u09AE \u0995\u09B0\u09C7\u099B\u09C7\u0964`);
  }
  return { cleanBase64, effectiveMime };
}
var handleAnalyzeChart = async (req, res) => {
  const startTime = Date.now();
  try {
    const {
      imageBase64,
      mimeType = "image/png",
      higherTfImageBase64,
      higherTfMimeType = "image/png"
    } = req.body;
    if (!imageBase64 || typeof imageBase64 !== "string") {
      res.status(400).json({
        error: "\u0995\u09CB\u09A8\u09CB \u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF \u099A\u09BE\u09B0\u09CD\u099F \u099B\u09AC\u09BF \u09AA\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AF\u09BC\u09A8\u09BF\u0964 \u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u098F\u0995\u099F\u09BF \u099A\u09BE\u09B0\u09CD\u099F \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09B6\u099F \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8\u0964"
      });
      return;
    }
    const { cleanBase64, effectiveMime } = validateAndCleanBase64(
      imageBase64,
      mimeType,
      "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF \u099A\u09BE\u09B0\u09CD\u099F"
    );
    let cleanHigherTfBase64 = null;
    let effectiveHigherTfMime = "image/png";
    if (higherTfImageBase64 && typeof higherTfImageBase64 === "string") {
      const htfParsed = validateAndCleanBase64(
        higherTfImageBase64,
        higherTfMimeType,
        "\u09AC\u09A1\u09BC \u099F\u09BE\u0987\u09AE\u09AB\u09CD\u09B0\u09C7\u09AE \u099A\u09BE\u09B0\u09CD\u099F"
      );
      cleanHigherTfBase64 = htfParsed.cleanBase64;
      effectiveHigherTfMime = htfParsed.effectiveMime;
    }
    if (!ai || !apiKey) {
      res.status(503).json({
        error: "\u09B8\u09BE\u09B0\u09CD\u09AD\u09BE\u09B0 \u098F\u09A8\u09AD\u09BE\u09AF\u09BC\u09B0\u09A8\u09AE\u09C7\u09A8\u09CD\u099F\u09C7 \u099C\u09C7\u09AE\u09BF\u09A8\u09BF \u098F\u09AA\u09BF\u0986\u0987 \u0995\u09BF (GEMINI_API_KEY) \u0995\u09A8\u09AB\u09BF\u0997\u09BE\u09B0 \u0995\u09B0\u09BE \u09A8\u09C7\u0987\u0964 \u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u09B8\u09C7\u099F\u09BF\u0982\u09B8\u09C7 API Key \u09AF\u09C1\u0995\u09CD\u09A4 \u0995\u09B0\u09C1\u09A8\u0964"
      });
      return;
    }
    const hasHigherTf = Boolean(cleanHigherTfBase64);
    const systemInstruction = `You are a cautious, disciplined financial candlestick chart vision analyst and technical risk assessor.
When given screenshot(s) of financial candlestick charts (Quotex or similar trading platforms), analyze the visible price action and estimate whether the NEXT candle after the latest visible candle on the entry chart is more likely to be UP, DOWN, or NO TRADE.

ABSOLUTE REQUIREMENTS & CONFLUENCE VOTING RULES:
1. Examine ONLY what is visibly supported by the uploaded screenshot(s). Never invent prices, asset names, timeframe tags, candle values, or indicators (e.g. RSI, MACD, Volume) that cannot be clearly read.
2. Distinguish clearly between:
   - The current candle forming (if incomplete).
   - The latest completed visible candle.
   - The next candle that has not yet formed (the target of this estimate).
${hasHigherTf ? `3. MULTI-TIMEFRAME ANALYSIS:
   - Image 1 = Entry Chart (smaller timeframe).
   - Image 2 = Higher Timeframe Chart.
   Evaluate the major trend and key S/R levels on the Higher Timeframe Chart and vote "UP", "DOWN", or "NEUTRAL" in htf_vote. Use the Entry Chart for precise timing and immediate price action.` : ""}
4. CONFLUENCE VOTING FACTORS (Each votes "UP", "DOWN", or "NEUTRAL"):
   - Trend (trend_vote): Higher highs/lows for UP, lower highs/lows for DOWN, sideways/unclear for NEUTRAL.
   - Pattern & Wick Rejection (pattern_vote): Bullish engulfing, strong lower wick rejection for UP; bearish engulfing, strong upper wick rejection for DOWN; indecisive for NEUTRAL.
   - Support/Resistance & Price Action (sr_vote): Bounce from confirmed support/breakout for UP; rejection from confirmed resistance for DOWN; mid-range for NEUTRAL.
   ${hasHigherTf ? '- Higher Timeframe (htf_vote): Overall higher TF trend bias ("UP", "DOWN", or "NEUTRAL").' : ""}
   - Indicators (indicator_vote): Only if at least one indicator is legibly visible (RSI, MACD, Moving Average, Bollinger Bands). If none visible, leave indicators_visible as empty array and indicator_vote as "NEUTRAL".
5. LEVEL QUALITY & MOMENTUM OBSERVATIONS (Do not invent):
   - level_touch_count: How many times current S/R was tested ("1", "2", "3+", or "UNKNOWN").
   - level_strength: "STRONG", "MODERATE", "WEAK", or "UNKNOWN".
   - momentum: "INCREASING", "DECREASING", "FLAT", or "UNKNOWN" based on candle body progression. Shrinking bodies indicate exhaustion.
   - breakout_type: "REAL", "FAKE_SUSPECTED", or "NONE". If FAKE_SUSPECTED, note it in summary or conflicting_evidence.
6. RISK & MARKET ENVIRONMENT:
   - market_condition: "TRENDING", "RANGING", or "CHOPPY".
   - near_key_level: "RESISTANCE", "SUPPORT", or "NONE" (is current price directly at an immediate key barrier?).
7. LANGUAGE REQUIREMENT:
   \u09B8\u09AC \u09AC\u09B0\u09CD\u09A3\u09A8\u09BE\u09AE\u09C2\u09B2\u0995 \u099F\u09C7\u0995\u09CD\u09B8\u099F (summary, observations, supporting_evidence, conflicting_evidence, limitations, confidence_note, votes_reasoning, indicators_visible) \u09B8\u09B9\u099C \u09AC\u09BE\u0982\u09B2\u09BE\u09AF\u09BC \u09B2\u09BF\u0996\u09AC\u09C7; JSON-\u098F\u09B0 enum \u09AE\u09BE\u09A8 (UP, DOWN, NO TRADE, UPTREND, DOWNTREND, SIDEWAYS, UNCLEAR, GOOD, LIMITED, POOR, LOW, MODERATE, HIGH, TRENDING, RANGING, CHOPPY, RESISTANCE, SUPPORT, NONE, STRONG, MODERATE, WEAK, INCREASING, DECREASING, FLAT, REAL, FAKE_SUSPECTED, \u09AD\u09CB\u099F\u09C7\u09B0 \u099C\u09A8\u09CD\u09AF UP, DOWN, NEUTRAL) \u0987\u0982\u09B0\u09C7\u099C\u09BF\u09A4\u09C7\u0987 \u09B0\u09BE\u0996\u09AC\u09C7\u0964
8. Return strictly valid JSON adhering to the specified schema.`;
    const promptText = `Analyze this candlestick chart screenshot${hasHigherTf ? "s (Entry Chart and Higher Timeframe Chart)" : ""}.
Evaluate:
1. Chart legibility, image quality, and visible timeframe/asset.
2. Trend vote (trend_vote: UP, DOWN, or NEUTRAL).
3. Candlestick pattern / wick rejection vote (pattern_vote: UP, DOWN, or NEUTRAL).
4. Support & Resistance / price action vote (sr_vote: UP, DOWN, or NEUTRAL).
${hasHigherTf ? "5. Higher timeframe vote (htf_vote: UP, DOWN, or NEUTRAL)." : ""}
6. Clearly visible indicators (RSI, MACD, MA, etc.) if any, and indicator_vote (UP, DOWN, or NEUTRAL).
7. Level touch count, level strength, candle momentum (increasing/decreasing/flat), and breakout status.
8. Market condition (TRENDING, RANGING, CHOPPY) and proximity to immediate key level (RESISTANCE, SUPPORT, NONE).
9. Concise votes_reasoning in Bengali (1 line per factor).
10. Final next-candle estimate (UP, DOWN, or NO TRADE) and summary in clear Bengali.`;
    const contentParts = [];
    if (cleanHigherTfBase64) {
      contentParts.push(
        { text: "\u3010\u099B\u09AC\u09BF \u09E7: \u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF \u099A\u09BE\u09B0\u09CD\u099F (\u099B\u09CB\u099F \u099F\u09BE\u0987\u09AE\u09AB\u09CD\u09B0\u09C7\u09AE)\u3011" },
        {
          inlineData: {
            mimeType: effectiveMime,
            data: cleanBase64
          }
        },
        { text: "\u3010\u099B\u09AC\u09BF \u09E8: \u09AC\u09A1\u09BC \u099F\u09BE\u0987\u09AE\u09AB\u09CD\u09B0\u09C7\u09AE \u099A\u09BE\u09B0\u09CD\u099F (\u0990\u099A\u09CD\u099B\u09BF\u0995)\u3011" },
        {
          inlineData: {
            mimeType: effectiveHigherTfMime,
            data: cleanHigherTfBase64
          }
        }
      );
    } else {
      contentParts.push({
        inlineData: {
          mimeType: effectiveMime,
          data: cleanBase64
        }
      });
    }
    contentParts.push({ text: promptText });
    const executeVisionAnalysis = async () => {
      let lastError = null;
      for (const modelName of CANDIDATE_MODELS) {
        try {
          const config = {
            systemInstruction,
            temperature: 0.15,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                direction: {
                  type: Type.STRING,
                  description: "Direction estimate for next candle: UP, DOWN, or NO TRADE"
                },
                trend_vote: {
                  type: Type.STRING,
                  description: "Factor 1 Trend vote: UP, DOWN, or NEUTRAL"
                },
                pattern_vote: {
                  type: Type.STRING,
                  description: "Factor 2 Pattern / wick rejection vote: UP, DOWN, or NEUTRAL"
                },
                sr_vote: {
                  type: Type.STRING,
                  description: "Factor 3 Support/Resistance & price action vote: UP, DOWN, or NEUTRAL"
                },
                htf_vote: {
                  type: Type.STRING,
                  description: "Factor 4 Higher timeframe trend vote: UP, DOWN, or NEUTRAL (if HTF provided)"
                },
                indicator_vote: {
                  type: Type.STRING,
                  description: "Factor 5 Indicator vote: UP, DOWN, or NEUTRAL (if visible)"
                },
                indicators_visible: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "List of clearly visible indicators and their read states in Bengali"
                },
                votes_reasoning: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "1-line Bengali reasoning for each factor vote"
                },
                summary: {
                  type: Type.STRING,
                  description: "Concise explanation of the estimate in Bengali based only on visible evidence"
                },
                trend: {
                  type: Type.STRING,
                  description: "Visible trend: UPTREND, DOWNTREND, SIDEWAYS, or UNCLEAR"
                },
                observations: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Specific candlestick and structural observations in Bengali visibly present in the screenshot"
                },
                supporting_evidence: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Visible evidence in Bengali that supports the directional estimate"
                },
                conflicting_evidence: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Contradictory evidence, counter-trend risks, or uncertainties in Bengali"
                },
                image_quality: {
                  type: Type.STRING,
                  description: "Quality of the uploaded screenshot: GOOD, LIMITED, or POOR"
                },
                timeframe: {
                  type: Type.STRING,
                  description: "Visible chart timeframe (e.g. 1M, 5S, 1H) or UNKNOWN if unreadable"
                },
                confidence_label: {
                  type: Type.STRING,
                  description: "Uncalibrated alignment label: LOW, MODERATE, or HIGH"
                },
                confidence_note: {
                  type: Type.STRING,
                  description: "Clear statement in Bengali that this is an uncalibrated visual assessment"
                },
                limitations: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Important limitations in Bengali of this particular static screenshot"
                },
                level_touch_count: {
                  type: Type.STRING,
                  description: 'Touch count of active S/R level (e.g. "1", "2", "3+", or "UNKNOWN")'
                },
                level_strength: {
                  type: Type.STRING,
                  description: "Strength of current level: STRONG, MODERATE, WEAK, or UNKNOWN"
                },
                momentum: {
                  type: Type.STRING,
                  description: "Candle momentum over last 5-10 candles: INCREASING, DECREASING, FLAT, or UNKNOWN"
                },
                breakout_type: {
                  type: Type.STRING,
                  description: "Breakout classification: REAL, FAKE_SUSPECTED, or NONE"
                },
                market_condition: {
                  type: Type.STRING,
                  description: "Overall market structure: TRENDING, RANGING, or CHOPPY"
                },
                near_key_level: {
                  type: Type.STRING,
                  description: "Price proximity to key level: RESISTANCE, SUPPORT, or NONE"
                }
              },
              required: [
                "direction",
                "trend_vote",
                "pattern_vote",
                "sr_vote",
                "summary",
                "trend",
                "observations",
                "supporting_evidence",
                "conflicting_evidence",
                "image_quality",
                "timeframe",
                "confidence_label",
                "confidence_note",
                "limitations",
                "level_strength",
                "momentum",
                "breakout_type",
                "market_condition",
                "near_key_level"
              ]
            }
          };
          if (modelName === "gemini-3.8-flash") {
            config.thinkingConfig = {
              thinkingLevel: ThinkingLevel.LOW
            };
          }
          const response2 = await ai.models.generateContent({
            model: modelName,
            contents: {
              parts: contentParts
            },
            config
          });
          return response2;
        } catch (err) {
          lastError = err;
        }
      }
      throw lastError || new Error("All vision models are currently unavailable.");
    };
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => {
        reject(new Error("TIMEOUT_EXCEEDED"));
      }, 26e3);
    });
    const response = await Promise.race([executeVisionAnalysis(), timeoutPromise]);
    const textOutput = response.text || "";
    if (!textOutput) {
      throw new Error("Empty response received from vision model.");
    }
    let cleanJsonText = textOutput.trim();
    if (cleanJsonText.startsWith("```")) {
      cleanJsonText = cleanJsonText.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
    }
    const parsedJson = JSON.parse(cleanJsonText);
    let image_quality = "LIMITED";
    const rawQual = String(parsedJson.image_quality || "").toUpperCase().trim();
    if (rawQual === "GOOD") image_quality = "GOOD";
    else if (rawQual === "POOR") image_quality = "POOR";
    let trend = "UNCLEAR";
    const rawTrend = String(parsedJson.trend || "").toUpperCase().trim();
    if (rawTrend === "UPTREND") trend = "UPTREND";
    else if (rawTrend === "DOWNTREND") trend = "DOWNTREND";
    else if (rawTrend === "SIDEWAYS") trend = "SIDEWAYS";
    let confidence_label = "LOW";
    const rawConf = String(parsedJson.confidence_label || "").toUpperCase().trim();
    if (rawConf === "HIGH") confidence_label = "HIGH";
    else if (rawConf === "MODERATE") confidence_label = "MODERATE";
    const sanitizeVote = (val) => {
      const v = String(val || "").toUpperCase().trim();
      if (v === "UP") return "UP";
      if (v === "DOWN") return "DOWN";
      return "NEUTRAL";
    };
    const trend_vote = sanitizeVote(parsedJson.trend_vote);
    const pattern_vote = sanitizeVote(parsedJson.pattern_vote);
    const sr_vote = sanitizeVote(parsedJson.sr_vote);
    let htf_vote = void 0;
    if (hasHigherTf && parsedJson.htf_vote) {
      htf_vote = sanitizeVote(parsedJson.htf_vote);
    }
    const indicators_visible = Array.isArray(parsedJson.indicators_visible) ? parsedJson.indicators_visible.map(String).filter((s) => s.trim().length > 0) : [];
    let indicator_vote = void 0;
    if (indicators_visible.length > 0 && parsedJson.indicator_vote) {
      indicator_vote = sanitizeVote(parsedJson.indicator_vote);
    }
    let level_strength = "UNKNOWN";
    const rawStrength = String(parsedJson.level_strength || "").toUpperCase().trim();
    if (["STRONG", "MODERATE", "WEAK"].includes(rawStrength)) {
      level_strength = rawStrength;
    }
    let momentum = "UNKNOWN";
    const rawMomentum = String(parsedJson.momentum || "").toUpperCase().trim();
    if (["INCREASING", "DECREASING", "FLAT"].includes(rawMomentum)) {
      momentum = rawMomentum;
    }
    let breakout_type = "NONE";
    const rawBreakout = String(parsedJson.breakout_type || "").toUpperCase().trim();
    if (["REAL", "FAKE_SUSPECTED"].includes(rawBreakout)) {
      breakout_type = rawBreakout;
    }
    const level_touch_count = String(parsedJson.level_touch_count || "UNKNOWN");
    let market_condition = "RANGING";
    const rawMarket = String(parsedJson.market_condition || "").toUpperCase().trim();
    if (rawMarket === "TRENDING") market_condition = "TRENDING";
    else if (rawMarket === "CHOPPY") market_condition = "CHOPPY";
    let near_key_level = "NONE";
    const rawKeyLevel = String(parsedJson.near_key_level || "").toUpperCase().trim();
    if (rawKeyLevel === "RESISTANCE") near_key_level = "RESISTANCE";
    else if (rawKeyLevel === "SUPPORT") near_key_level = "SUPPORT";
    const participatingFactors = [
      { name: "\u099F\u09CD\u09B0\u09C7\u09A8\u09CD\u09A1", vote: trend_vote },
      { name: "\u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8", vote: pattern_vote },
      { name: "S/R", vote: sr_vote }
    ];
    if (htf_vote) {
      participatingFactors.push({ name: "\u09AC\u09A1\u09BC \u099F\u09BE\u0987\u09AE\u09AB\u09CD\u09B0\u09C7\u09AE", vote: htf_vote });
    }
    if (indicator_vote) {
      participatingFactors.push({ name: "\u0987\u09A8\u09CD\u09A1\u09BF\u0995\u09C7\u099F\u09B0", vote: indicator_vote });
    }
    const N = participatingFactors.length;
    const threshold = Math.ceil(2 / 3 * N);
    const upVotes = participatingFactors.filter((f) => f.vote === "UP").length;
    const downVotes = participatingFactors.filter((f) => f.vote === "DOWN").length;
    const neutralVotes = participatingFactors.filter((f) => f.vote === "NEUTRAL").length;
    let computedDirection = "NO TRADE";
    if (image_quality === "POOR") {
      computedDirection = "NO TRADE";
    } else if (upVotes >= threshold) {
      computedDirection = "UP";
    } else if (downVotes >= threshold) {
      computedDirection = "DOWN";
    } else {
      computedDirection = "NO TRADE";
    }
    if (computedDirection === "UP" && downVotes > 0 || computedDirection === "DOWN" && upVotes > 0) {
      if (confidence_label === "HIGH") {
        confidence_label = "MODERATE";
      }
    }
    const limitations = Array.isArray(parsedJson.limitations) ? parsedJson.limitations.map(String) : [];
    if (image_quality === "POOR" && computedDirection === "NO TRADE") {
      limitations.unshift(
        "\u099B\u09AC\u09BF\u09B0 \u09AE\u09BE\u09A8 \u0985\u09B8\u09CD\u09AA\u09B7\u09CD\u099F \u09AC\u09BE \u09A4\u09CD\u09B0\u09C1\u099F\u09BF\u09AA\u09C2\u09B0\u09CD\u09A3 (POOR) \u09B9\u0993\u09AF\u09BC\u09BE\u09AF\u09BC \u0995\u09A8\u09AB\u09CD\u09B2\u09C1\u09AF\u09BC\u09C7\u09A8\u09CD\u09B8 \u09A8\u09BF\u09AF\u09BC\u09AE\u09BE\u09A8\u09C1\u09AF\u09BE\u09AF\u09BC\u09C0 NO TRADE \u09B8\u09BF\u09A6\u09CD\u09A7\u09BE\u09A8\u09CD\u09A4 \u09A6\u09C7\u0993\u09AF\u09BC\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964"
      );
    }
    if (market_condition === "CHOPPY") {
      computedDirection = "NO TRADE";
      limitations.unshift(
        "\u09AC\u09BE\u099C\u09BE\u09B0 \u0985\u09A4\u09CD\u09AF\u09A8\u09CD\u09A4 \u099A\u09AA\u09BF/\u098F\u09B2\u09CB\u09AE\u09C7\u09B2\u09CB (CHOPPY) \u09B9\u0993\u09AF\u09BC\u09BE\u09AF\u09BC \u099D\u09C1\u0981\u0995\u09BF\u09B0 \u0995\u09A0\u09CB\u09B0 \u09A8\u09BF\u09AF\u09BC\u09AE\u09C7 \u099F\u09CD\u09B0\u09C7\u09A1 \u09AC\u09BE\u09A4\u09BF\u09B2 (NO TRADE) \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964"
      );
    }
    if (computedDirection === "UP" && near_key_level === "RESISTANCE") {
      computedDirection = "NO TRADE";
      limitations.unshift(
        "\u09AE\u09C2\u09B2\u09CD\u09AF \u09A4\u09BE\u09CE\u0995\u09CD\u09B7\u09A3\u09BF\u0995 \u09AA\u09CD\u09B0\u09A7\u09BE\u09A8 \u09B0\u09C7\u099C\u09BF\u09B8\u09CD\u099F\u09CD\u09AF\u09BE\u09A8\u09CD\u09B8\u09C7\u09B0 (RESISTANCE) \u0996\u09C1\u09AC \u0995\u09BE\u099B\u09C7 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u0995\u09B0\u09BE\u09AF\u09BC UP \u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF \u09AC\u09BF\u09AA\u099C\u09CD\u099C\u09A8\u0995 \u09AC\u09BF\u09A7\u09BE\u09AF\u09BC NO TRADE \u09A8\u09BF\u09B0\u09CD\u09A7\u09BE\u09B0\u09A3 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964"
      );
    }
    if (computedDirection === "DOWN" && near_key_level === "SUPPORT") {
      computedDirection = "NO TRADE";
      limitations.unshift(
        "\u09AE\u09C2\u09B2\u09CD\u09AF \u09A4\u09BE\u09CE\u0995\u09CD\u09B7\u09A3\u09BF\u0995 \u09AA\u09CD\u09B0\u09A7\u09BE\u09A8 \u09B8\u09BE\u09AA\u09CB\u09B0\u09CD\u099F\u09C7\u09B0 (SUPPORT) \u0996\u09C1\u09AC \u0995\u09BE\u099B\u09C7 \u0985\u09AC\u09B8\u09CD\u09A5\u09BE\u09A8 \u0995\u09B0\u09BE\u09AF\u09BC DOWN \u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF \u09AC\u09BF\u09AA\u099C\u09CD\u099C\u09A8\u0995 \u09AC\u09BF\u09A7\u09BE\u09AF\u09BC NO TRADE \u09A8\u09BF\u09B0\u09CD\u09A7\u09BE\u09B0\u09A3 \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964"
      );
    }
    if (breakout_type === "FAKE_SUSPECTED") {
      limitations.unshift("\u09AC\u09CD\u09B0\u09C7\u0995\u0986\u0989\u099F\u099F\u09BF \u09AB\u09C7\u0995\u0986\u0989\u099F (Fake Breakout) \u09B9\u0993\u09AF\u09BC\u09BE\u09B0 \u0986\u09B6\u0999\u09CD\u0995\u09BE \u09B0\u09AF\u09BC\u09C7\u099B\u09C7\u0964");
    }
    const elapsedMs = Date.now() - startTime;
    let counter_argument = void 0;
    let review_verdict = "SKIPPED";
    if (elapsedMs <= 14e3) {
      try {
        const reviewTimeoutMs = Math.min(6500, Math.max(2e3, 22e3 - elapsedMs));
        const reviewSystemInstruction = `You are a skeptical, strict financial market risk auditor.
Your job is to audit the initial technical analysis and formulate the strongest counter-argument against the initial bias.
RULES:
1. Provide the single strongest counter-argument in 1-2 lines of simple Bengali (counter_argument).
2. Choose verdict strictly from: "KEPT", "DOWNGRADED", or "NO_TRADE".
   - "KEPT": Initial decision is solid with no fatal flaws.
   - "DOWNGRADED": Noticeable counter-risk exists; downgrade confidence by one level.
   - "NO_TRADE": High-risk trap, major conflicting wick, or lack of momentum makes it unsafe.
3. You can NEVER reverse direction (cannot turn UP into DOWN or DOWN into UP). You can NEVER change NO TRADE into UP or DOWN.
4. Return strictly valid JSON adhering to the specified schema.`;
        const reviewPrompt = `Initial Analysis Result:
Direction: ${computedDirection}
Confidence: ${confidence_label}
Summary: ${parsedJson.summary}
Trend: ${trend}
Votes: ${participatingFactors.map((p) => `${p.name}: ${p.vote}`).join(", ")}
Market: ${market_condition}
Key Level Proximity: ${near_key_level}

Audit this decision. Give the strongest counter-argument in 1-2 lines in Bengali and return verdict ("KEPT", "DOWNGRADED", or "NO_TRADE").`;
        const reviewSchema = {
          type: Type.OBJECT,
          properties: {
            counter_argument: {
              type: Type.STRING,
              description: "Strongest counter-argument against initial estimate in 1-2 lines in Bengali"
            },
            verdict: {
              type: Type.STRING,
              description: "Audit verdict: KEPT, DOWNGRADED, or NO_TRADE"
            }
          },
          required: ["counter_argument", "verdict"]
        };
        const executeReview = async () => {
          const modelName = CANDIDATE_MODELS[0] || "gemini-3.1-flash-lite";
          const reviewConfig = {
            systemInstruction: reviewSystemInstruction,
            temperature: 0.1,
            responseMimeType: "application/json",
            responseSchema: reviewSchema
          };
          if (modelName === "gemini-3.8-flash") {
            reviewConfig.thinkingConfig = { thinkingLevel: ThinkingLevel.LOW };
          }
          return await ai.models.generateContent({
            model: modelName,
            contents: {
              parts: [...contentParts.filter((p) => p.inlineData), { text: reviewPrompt }]
            },
            config: reviewConfig
          });
        };
        const reviewTimeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error("REVIEW_TIMEOUT")), reviewTimeoutMs);
        });
        const reviewResponse = await Promise.race([executeReview(), reviewTimeoutPromise]);
        const reviewText = reviewResponse.text || "";
        let cleanReviewJson = reviewText.trim();
        if (cleanReviewJson.startsWith("```")) {
          cleanReviewJson = cleanReviewJson.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "").trim();
        }
        const parsedReview = JSON.parse(cleanReviewJson);
        counter_argument = String(parsedReview.counter_argument || "");
        const rawVerdict = String(parsedReview.verdict || "").toUpperCase().trim();
        if (rawVerdict === "NO_TRADE") {
          if (computedDirection !== "NO TRADE") {
            computedDirection = "NO TRADE";
            limitations.unshift("\u09A6\u09CD\u09AC\u09BF\u09A4\u09C0\u09AF\u09BC \u09A7\u09BE\u09AA\u09C7\u09B0 \u0986\u09A4\u09CD\u09AE-\u09AA\u09B0\u09CD\u09AF\u09BE\u09B2\u09CB\u099A\u09A8\u09BE\u09AF\u09BC \u0985\u09A4\u09BF\u09B0\u09BF\u0995\u09CD\u09A4 \u099D\u09C1\u0981\u0995\u09BF \u099A\u09BF\u09B9\u09CD\u09A8\u09BF\u09A4 \u09B9\u0993\u09AF\u09BC\u09BE\u09AF\u09BC \u09B8\u09BF\u09A6\u09CD\u09A7\u09BE\u09A8\u09CD\u09A4 NO TRADE \u0995\u09B0\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964");
          }
          review_verdict = "NO_TRADE";
        } else if (rawVerdict === "DOWNGRADED") {
          review_verdict = "DOWNGRADED";
          if (confidence_label === "HIGH") confidence_label = "MODERATE";
          else if (confidence_label === "MODERATE") confidence_label = "LOW";
        } else {
          review_verdict = "KEPT";
        }
      } catch (reviewErr) {
        console.warn("Review phase timed out or bypassed, continuing with primary result:", reviewErr);
        review_verdict = "SKIPPED";
      }
    } else {
      review_verdict = "SKIPPED";
      limitations.unshift("\u09B8\u09AE\u09AF\u09BC\u09B8\u09CD\u09AC\u09B2\u09CD\u09AA\u09A4\u09BE\u09B0 \u0995\u09BE\u09B0\u09A3\u09C7 \u09A6\u09CD\u09AC\u09BF\u09A4\u09C0\u09AF\u09BC \u09A7\u09BE\u09AA\u09C7\u09B0 \u09AA\u09B0\u09CD\u09AF\u09BE\u09B2\u09CB\u099A\u09A8\u09BE \u09AC\u09BE\u09A6 \u09A6\u09C7\u0993\u09AF\u09BC\u09BE \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964");
    }
    const votes_reasoning = Array.isArray(parsedJson.votes_reasoning) ? parsedJson.votes_reasoning.map(String) : [];
    const normalizedAnalysis = {
      direction: computedDirection,
      trend_vote,
      pattern_vote,
      sr_vote,
      htf_vote,
      indicator_vote,
      indicators_visible,
      votes_reasoning,
      counter_argument,
      review_verdict,
      level_touch_count,
      level_strength,
      momentum,
      breakout_type,
      market_condition,
      near_key_level,
      summary: String(parsedJson.summary || "\u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3 \u09B8\u09AE\u09CD\u09AA\u09A8\u09CD\u09A8 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964"),
      trend,
      observations: Array.isArray(parsedJson.observations) ? parsedJson.observations.map(String) : [],
      supporting_evidence: Array.isArray(parsedJson.supporting_evidence) ? parsedJson.supporting_evidence.map(String) : [],
      conflicting_evidence: Array.isArray(parsedJson.conflicting_evidence) ? parsedJson.conflicting_evidence.map(String) : [],
      image_quality,
      timeframe: String(parsedJson.timeframe || "UNKNOWN"),
      confidence_label,
      confidence_note: String(parsedJson.confidence_note || "\u0985\u09B8\u09AE\u09B0\u09CD\u09A5\u09BF\u09A4 \u09AD\u09BF\u099C\u09CD\u09AF\u09C1\u09AF\u09BC\u09BE\u09B2 \u09AE\u09C2\u09B2\u09CD\u09AF\u09BE\u09AF\u09BC\u09A8, \u098F\u099F\u09BF \u09A8\u09BF\u09B6\u09CD\u099A\u09BF\u09A4 \u09B8\u09BE\u09AB\u09B2\u09CD\u09AF\u09C7\u09B0 \u09B8\u09AE\u09CD\u09AD\u09BE\u09AC\u09A8\u09BE \u09A8\u09AF\u09BC\u0964"),
      limitations
    };
    res.json({
      success: true,
      analysis: normalizedAnalysis,
      timestamp: Date.now()
    });
  } catch (error) {
    console.error("Server chart analysis error:", error);
    if (error?.message === "TIMEOUT_EXCEEDED") {
      res.status(504).json({
        error: "\u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3\u09C7\u09B0 \u09B8\u09AE\u09AF\u09BC\u09B8\u09C0\u09AE\u09BE (\u09E8\u09EB \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1) \u0985\u09A4\u09BF\u0995\u09CD\u09B0\u09AE \u0995\u09B0\u09C7\u099B\u09C7\u0964 \u09AD\u09BF\u09B6\u09A8 \u09AE\u09A1\u09C7\u09B2 \u09AA\u09CD\u09B0\u0995\u09CD\u09B0\u09BF\u09AF\u09BC\u09BE \u0995\u09B0\u09A4\u09C7 \u0985\u09A4\u09BF\u09B0\u09BF\u0995\u09CD\u09A4 \u09B8\u09AE\u09AF\u09BC \u09A8\u09BF\u09AF\u09BC\u09C7\u099B\u09C7\u0964 \u0985\u09A8\u09C1\u0997\u09CD\u09B0\u09B9 \u0995\u09B0\u09C7 \u09B8\u09CD\u09AA\u09B7\u09CD\u099F \u0993 \u0995\u09CD\u09B0\u09AA \u0995\u09B0\u09BE \u099A\u09BE\u09B0\u09CD\u099F \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09B6\u099F \u09A6\u09BF\u09AF\u09BC\u09C7 \u09AA\u09C1\u09A8\u09B0\u09BE\u09AF\u09BC \u099A\u09C7\u09B7\u09CD\u099F\u09BE \u0995\u09B0\u09C1\u09A8\u0964"
      });
      return;
    }
    let errorMsg = error?.message || "\u099A\u09BE\u09B0\u09CD\u099F \u09B8\u09CD\u0995\u09CD\u09B0\u09BF\u09A8\u09B6\u099F \u09AC\u09BF\u09B6\u09CD\u09B2\u09C7\u09B7\u09A3 \u09AC\u09CD\u09AF\u09B0\u09CD\u09A5 \u09B9\u09AF\u09BC\u09C7\u099B\u09C7\u0964";
    try {
      const parsed = JSON.parse(errorMsg);
      if (parsed?.error?.message) {
        errorMsg = parsed.error.message;
      }
    } catch {
    }
    res.status(500).json({
      error: errorMsg
    });
  }
};
app.post("/api/analyze", handleAnalyzeChart);
app.post("/api/analyze-chart", handleAnalyzeChart);
app.all("/api/*", (req, res) => {
  res.status(404).json({
    error: `API route ${req.method} ${req.path} not found.`
  });
});
async function startServer() {
  const isDev = process.env.NODE_ENV !== "production";
  if (isDev) {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.resolve(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Quotex AI server running at http://0.0.0.0:${PORT} [${isDev ? "development" : "production"}]`);
  });
}
startServer().catch((err) => {
  console.error("Fatal server start error:", err);
  process.exit(1);
});
