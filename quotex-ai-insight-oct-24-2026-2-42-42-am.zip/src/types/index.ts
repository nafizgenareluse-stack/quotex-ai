export type Direction = 'UP' | 'DOWN' | 'NO TRADE';
export type Trend = 'UPTREND' | 'DOWNTREND' | 'SIDEWAYS' | 'UNCLEAR';
export type ImageQuality = 'GOOD' | 'LIMITED' | 'POOR';
export type ConfidenceLabel = 'LOW' | 'MODERATE' | 'HIGH';
export type Vote = 'UP' | 'DOWN' | 'NEUTRAL';
export type Outcome = 'CORRECT' | 'WRONG' | 'PENDING';

// Update 2: Review verdict
export type ReviewVerdict = 'KEPT' | 'DOWNGRADED' | 'NO_TRADE' | 'SKIPPED';

// Update 4: Level strength and momentum
export type LevelStrength = 'STRONG' | 'MODERATE' | 'WEAK' | 'UNKNOWN';
export type Momentum = 'INCREASING' | 'DECREASING' | 'FLAT' | 'UNKNOWN';
export type BreakoutType = 'REAL' | 'FAKE_SUSPECTED' | 'NONE';

// Update 5: Market condition and key level proximity
export type MarketCondition = 'TRENDING' | 'RANGING' | 'CHOPPY';
export type NearKeyLevel = 'RESISTANCE' | 'SUPPORT' | 'NONE';

export interface AnalysisResult {
  direction: Direction;
  summary: string;
  trend: Trend;
  observations: string[];
  supporting_evidence: string[];
  conflicting_evidence: string[];
  image_quality: ImageQuality;
  timeframe: string;
  confidence_label: ConfidenceLabel;
  confidence_note: string;
  limitations: string[];

  // Confluence 3-factor votes (optional for backward compatibility)
  trend_vote?: Vote;
  pattern_vote?: Vote;
  sr_vote?: Vote;
  votes_reasoning?: string[];

  // Update 1: Higher Timeframe vote
  htf_vote?: Vote;

  // Update 2: Self-Review
  counter_argument?: string;
  review_verdict?: ReviewVerdict;

  // Update 3: Indicators
  indicators_visible?: string[];
  indicator_vote?: Vote;

  // Update 4: Level quality & momentum
  level_touch_count?: string;
  level_strength?: LevelStrength;
  momentum?: Momentum;
  breakout_type?: BreakoutType;

  // Update 5: Market condition & near key level
  market_condition?: MarketCondition;
  near_key_level?: NearKeyLevel;
}

export interface HistoryRecord {
  id: string;
  timestamp: number;
  imageDataUrl: string;
  thumbnailDataUrl: string;
  analysis: AnalysisResult;
  // Outcome verification (optional, defaults to 'PENDING')
  outcome?: Outcome;
  // Update 1: Optional higher timeframe image and thumbnail
  higherTfImageDataUrl?: string;
  higherTfThumbnailDataUrl?: string;
}

export type Theme = 'dark' | 'light';

export type NavTab = 'analyze' | 'history' | 'live';


