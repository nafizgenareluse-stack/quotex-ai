import { LiveHistoryRecord, LiveOutcome } from '../types/live';

const DB_NAME = 'quotex_ai_live_db';
const DB_VERSION = 1;
const STORE_NAME = 'live_signals';

function openLiveDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not supported in this browser environment.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt', { unique: false });
        store.createIndex('outcome', 'outcome', { unique: false });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error || new Error('Failed to open live database.'));
    };
  });
}

export async function saveLiveSignalRecord(record: LiveHistoryRecord): Promise<void> {
  try {
    const db = await openLiveDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(record);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to save live signal record:', err);
  }
}

export async function getLiveHistoryRecords(): Promise<LiveHistoryRecord[]> {
  try {
    const db = await openLiveDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();

      req.onsuccess = () => {
        const results = (req.result as LiveHistoryRecord[]) || [];
        // Sort newest first
        results.sort((a, b) => b.createdAt - a.createdAt);
        resolve(results);
      };

      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to get live history records:', err);
    return [];
  }
}

export async function updateLiveSignalOutcome(
  id: string,
  outcome: LiveOutcome,
  resolvedClosePrice?: number,
  resolvedOpenPrice?: number
): Promise<void> {
  try {
    const db = await openLiveDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const getReq = store.get(id);

      getReq.onsuccess = () => {
        const record = getReq.result as LiveHistoryRecord;
        if (!record) {
          resolve();
          return;
        }

        record.outcome = outcome;
        if (resolvedClosePrice !== undefined) record.resolvedClosePrice = resolvedClosePrice;
        if (resolvedOpenPrice !== undefined) record.resolvedOpenPrice = resolvedOpenPrice;
        record.resolvedAt = Date.now();

        const updateReq = store.put(record);
        updateReq.onsuccess = () => resolve();
        updateReq.onerror = () => reject(updateReq.error);
      };

      getReq.onerror = () => reject(getReq.error);
    });
  } catch (err) {
    console.error('Failed to update live signal outcome:', err);
  }
}

export async function deleteLiveSignalRecord(id: string): Promise<void> {
  try {
    const db = await openLiveDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(id);

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to delete live signal record:', err);
  }
}

export async function clearAllLiveSignals(): Promise<void> {
  try {
    const db = await openLiveDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.clear();

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to clear all live signals:', err);
  }
}
