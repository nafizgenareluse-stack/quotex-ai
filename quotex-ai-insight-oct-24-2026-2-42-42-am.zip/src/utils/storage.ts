import { HistoryRecord, Theme } from '../types';

const THEME_KEY = 'quotex_ai_theme';
const DB_NAME = 'quotex_ai_db';
const DB_VERSION = 1;
const STORE_NAME = 'history_records';

/**
 * Theme persistence
 */
export function getStoredTheme(): Theme {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') {
      return saved;
    }
  } catch {
    // ignore
  }
  return 'dark'; // Dark mode default as specified
}

export function setStoredTheme(theme: Theme): void {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (err) {
    console.warn('Failed to save theme to localStorage:', err);
  }
}

/**
 * IndexedDB helper for robust, quota-friendly local persistence
 */
function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not supported in this environment.'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error || new Error('Failed to open database.'));
    };
  });
}

/**
 * Retrieve all saved analysis history records, ordered descending by timestamp
 */
export async function getAllHistory(): Promise<HistoryRecord[]> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const index = store.index('timestamp');
      const request = index.openCursor(null, 'prev'); // Most recent first
      const results: HistoryRecord[] = [];

      request.onsuccess = (event) => {
        const cursor = (event.target as IDBRequest<IDBCursorWithValue>).result;
        if (cursor) {
          results.push(cursor.value);
          cursor.continue();
        } else {
          resolve(results);
        }
      };

      request.onerror = () => {
        reject(request.error || new Error('Failed to fetch history records.'));
      };
    });
  } catch (err) {
    console.error('IndexedDB getAllHistory error:', err);
    // Fallback to localStorage if IndexedDB is blocked
    return getLocalStorageFallbackHistory();
  }
}

/**
 * Get single history record by ID
 */
export async function getHistoryRecord(id: string): Promise<HistoryRecord | null> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        reject(request.error || new Error(`Failed to fetch record ${id}.`));
      };
    });
  } catch (err) {
    console.error('IndexedDB getHistoryRecord error:', err);
    const records = getLocalStorageFallbackHistory();
    return records.find((r) => r.id === id) || null;
  }
}

/**
 * Save an analysis record to IndexedDB
 */
export async function saveHistoryRecord(record: HistoryRecord): Promise<void> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.put(record);

      request.onsuccess = () => {
        resolve();
      };

      request.onerror = () => {
        const error = request.error;
        if (error && error.name === 'QuotaExceededError') {
          reject(new Error('Storage quota exceeded. Please delete some previous history records.'));
        } else {
          reject(error || new Error('Failed to save record to storage.'));
        }
      };
    });
  } catch (err: any) {
    console.error('IndexedDB saveHistoryRecord error:', err);
    // If quota or IndexedDB fails, attempt safe localStorage fallback
    try {
      saveLocalStorageFallbackHistory(record);
    } catch (fallbackErr: any) {
      throw new Error(err?.message || 'Failed to save to local storage.');
    }
  }
}

/**
 * Delete an individual record from IndexedDB
 */
export async function deleteHistoryRecord(id: string): Promise<void> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.delete(id);

      request.onsuccess = () => {
        resolve();
      };

      request.onerror = () => {
        reject(request.error || new Error(`Failed to delete record ${id}.`));
      };
    });
  } catch (err) {
    console.error('IndexedDB deleteHistoryRecord error:', err);
    deleteLocalStorageFallbackHistory(id);
  }
}

/**
 * Update outcome for an existing record
 */
export async function updateHistoryRecordOutcome(
  id: string,
  outcome: 'CORRECT' | 'WRONG' | 'PENDING'
): Promise<void> {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const request = store.get(id);

      request.onsuccess = () => {
        const record = request.result as HistoryRecord | undefined;
        if (!record) {
          updateLocalStorageFallbackOutcome(id, outcome);
          resolve();
          return;
        }
        record.outcome = outcome;
        const putRequest = store.put(record);
        putRequest.onsuccess = () => {
          updateLocalStorageFallbackOutcome(id, outcome);
          resolve();
        };
        putRequest.onerror = () => {
          reject(putRequest.error || new Error(`Failed to update record ${id}.`));
        };
      };

      request.onerror = () => {
        reject(request.error || new Error(`Failed to get record ${id} for outcome update.`));
      };
    });
  } catch (err) {
    console.error('IndexedDB updateHistoryRecordOutcome error:', err);
    updateLocalStorageFallbackOutcome(id, outcome);
  }
}


/**
 * Resize and compress image data URL to max dimension (e.g. 1400px) as JPEG (0.85)
 */
export function compressImage(dataUrl: string, maxDim: number = 1400, quality: number = 0.85): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      } else {
        resolve(dataUrl);
      }
    };
    img.onerror = () => {
      resolve(dataUrl);
    };
    img.src = dataUrl;
  });
}

/**
 * Generate a thumbnail data URL from an image data URL (max width/height 320px)
 */
export function createThumbnail(dataUrl: string, maxDim: number = 320): Promise<string> {

  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        }
      } else {
        if (height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'medium';
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      } else {
        resolve(dataUrl);
      }
    };
    img.onerror = () => {
      resolve(dataUrl);
    };
    img.src = dataUrl;
  });
}

/**
 * LocalStorage fallback helpers
 */
const FALLBACK_STORAGE_KEY = 'quotex_ai_fallback_history';

function getLocalStorageFallbackHistory(): HistoryRecord[] {
  try {
    const raw = localStorage.getItem(FALLBACK_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveLocalStorageFallbackHistory(record: HistoryRecord): void {
  const current = getLocalStorageFallbackHistory();
  // Filter out any duplicate ID
  const filtered = current.filter((r) => r.id !== record.id);
  filtered.unshift(record);
  // Cap at 20 in fallback to avoid localStorage quota
  if (filtered.length > 20) filtered.length = 20;
  localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(filtered));
}

function deleteLocalStorageFallbackHistory(id: string): void {
  try {
    const current = getLocalStorageFallbackHistory();
    const filtered = current.filter((r) => r.id !== id);
    localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(filtered));
  } catch {
    // ignore
  }
}

function updateLocalStorageFallbackOutcome(id: string, outcome: 'CORRECT' | 'WRONG' | 'PENDING'): void {
  try {
    const current = getLocalStorageFallbackHistory();
    const updated = current.map((r) => (r.id === id ? { ...r, outcome } : r));
    localStorage.setItem(FALLBACK_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
}

