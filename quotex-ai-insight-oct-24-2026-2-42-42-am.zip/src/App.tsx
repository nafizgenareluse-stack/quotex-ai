import React, { useState, useEffect } from 'react';
import { HistoryRecord, NavTab, Theme } from './types';
import {
  getAllHistory,
  deleteHistoryRecord,
  updateHistoryRecordOutcome,
  getStoredTheme,
  setStoredTheme,
} from './utils/storage';
import { TopAppBar } from './components/TopAppBar';
import { BottomNav } from './components/BottomNav';
import { AnalyzeView } from './components/AnalyzeView';
import { HistoryView } from './components/HistoryView';
import { LiveView } from './components/LiveView';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('analyze');
  const [theme, setTheme] = useState<Theme>(getStoredTheme);
  const [history, setHistory] = useState<HistoryRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState<boolean>(true);

  // Sync theme with HTML document class and storage
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
    setStoredTheme(theme);
  }, [theme]);

  // Load history from IndexedDB on startup
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        const records = await getAllHistory();
        if (isMounted) {
          setHistory(records);
        }
      } catch (err) {
        console.error('Failed to load history from IndexedDB:', err);
      } finally {
        if (isMounted) {
          setIsLoadingHistory(false);
        }
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleRecordSaved = (newRecord: HistoryRecord) => {
    setHistory((prev) => [newRecord, ...prev.filter((r) => r.id !== newRecord.id)]);
  };

  const handleDeleteRecord = async (id: string) => {
    await deleteHistoryRecord(id);
    setHistory((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateOutcome = async (id: string, outcome: 'CORRECT' | 'WRONG' | 'PENDING') => {
    await updateHistoryRecordOutcome(id, outcome);
    setHistory((prev) =>
      prev.map((r) => (r.id === id ? { ...r, outcome } : r))
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0B111E] text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      {/* 1. Header: Exactly "Quotex AI" + Theme Toggle */}
      <TopAppBar theme={theme} onToggleTheme={handleToggleTheme} />

      {/* 2. Main Container with EXACTLY TWO pages */}
      <main className="flex-1 w-full">
        {currentTab === 'analyze' && (
          <AnalyzeView onRecordSaved={handleRecordSaved} history={history} />
        )}

        {currentTab === 'live' && <LiveView />}

        {currentTab === 'history' && (
          <HistoryView
            history={history}
            onDeleteRecord={handleDeleteRecord}
            onUpdateOutcome={handleUpdateOutcome}
          />
        )}
      </main>


      {/* 3. Bottom Navigation: Exactly "Analyze" and "History" */}
      <BottomNav
        currentTab={currentTab}
        onChangeTab={setCurrentTab}
        historyCount={history.length}
      />
    </div>
  );
}
