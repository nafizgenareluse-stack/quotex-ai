import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { Theme } from '../types';

interface TopAppBarProps {
  theme: Theme;
  onToggleTheme: () => void;
}

export const TopAppBar: React.FC<TopAppBarProps> = ({ theme, onToggleTheme }) => {
  return (
    <header className="sticky top-0 z-30 w-full border-b backdrop-blur-md transition-colors border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90">
      <div className="max-w-2xl mx-auto px-4 h-14 flex items-center justify-between">
        {/* App Title Only */}
        <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100 select-none">
          Quotex AI
        </h1>

        {/* Theme Toggle Button */}
        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={theme === 'dark' ? 'লাইট মোডে পরিবর্তন করুন' : 'ডার্ক মোডে পরিবর্তন করুন'}
          className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
        >
          {theme === 'dark' ? (
            <Sun className="w-5 h-5 transition-transform" />
          ) : (
            <Moon className="w-5 h-5 transition-transform" />
          )}
        </button>

      </div>
    </header>
  );
};
