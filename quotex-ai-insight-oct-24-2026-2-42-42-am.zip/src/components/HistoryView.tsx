import React, { useState } from 'react';
import {
  Trash2,
  TrendingUp,
  TrendingDown,
  FileQuestion,
  Clock,
  X,
  Maximize2,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Hourglass,
  Layers,
  BarChart3,
  ChevronDown,
  ChevronUp,
  Activity,
  Scale,
  Search,
} from 'lucide-react';
import { HistoryRecord, Outcome } from '../types';

interface HistoryViewProps {
  history: HistoryRecord[];
  onDeleteRecord: (id: string) => Promise<void>;
  onUpdateOutcome: (id: string, outcome: Outcome) => Promise<void>;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  onDeleteRecord,
  onUpdateOutcome,
}) => {
  const [selectedRecord, setSelectedRecord] = useState<HistoryRecord | null>(null);
  const [recordToDelete, setRecordToDelete] = useState<HistoryRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [lightboxImageUrl, setLightboxImageUrl] = useState<string | null>(null);
  const [activeModalImageTab, setActiveModalImageTab] = useState<'entry' | 'htf'>('entry');
  const [isStatsOpen, setIsStatsOpen] = useState<boolean>(false);

  // Summary statistics calculations
  const totalAnalyses = history.length;
  const upDownRecords = history.filter(
    (item) => item.analysis.direction === 'UP' || item.analysis.direction === 'DOWN'
  );
  const upDownCount = upDownRecords.length;
  const noTradeCount = history.filter(
    (item) => item.analysis.direction === 'NO TRADE'
  ).length;

  // Outcomes for UP/DOWN predictions
  const correctCount = upDownRecords.filter((item) => item.outcome === 'CORRECT').length;
  const wrongCount = upDownRecords.filter((item) => item.outcome === 'WRONG').length;
  const pendingCount = upDownRecords.filter(
    (item) => !item.outcome || item.outcome === 'PENDING'
  ).length;

  const verifiedCount = correctCount + wrongCount;
  const accuracyRate =
    verifiedCount > 0 ? ((correctCount / verifiedCount) * 100).toFixed(1) : null;

  // UPDATE 6: Calculate breakdown statistics from verified records
  const verifiedOnlyRecords = history.filter(
    (h) =>
      (h.outcome === 'CORRECT' || h.outcome === 'WRONG') &&
      (h.analysis.direction === 'UP' || h.analysis.direction === 'DOWN')
  );

  const calculateGroupStats = (
    records: HistoryRecord[],
    keyExtractor: (r: HistoryRecord) => string | undefined
  ): { label: string; n: number; correct: number; rate: number | null }[] => {
    const map = new Map<string, { correct: number; total: number }>();

    for (const r of records) {
      const key = keyExtractor(r);
      if (!key || key === 'UNKNOWN') continue;
      const curr = map.get(key) || { correct: 0, total: 0 };
      curr.total += 1;
      if (r.outcome === 'CORRECT') curr.correct += 1;
      map.set(key, curr);
    }

    return Array.from(map.entries())
      .map(([label, val]) => ({
        label,
        n: val.total,
        correct: val.correct,
        rate: val.total > 0 ? Math.round((val.correct / val.total) * 100) : null,
      }))
      .sort((a, b) => b.n - a.n);
  };

  const timeframeStats = calculateGroupStats(verifiedOnlyRecords, (r) => r.analysis.timeframe);
  const confidenceStats = calculateGroupStats(verifiedOnlyRecords, (r) => r.analysis.confidence_label);
  const directionStats = calculateGroupStats(verifiedOnlyRecords, (r) => r.analysis.direction);
  const marketStats = calculateGroupStats(verifiedOnlyRecords, (r) => r.analysis.market_condition);

  const confirmDelete = async () => {
    if (!recordToDelete) return;
    setIsDeleting(true);
    try {
      await onDeleteRecord(recordToDelete.id);
      if (selectedRecord?.id === recordToDelete.id) {
        setSelectedRecord(null);
      }
      setRecordToDelete(null);
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleOutcomeClick = async (
    e: React.MouseEvent,
    recordId: string,
    newOutcome: Outcome
  ) => {
    e.stopPropagation();
    try {
      await onUpdateOutcome(recordId, newOutcome);
      if (selectedRecord && selectedRecord.id === recordId) {
        setSelectedRecord((prev) => (prev ? { ...prev, outcome: newOutcome } : null));
      }
    } catch (err) {
      console.error('Failed to update outcome:', err);
    }
  };

  const formatTrend = (trend?: string) => {
    switch (trend) {
      case 'UPTREND':
        return 'ঊর্ধ্বমুখী (UPTREND)';
      case 'DOWNTREND':
        return 'নিম্নমুখী (DOWNTREND)';
      case 'SIDEWAYS':
        return 'পার্শ্বমুখী (SIDEWAYS)';
      case 'UNCLEAR':
      default:
        return 'অস্পষ্ট (UNCLEAR)';
    }
  };

  const getVoteBadge = (vote?: string) => {
    if (vote === 'UP') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-400">
          <TrendingUp className="w-3 h-3" /> UP
        </span>
      );
    }
    if (vote === 'DOWN') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/15 text-rose-700 dark:text-rose-400">
          <TrendingDown className="w-3 h-3" /> DOWN
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
        NEUTRAL
      </span>
    );
  };

  const renderOutcomeButtons = (item: HistoryRecord) => {
    if (item.analysis.direction === 'NO TRADE') {
      return (
        <span className="text-[11px] text-slate-400 dark:text-slate-500 italic select-none">
          ট্রেড নয়, যাচাই প্রযোজ্য নয়
        </span>
      );
    }

    const currentOutcome: Outcome = item.outcome || 'PENDING';

    return (
      <div className="flex items-center gap-1.5 flex-wrap">
        <button
          type="button"
          onClick={(e) => handleOutcomeClick(e, item.id, 'CORRECT')}
          aria-label="পূর্বাভাস সঠিক হিসেবে চিহ্নিত করুন"
          className={`min-h-[40px] px-2.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1 transition-all ${
            currentOutcome === 'CORRECT'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-slate-100 hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-emerald-950/40 dark:hover:text-emerald-300'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>সঠিক</span>
        </button>

        <button
          type="button"
          onClick={(e) => handleOutcomeClick(e, item.id, 'WRONG')}
          aria-label="পূর্বাভাস ভুল হিসেবে চিহ্নিত করুন"
          className={`min-h-[40px] px-2.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1 transition-all ${
            currentOutcome === 'WRONG'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-rose-950/40 dark:hover:text-rose-300'
          }`}
        >
          <XCircle className="w-3.5 h-3.5" />
          <span>ভুল</span>
        </button>

        <button
          type="button"
          onClick={(e) => handleOutcomeClick(e, item.id, 'PENDING')}
          aria-label="পূর্বাভাস অপেক্ষমাণ রাখুন"
          className={`min-h-[40px] px-2 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1 transition-all ${
            currentOutcome === 'PENDING'
              ? 'bg-amber-500 text-white shadow-xs'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700'
          }`}
        >
          <Hourglass className="w-3 h-3" />
          <span>অপেক্ষমাণ</span>
        </button>
      </div>
    );
  };

  return (
    <div className="w-full max-w-2xl mx-auto pb-24 pt-4 px-4 sm:px-6 space-y-4">
      {/* Page Title & Count */}
      <div className="flex items-center justify-between">
        <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
          বিশ্লেষণের ইতিহাস
        </h2>
        {history.length > 0 && (
          <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {history.length}টি রেকর্ড
          </span>
        )}
      </div>

      {/* Summary Card */}
      {history.length > 0 && (
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              <BarChart3 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>পূর্বাভাস যাচাই ও পারফরম্যান্স সারাংশ</span>
            </div>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 tabular-nums font-medium">
              মোট বিশ্লেষণ: <strong>{totalAnalyses}টি</strong>
            </span>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-2.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-medium block">দিক বণ্টন</span>
              <div className="mt-1 text-xs font-semibold text-slate-800 dark:text-slate-200 space-y-0.5">
                <div className="flex justify-between">
                  <span>UP/DOWN:</span>
                  <span className="tabular-nums font-bold">{upDownCount}টি</span>
                </div>
                <div className="flex justify-between text-slate-500 dark:text-slate-400">
                  <span>NO TRADE:</span>
                  <span className="tabular-nums">{noTradeCount}টি</span>
                </div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-medium block">যাচাইকৃত অবস্থা</span>
              <div className="mt-1 text-xs font-semibold space-y-0.5">
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                  <span>সঠিক ✅:</span>
                  <span className="tabular-nums font-bold">{correctCount}টি</span>
                </div>
                <div className="flex justify-between text-rose-600 dark:text-rose-400">
                  <span>ভুল ❌:</span>
                  <span className="tabular-nums font-bold">{wrongCount}টি</span>
                </div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-medium block">অপেক্ষমাণ</span>
              <div className="mt-1 text-xs font-semibold text-amber-600 dark:text-amber-400 space-y-0.5">
                <div className="flex justify-between">
                  <span>অপেক্ষমাণ ⏳:</span>
                  <span className="tabular-nums font-bold">{pendingCount}টি</span>
                </div>
                <div className="text-[10px] text-slate-400 font-normal">যাচাই বাকি</div>
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800/80">
              <span className="text-[10px] text-slate-400 uppercase font-medium block">সঠিকতার হার</span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-lg font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                  {accuracyRate !== null ? `${accuracyRate}%` : '—'}
                </span>
                {accuracyRate !== null && (
                  <span className="text-[10px] text-slate-400">
                    ({correctCount}/{verifiedCount})
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1 gap-1">
            <span>
              NO TRADE ছাড়া মোট ট্রেডযোগ্য পূর্বাভাস: <strong className="text-slate-700 dark:text-slate-300 tabular-nums">{upDownCount}টি</strong>
            </span>
            {verifiedCount < 20 && verifiedCount > 0 && (
              <span className="text-amber-600 dark:text-amber-400 font-medium">
                * নমুনা কম, হার এখনো নির্ভরযোগ্য নয় ({verifiedCount}/২০)।
              </span>
            )}
          </div>

          {/* UPDATE 6: Collapsible Detailed Breakdown Statistics */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setIsStatsOpen(!isStatsOpen)}
              className="w-full flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 min-h-[36px] transition-colors"
            >
              <span>বিস্তারিত পরিসংখ্যান (নিজের ডেটা থেকে শিক্ষা)</span>
              {isStatsOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {isStatsOpen && (
              <div className="mt-3 space-y-3 pt-1 text-xs animate-in fade-in duration-200">
                {verifiedOnlyRecords.length === 0 ? (
                  <p className="text-slate-400 text-center py-2 text-[11px]">
                    পরিসংখ্যান দেখতে অন্তত কিছু পূর্বাভাসকে সঠিক বা ভুল হিসেবে যাচাই করুন।
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {/* Timeframe Stats */}
                    <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block mb-2">
                        টাইমফ্রেম অনুযায়ী
                      </span>
                      {timeframeStats.length > 0 ? (
                        <div className="space-y-1.5">
                          {timeframeStats.map((item) => (
                            <div key={item.label} className="flex items-center justify-between">
                              <span className="text-slate-600 dark:text-slate-400">{item.label}</span>
                              <div className="flex items-center gap-1.5 tabular-nums">
                                <span className="text-[10px] text-slate-400">(n={item.n})</span>
                                <span className={item.n < 10 ? 'text-slate-400' : 'font-bold text-slate-800 dark:text-slate-200'}>
                                  {item.rate !== null ? `${item.rate}%` : '—'}
                                </span>
                                {item.n < 10 && <span className="text-[9px] text-slate-400">(নমুনা কম)</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px]">কোনো তথ্য নেই</span>
                      )}
                    </div>

                    {/* Confidence Stats */}
                    <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block mb-2">
                        আস্থা স্তর অনুযায়ী
                      </span>
                      {confidenceStats.length > 0 ? (
                        <div className="space-y-1.5">
                          {confidenceStats.map((item) => (
                            <div key={item.label} className="flex items-center justify-between">
                              <span className="text-slate-600 dark:text-slate-400">{item.label}</span>
                              <div className="flex items-center gap-1.5 tabular-nums">
                                <span className="text-[10px] text-slate-400">(n={item.n})</span>
                                <span className={item.n < 10 ? 'text-slate-400' : 'font-bold text-slate-800 dark:text-slate-200'}>
                                  {item.rate !== null ? `${item.rate}%` : '—'}
                                </span>
                                {item.n < 10 && <span className="text-[9px] text-slate-400">(নমুনা কম)</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px]">কোনো তথ্য নেই</span>
                      )}
                    </div>

                    {/* Direction Stats */}
                    <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block mb-2">
                        দিক অনুযায়ী (UP বনাম DOWN)
                      </span>
                      {directionStats.length > 0 ? (
                        <div className="space-y-1.5">
                          {directionStats.map((item) => (
                            <div key={item.label} className="flex items-center justify-between">
                              <span className="text-slate-600 dark:text-slate-400">{item.label}</span>
                              <div className="flex items-center gap-1.5 tabular-nums">
                                <span className="text-[10px] text-slate-400">(n={item.n})</span>
                                <span className={item.n < 10 ? 'text-slate-400' : 'font-bold text-slate-800 dark:text-slate-200'}>
                                  {item.rate !== null ? `${item.rate}%` : '—'}
                                </span>
                                {item.n < 10 && <span className="text-[9px] text-slate-400">(নমুনা কম)</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px]">কোনো তথ্য নেই</span>
                      )}
                    </div>

                    {/* Market Condition Stats */}
                    <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block mb-2">
                        বাজারের অবস্থা অনুযায়ী
                      </span>
                      {marketStats.length > 0 ? (
                        <div className="space-y-1.5">
                          {marketStats.map((item) => (
                            <div key={item.label} className="flex items-center justify-between">
                              <span className="text-slate-600 dark:text-slate-400">{item.label}</span>
                              <div className="flex items-center gap-1.5 tabular-nums">
                                <span className="text-[10px] text-slate-400">(n={item.n})</span>
                                <span className={item.n < 10 ? 'text-slate-400' : 'font-bold text-slate-800 dark:text-slate-200'}>
                                  {item.rate !== null ? `${item.rate}%` : '—'}
                                </span>
                                {item.n < 10 && <span className="text-[9px] text-slate-400">(নমুনা কম)</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <span className="text-slate-400 text-[11px]">বাজার অবস্থার কোনো রেকর্ড নেই</span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      )}

      {/* Empty State */}
      {history.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center shadow-xs">
          <div className="mx-auto w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-400 mb-3">
            <Clock className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">
            এখনো কোনো সংরক্ষিত বিশ্লেষণ নেই
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto leading-relaxed">
            Analyze পেজে চার্ট স্ক্রিনশট নির্বাচন করে বিশ্লেষণ করুন। ফলাফল ও স্ক্রিনশট এখানে সংরক্ষিত থাকবে।
          </p>
        </div>
      ) : (
        /* History Cards List */
        <div className="space-y-3">
          {history.map((item) => {
            const isUp = item.analysis.direction === 'UP';
            const isDown = item.analysis.direction === 'DOWN';
            const isNoTrade = item.analysis.direction === 'NO TRADE';

            const dateStr = new Date(item.timestamp).toLocaleDateString('bn-BD', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
            });
            const timeStr = new Date(item.timestamp).toLocaleTimeString('bn-BD', {
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <article
                key={item.id}
                onClick={() => {
                  setSelectedRecord(item);
                  setActiveModalImageTab('entry');
                }}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-2xl p-4 shadow-xs transition-all cursor-pointer flex flex-col gap-3 relative group"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                  {/* Thumbnail Container */}
                  <div className="relative w-20 h-16 sm:w-24 sm:h-20 rounded-xl overflow-hidden bg-slate-950 shrink-0 border border-slate-200 dark:border-slate-800 flex items-center justify-center">
                    <img
                      src={item.thumbnailDataUrl || item.imageDataUrl}
                      alt="চার্ট থাম্বনেইল"
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                    {item.higherTfImageDataUrl && (
                      <span className="absolute bottom-1 right-1 px-1 py-0.2 rounded bg-black/75 text-white text-[9px] font-semibold">
                        Multi-TF
                      </span>
                    )}
                  </div>

                  {/* Card Content */}
                  <div className="flex-1 min-w-0 pr-10 sm:pr-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      {/* Direction Badge */}
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold ${
                          isUp
                            ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400'
                            : isDown
                            ? 'bg-rose-500/15 text-rose-700 dark:text-rose-400'
                            : 'bg-amber-500/15 text-amber-700 dark:text-amber-400'
                        }`}
                      >
                        {isUp && <TrendingUp className="w-3.5 h-3.5" />}
                        {isDown && <TrendingDown className="w-3.5 h-3.5" />}
                        {isNoTrade && <FileQuestion className="w-3.5 h-3.5" />}
                        <span>{item.analysis.direction}</span>
                      </span>

                      {/* Timeframe Tag */}
                      {item.analysis.timeframe && item.analysis.timeframe !== 'UNKNOWN' && (
                        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                          {item.analysis.timeframe}
                        </span>
                      )}

                      {/* Market Condition Tag */}
                      {item.analysis.market_condition && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                          {item.analysis.market_condition === 'TRENDING' ? 'ট্রেন্ডিং' : item.analysis.market_condition === 'CHOPPY' ? 'চপি' : 'রেঞ্জ'}
                        </span>
                      )}

                      {/* Date & Time */}
                      <span className="text-[11px] text-slate-400 dark:text-slate-500 tabular-nums ml-auto sm:ml-0">
                        {dateStr} · {timeStr}
                      </span>
                    </div>

                    <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2 leading-relaxed">
                      {item.analysis.summary}
                    </p>
                  </div>

                  {/* Delete Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setRecordToDelete(item);
                    }}
                    aria-label="রেকর্ড মুছুন"
                    className="absolute top-3 right-3 sm:relative sm:top-auto sm:right-auto min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Outcome Verification Row */}
                <div className="pt-2.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between flex-wrap gap-2">
                  <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    ফলাফল যাচাই:
                  </span>
                  <div>{renderOutcomeButtons(item)}</div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Record Detail Modal */}
      {selectedRecord && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto"
        >
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <Calendar className="w-3.5 h-3.5" />
                <span className="tabular-nums">
                  {new Date(selectedRecord.timestamp).toLocaleString('bn-BD', {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  })}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                aria-label="বিবরণ বন্ধ করুন"
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-5 overflow-y-auto space-y-4">
              {/* Image Tabs if Higher Timeframe image exists */}
              {selectedRecord.higherTfImageDataUrl && (
                <div className="flex gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
                  <button
                    type="button"
                    onClick={() => setActiveModalImageTab('entry')}
                    className={`min-h-[36px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                      activeModalImageTab === 'entry'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    ছবি ১: এন্ট্রি চার্ট
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveModalImageTab('htf')}
                    className={`min-h-[36px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors ${
                      activeModalImageTab === 'htf'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    ছবি ২: বড় টাইমফ্রেম চার্ট
                  </button>
                </div>
              )}

              {/* Full Screenshot Preview with Lightbox trigger */}
              <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 relative group">
                <img
                  src={
                    activeModalImageTab === 'htf' && selectedRecord.higherTfImageDataUrl
                      ? selectedRecord.higherTfImageDataUrl
                      : selectedRecord.imageDataUrl
                  }
                  alt="চার্ট প্রিভিউ"
                  className="w-full max-h-72 object-contain mx-auto"
                />
                <button
                  type="button"
                  onClick={() =>
                    setLightboxImageUrl(
                      activeModalImageTab === 'htf' && selectedRecord.higherTfImageDataUrl
                        ? selectedRecord.higherTfImageDataUrl
                        : selectedRecord.imageDataUrl
                    )
                  }
                  className="absolute bottom-2 right-2 min-h-[36px] px-2.5 py-1 text-xs rounded-lg bg-black/70 text-white hover:bg-black/90 transition-colors flex items-center gap-1.5 backdrop-blur-xs"
                >
                  <Maximize2 className="w-3.5 h-3.5" />
                  ফুলস্ক্রিন দেখুন
                </button>
              </div>

              {/* Outcome verification inside modal */}
              {selectedRecord.analysis.direction !== 'NO TRADE' && (
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 flex items-center justify-between flex-wrap gap-2">
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    পূর্বাভাস যাচাই করুন:
                  </span>
                  <div>{renderOutcomeButtons(selectedRecord)}</div>
                </div>
              )}

              {/* Direction Estimate Banner */}
              <div
                className={`p-4 rounded-xl border ${
                  selectedRecord.analysis.direction === 'UP'
                    ? 'bg-emerald-500/10 border-emerald-500/30'
                    : selectedRecord.analysis.direction === 'DOWN'
                    ? 'bg-rose-500/10 border-rose-500/30'
                    : 'bg-amber-500/10 border-amber-500/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {selectedRecord.analysis.direction === 'UP' && (
                      <TrendingUp className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
                    )}
                    {selectedRecord.analysis.direction === 'DOWN' && (
                      <TrendingDown className="w-6 h-6 text-rose-600 dark:text-rose-400" />
                    )}
                    {selectedRecord.analysis.direction === 'NO TRADE' && (
                      <FileQuestion className="w-6 h-6 text-amber-600 dark:text-amber-400" />
                    )}
                    <h4
                      className={`text-xl font-bold tracking-tight ${
                        selectedRecord.analysis.direction === 'UP'
                          ? 'text-emerald-700 dark:text-emerald-300'
                          : selectedRecord.analysis.direction === 'DOWN'
                          ? 'text-rose-700 dark:text-rose-300'
                          : 'text-amber-700 dark:text-amber-300'
                      }`}
                    >
                      {selectedRecord.analysis.direction}
                    </h4>
                  </div>
                  <div className="text-right space-y-0.5">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 block">
                      আস্থা: {selectedRecord.analysis.confidence_label}
                    </span>
                    {selectedRecord.analysis.market_condition && (
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                        বাজার: {selectedRecord.analysis.market_condition === 'TRENDING' ? 'ট্রেন্ডিং' : selectedRecord.analysis.market_condition === 'CHOPPY' ? 'চপি' : 'রেঞ্জ'}
                      </span>
                    )}
                  </div>
                </div>

                <p className="mt-2.5 text-xs text-slate-800 dark:text-slate-200 leading-relaxed">
                  {selectedRecord.analysis.summary}
                </p>
                <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 italic">
                  নোট: {selectedRecord.analysis.confidence_note}
                </p>
              </div>

              {/* UPDATE 2: Self-Review section if present */}
              {(selectedRecord.analysis.counter_argument || selectedRecord.analysis.review_verdict) && (
                <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between pb-1 border-b border-slate-200 dark:border-slate-800/80">
                    <div className="flex items-center gap-1 font-semibold text-slate-800 dark:text-slate-200">
                      <Scale className="w-3.5 h-3.5 text-amber-600" />
                      <span>আত্ম-পর্যালোচনা:</span>
                    </div>
                    {selectedRecord.analysis.review_verdict && (
                      <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        ফল: {selectedRecord.analysis.review_verdict}
                      </span>
                    )}
                  </div>
                  {selectedRecord.analysis.counter_argument && (
                    <p className="text-slate-700 dark:text-slate-300">
                      <strong className="text-rose-600 dark:text-rose-400">উল্টো যুক্তি: </strong>
                      {selectedRecord.analysis.counter_argument}
                    </p>
                  )}
                </div>
              )}

              {/* Confluence Factor Votes if present */}
              {(selectedRecord.analysis.trend_vote ||
                selectedRecord.analysis.pattern_vote ||
                selectedRecord.analysis.sr_vote) && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200">
                    <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>ফ্যাক্টর ভোট (Confluence)</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">ট্রেন্ড:</span>
                      {getVoteBadge(selectedRecord.analysis.trend_vote)}
                    </div>
                    <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">প্যাটার্ন:</span>
                      {getVoteBadge(selectedRecord.analysis.pattern_vote)}
                    </div>
                    <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                      <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">S/R:</span>
                      {getVoteBadge(selectedRecord.analysis.sr_vote)}
                    </div>
                    {selectedRecord.analysis.htf_vote && (
                      <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">বড় TF:</span>
                        {getVoteBadge(selectedRecord.analysis.htf_vote)}
                      </div>
                    )}
                    {selectedRecord.analysis.indicator_vote && (
                      <div className="p-2 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-[11px] font-medium text-slate-600 dark:text-slate-400">ইন্ডিকেটর:</span>
                        {getVoteBadge(selectedRecord.analysis.indicator_vote)}
                      </div>
                    )}
                  </div>

                  {selectedRecord.analysis.indicators_visible &&
                    selectedRecord.analysis.indicators_visible.length > 0 && (
                      <div className="text-[11px] text-slate-600 dark:text-slate-400 pt-1">
                        <span className="font-semibold text-slate-500 block mb-0.5">পঠিত ইন্ডিকেটর:</span>
                        <ul className="space-y-0.5">
                          {selectedRecord.analysis.indicators_visible.map((ind, i) => (
                            <li key={i} className="flex items-center gap-1">
                              <Search className="w-3 h-3 text-slate-400" />
                              <span>{ind}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                </div>
              )}

              {/* UPDATE 4: Level Quality & Momentum if present */}
              {(selectedRecord.analysis.level_strength || selectedRecord.analysis.momentum) && (
                <div className="p-3 bg-slate-50 dark:bg-slate-950/60 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-1.5 font-semibold text-slate-800 dark:text-slate-200 pb-1.5 border-b border-slate-200 dark:border-slate-800">
                    <Activity className="w-3.5 h-3.5 text-emerald-600" />
                    <span>লেভেলের গুণমান ও মোমেন্টাম:</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px]">
                    <div>
                      <span className="text-slate-400 block text-[10px]">লেভেল স্পর্শ</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {selectedRecord.analysis.level_touch_count || 'UNKNOWN'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">লেভেলের শক্তি</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {selectedRecord.analysis.level_strength || 'UNKNOWN'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">মোমেন্টাম</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {selectedRecord.analysis.momentum || 'UNKNOWN'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[10px]">ব্রেকআউট</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {selectedRecord.analysis.breakout_type || 'NONE'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Trend & Observations */}
              <div className="space-y-3 text-xs">
                <div className="grid grid-cols-2 gap-2 p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block">দৃশ্যমান ট্রেন্ড</span>
                    <span className="font-semibold text-slate-900 dark:text-slate-100">
                      {formatTrend(selectedRecord.analysis.trend)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-slate-400 block">টাইমফ্রেম</span>
                    <span className="font-semibold text-slate-900 dark:text-slate-100">
                      {selectedRecord.analysis.timeframe}
                    </span>
                  </div>
                </div>

                {selectedRecord.analysis.observations &&
                  selectedRecord.analysis.observations.length > 0 && (
                    <div>
                      <h5 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-1.5">
                        দৃশ্যমান ক্যান্ডেলস্টিক পর্যবেক্ষণ
                      </h5>
                      <ul className="space-y-1 text-slate-700 dark:text-slate-300">
                        {selectedRecord.analysis.observations.map((obs, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-slate-400">·</span>
                            <span className="leading-relaxed">{obs}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                {/* Evidence Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">
                      পক্ষে প্রমাণ
                    </span>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400">
                      {selectedRecord.analysis.supporting_evidence &&
                      selectedRecord.analysis.supporting_evidence.length > 0 ? (
                        selectedRecord.analysis.supporting_evidence.map((s, i) => (
                          <li key={i}>✓ {s}</li>
                        ))
                      ) : (
                        <li className="text-slate-400">কোনো জোরালো প্রমাণ নেই।</li>
                      )}
                    </ul>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800">
                    <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider block mb-1">
                      বিপক্ষে ঝুঁকি ও অনিশ্চয়তা
                    </span>
                    <ul className="space-y-1 text-slate-600 dark:text-slate-400">
                      {selectedRecord.analysis.conflicting_evidence &&
                      selectedRecord.analysis.conflicting_evidence.length > 0 ? (
                        selectedRecord.analysis.conflicting_evidence.map((c, i) => (
                          <li key={i}>! {c}</li>
                        ))
                      ) : (
                        <li className="text-slate-400">কোনো বড় ঝুঁকি নেই।</li>
                      )}
                    </ul>
                  </div>
                </div>

                {/* Limitations */}
                {selectedRecord.analysis.limitations &&
                  selectedRecord.analysis.limitations.length > 0 && (
                    <div className="pt-2 text-[11px] text-slate-500 dark:text-slate-400">
                      <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                        সীমাবদ্ধতা ও সতর্কবার্তা
                      </span>
                      <ul className="space-y-0.5">
                        {selectedRecord.analysis.limitations.map((l, i) => (
                          <li key={i}>· {l}</li>
                        ))}
                      </ul>
                    </div>
                  )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-slate-950/50">
              <button
                type="button"
                onClick={() => setRecordToDelete(selectedRecord)}
                className="text-xs font-medium text-rose-600 dark:text-rose-400 hover:text-rose-700 min-h-[40px] px-2 flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                রেকর্ড মুছুন
              </button>

              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                className="min-h-[40px] px-4 py-2 text-xs font-medium bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 rounded-lg hover:bg-slate-800 dark:hover:bg-white transition-colors"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Lightbox Modal */}
      {lightboxImageUrl && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setLightboxImageUrl(null)}
          className="fixed inset-0 z-60 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 cursor-zoom-out"
        >
          <button
            type="button"
            onClick={() => setLightboxImageUrl(null)}
            aria-label="ফুলস্ক্রিন ভিউ বন্ধ করুন"
            className="absolute top-4 right-4 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightboxImageUrl}
            alt="ফুলস্ক্রিন চার্ট"
            className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl"
          />
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {recordToDelete && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs"
        >
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-sm p-5 shadow-xl animate-in fade-in zoom-in-95 duration-150">
            <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              ইতিহাস রেকর্ড মুছবেন?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed">
              এই বিশ্লেষণ এবং মূল চার্ট স্ক্রিনশটটি আপনার ডিভাইসের লোকাল স্টোরেজ থেকে স্থায়ীভাবে মুছে যাবে।
            </p>

            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setRecordToDelete(null)}
                className="min-h-[40px] px-3.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              >
                বাতিল
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={confirmDelete}
                className="min-h-[40px] px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors flex items-center gap-1.5"
              >
                {isDeleting ? 'মুছে ফেলা হচ্ছে...' : 'মুছে ফেলুন'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
