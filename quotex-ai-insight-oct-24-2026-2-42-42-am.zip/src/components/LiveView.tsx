import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Activity,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Clock,
  RefreshCw,
  Sparkles,
  BarChart2,
  Sliders,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ShieldAlert,
  ChevronDown,
  ChevronUp,
  Trash2,
  Zap,
  Target,
  Layers,
} from 'lucide-react';
import {
  LiveSignalResult,
  LiveHistoryRecord,
  BacktestResultPayload,
  DataStatus,
  LiveOutcome,
} from '../types/live';
import {
  saveLiveSignalRecord,
  getLiveHistoryRecords,
  updateLiveSignalOutcome,
  deleteLiveSignalRecord,
  clearAllLiveSignals,
} from '../utils/liveStorage';

export const LiveView: React.FC = () => {
  // Navigation Sub-tab
  const [subTab, setSubTab] = useState<'signal' | 'backtest' | 'history'>('signal');

  // Controls state
  const [symbol, setSymbol] = useState<string>('EURUSD_otc');
  const [tf, setTf] = useState<number>(60);
  const [availableSymbols, setAvailableSymbols] = useState<Array<{ symbol: string; name: string }>>([
    { symbol: 'EURUSD_otc', name: 'EUR/USD (OTC)' },
    { symbol: 'GBPUSD_otc', name: 'GBP/USD (OTC)' },
    { symbol: 'USDJPY_otc', name: 'USD/JPY (OTC)' },
    { symbol: 'AUDUSD_otc', name: 'AUD/USD (OTC)' },
    { symbol: 'USDCAD_otc', name: 'USD/CAD (OTC)' },
    { symbol: 'EURGBP_otc', name: 'EUR/GBP (OTC)' },
    { symbol: 'EURJPY_otc', name: 'EUR/JPY (OTC)' },
    { symbol: 'GBPJPY_otc', name: 'GBP/JPY (OTC)' },
  ]);

  // Signal State
  const [currentSignal, setCurrentSignal] = useState<LiveSignalResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [signalError, setSignalError] = useState<string | null>(null);
  const [dataStatus, setDataStatus] = useState<DataStatus | null>(null);

  // Gemini Explanation State
  const [isExplaining, setIsExplaining] = useState<boolean>(false);
  const [explanation, setExplanation] = useState<{ text: string; counter: string } | null>(null);
  const [explainError, setExplainError] = useState<string | null>(null);

  // Countdown timer state
  const [secondsRemaining, setSecondsRemaining] = useState<number | null>(null);
  const timerRef = useRef<number | null>(null);

  // Backtest State
  const [backtestResult, setBacktestResult] = useState<BacktestResultPayload | null>(null);
  const [isBacktesting, setIsBacktesting] = useState<boolean>(false);
  const [backtestError, setBacktestError] = useState<string | null>(null);

  // History State
  const [historyRecords, setHistoryRecords] = useState<LiveHistoryRecord[]>([]);
  const [isVerifyingHistory, setIsVerifyingHistory] = useState<boolean>(false);
  const [expandedRecordId, setExpandedRecordId] = useState<string | null>(null);
  const [historyNotice, setHistoryNotice] = useState<string | null>(null);

  // Fetch symbol list once on mount
  useEffect(() => {
    fetch('/api/live/symbols')
      .then((res) => res.json())
      .then((data) => {
        if (data.symbols && Array.isArray(data.symbols)) {
          setAvailableSymbols(data.symbols);
        }
      })
      .catch((err) => {
        console.warn('Could not load symbols dynamically, using defaults:', err);
      });
  }, []);

  // Load history on mount and when switching to history tab
  const loadHistory = useCallback(async () => {
    try {
      const records = await getLiveHistoryRecords();
      setHistoryRecords(records);
    } catch (err) {
      console.error('Failed to load live history:', err);
    }
  }, []);

  useEffect(() => {
    loadHistory();
  }, [loadHistory, subTab]);

  // Countdown timer effect
  useEffect(() => {
    if (!currentSignal) {
      setSecondsRemaining(null);
      return;
    }

    const updateTimer = () => {
      const nowSec = Math.floor(Date.now() / 1000);
      const remaining = currentSignal.targetCloseTime - nowSec;
      setSecondsRemaining(remaining > 0 ? remaining : 0);
    };

    updateTimer();
    const interval = window.setInterval(updateTimer, 1000);
    timerRef.current = interval;

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentSignal]);

  // Handle Signal Generation
  const handleGenerateSignal = async () => {
    setIsAnalyzing(true);
    setSignalError(null);
    setExplanation(null);
    setExplainError(null);

    try {
      const res = await fetch(`/api/live/signal?symbol=${encodeURIComponent(symbol)}&tf=${tf}`);
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'লাইভ সিগন্যাল তৈরি করতে ব্যর্থ হয়েছে।');
      }

      const signalResult: LiveSignalResult = data;
      setCurrentSignal(signalResult);
      setDataStatus(signalResult.dataStatus);

      // Save to Live IndexedDB as PENDING (or NOT_APPLICABLE if NO TRADE)
      const record: LiveHistoryRecord = {
        id: signalResult.id,
        symbol: signalResult.symbol,
        tf: signalResult.tf,
        signal: signalResult,
        targetCandleTime: signalResult.targetCandleTime,
        targetCloseTime: signalResult.targetCloseTime,
        createdAt: signalResult.createdAt,
        outcome: signalResult.direction === 'NO TRADE' ? 'NOT_APPLICABLE' : 'PENDING',
      };

      await saveLiveSignalRecord(record);
      await loadHistory();
    } catch (err: any) {
      setSignalError(err.message || 'নেটওয়ার্ক বা সার্ভার সমস্যা দেখা দিয়েছে।');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handle Gemini Explanation
  const handleRequestExplain = async () => {
    if (!currentSignal) return;
    setIsExplaining(true);
    setExplainError(null);

    try {
      const res = await fetch('/api/live/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ signal: currentSignal }),
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'এআই ব্যাখ্যা পাওয়া যায়নি।');
      }

      setExplanation({
        text: data.explanation || '',
        counter: data.counterArgument || '',
      });
    } catch (err: any) {
      setExplainError(err.message || 'ব্যাখ্যা তৈরিতে সমস্যা হয়েছে।');
    } finally {
      setIsExplaining(false);
    }
  };

  // Handle Backtest
  const handleRunBacktest = async () => {
    setIsBacktesting(true);
    setBacktestError(null);

    try {
      const res = await fetch(`/api/live/backtest?symbol=${encodeURIComponent(symbol)}&tf=${tf}&limit=150`);
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'ব্যাকটেস্ট সম্পন্ন করা যায়নি।');
      }

      setBacktestResult(data);
      setDataStatus(data.dataStatus);
    } catch (err: any) {
      setBacktestError(err.message || 'ব্যাকটেস্টে ত্রুটি ঘটেছে।');
    } finally {
      setIsBacktesting(false);
    }
  };

  // Handle Auto Verification of Live History Records
  const handleAutoVerifyHistory = async () => {
    setIsVerifyingHistory(true);
    setHistoryNotice(null);

    try {
      const pendingRecords = historyRecords.filter(
        (r) => r.outcome === 'PENDING' && r.signal.direction !== 'NO TRADE'
      );

      if (pendingRecords.length === 0) {
        setHistoryNotice('যাচাই করার মতো কোনো পেন্ডিং সিগন্যাল নেই।');
        setIsVerifyingHistory(false);
        return;
      }

      // Group pending records by symbol & tf to minimize OTCharts calls
      const groups = new Map<string, LiveHistoryRecord[]>();
      for (const rec of pendingRecords) {
        const key = `${rec.symbol}:${rec.tf}`;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key)!.push(rec);
      }

      let verifiedCount = 0;
      const nowSec = Math.floor(Date.now() / 1000);

      for (const [key, records] of groups.entries()) {
        const [grpSymbol, grpTfStr] = key.split(':');
        const grpTf = parseInt(grpTfStr, 10);

        try {
          const res = await fetch(
            `/api/live/candles?symbol=${encodeURIComponent(grpSymbol)}&tf=${grpTf}&limit=80`
          );
          if (!res.ok) continue;

          const data = await res.json();
          const closedCandles: any[] = data.candles || [];

          for (const rec of records) {
            // Check if target candle is closed
            if (rec.targetCloseTime > nowSec) {
              // Still open/forming
              continue;
            }

            // Find candle matching targetCandleTime
            const targetCandle = closedCandles.find((c) => Math.abs(c.time - rec.targetCandleTime) < grpTf / 2);
            if (!targetCandle) continue;

            let determinedOutcome: LiveOutcome = 'DRAW';
            if (targetCandle.close > targetCandle.open) {
              determinedOutcome = rec.signal.direction === 'UP' ? 'CORRECT' : 'WRONG';
            } else if (targetCandle.close < targetCandle.open) {
              determinedOutcome = rec.signal.direction === 'DOWN' ? 'CORRECT' : 'WRONG';
            } else {
              determinedOutcome = 'DRAW';
            }

            await updateLiveSignalOutcome(
              rec.id,
              determinedOutcome,
              targetCandle.close,
              targetCandle.open
            );
            verifiedCount++;
          }
        } catch (grpErr) {
          console.warn(`Error verifying group ${key}:`, grpErr);
        }
      }

      await loadHistory();
      setHistoryNotice(
        verifiedCount > 0
          ? `${verifiedCount}টি সিগন্যালের ফলাফল সফলভাবে যাচাই ও আপডেট হয়েছে।`
          : 'নতুন কোনো ক্যান্ডেল বন্ধ হয়নি। ক্যান্ডেল বন্ধের পর পুনরায় ক্লিক করুন।'
      );
    } catch (err: any) {
      setHistoryNotice('যাচাই করার সময় একটি ত্রুটি ঘটেছে: ' + err.message);
    } finally {
      setIsVerifyingHistory(false);
    }
  };

  const handleManualOutcome = async (id: string, outcome: LiveOutcome) => {
    await updateLiveSignalOutcome(id, outcome);
    await loadHistory();
  };

  const handleDeleteRecord = async (id: string) => {
    await deleteLiveSignalRecord(id);
    await loadHistory();
  };

  const handleClearHistory = async () => {
    if (window.confirm('আপনি কি নিশ্চিত যে সমস্ত লাইভ ইতিহাস মুছে ফেলতে চান?')) {
      await clearAllLiveSignals();
      await loadHistory();
    }
  };

  // Helper formatting functions
  const formatTime = (timestampSeconds: number) => {
    if (!timestampSeconds) return 'N/A';
    return new Date(timestampSeconds * 1000).toLocaleTimeString('bn-BD', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const formatCountdown = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Stats calculation for history
  const totalSignals = historyRecords.length;
  const actionableRecords = historyRecords.filter(
    (r) => r.signal.direction === 'UP' || r.signal.direction === 'DOWN'
  );
  const correctSignals = actionableRecords.filter((r) => r.outcome === 'CORRECT').length;
  const wrongSignals = actionableRecords.filter((r) => r.outcome === 'WRONG').length;
  const drawSignals = actionableRecords.filter((r) => r.outcome === 'DRAW').length;
  const pendingSignals = actionableRecords.filter((r) => r.outcome === 'PENDING').length;
  const decisiveSignals = correctSignals + wrongSignals;
  const liveWinRate = decisiveSignals > 0 ? ((correctSignals / decisiveSignals) * 100).toFixed(1) : null;

  return (
    <div className="space-y-6 pb-24">
      {/* 1. Header & Segmented Sub-Tab Control */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                লাইভ কোয়ান্ট ট্রেডিং
              </h1>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              বাস্তব ক্যান্ডেল ডেটা ও গাণিতিক ইন্ডিকেটর নির্ভর লাইভ সিগন্যাল ও ব্যাকটেস্টিং
            </p>
          </div>

          {/* Sub tabs switcher */}
          <div className="flex bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl self-start sm:self-auto border border-slate-200 dark:border-slate-700/50">
            <button
              onClick={() => setSubTab('signal')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                subTab === 'signal'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              সিগন্যাল
            </button>
            <button
              onClick={() => setSubTab('backtest')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                subTab === 'backtest'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <BarChart2 className="w-3.5 h-3.5" />
              ব্যাকটেস্ট
            </button>
            <button
              onClick={() => setSubTab('history')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                subTab === 'history'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              লাইভ ইতিহাস ({totalSignals})
            </button>
          </div>
        </div>

        {/* Live Data Status Bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 gap-2">
          <div className="flex items-center gap-2">
            <span className="font-medium text-slate-700 dark:text-slate-300">ডেটা ফিড:</span>
            <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-mono">
              OTCharts API
            </span>
            {dataStatus && (
              <>
                <span>•</span>
                <span>ক্যান্ডেল: <b>{dataStatus.candleCount}টি</b></span>
                <span>•</span>
                <span>শেষ বন্ধ: <b>{formatTime(dataStatus.lastClosedCandleTime)}</b></span>
              </>
            )}
          </div>
          <div className="flex items-center gap-2 font-mono">
            <span>রিকোয়েস্ট কাউন্টার: {dataStatus ? dataStatus.otchartsRequestsCount : 0}</span>
            <span>•</span>
            <span className="text-[10px] text-slate-400">কোটা সাশ্রয়ী ক্যাশিং সক্রিয়</span>
          </div>
        </div>
      </div>

      {/* 2. Top Controls: Symbol & Timeframe */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            {/* Symbol Select */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                ট্রেডিং পেয়ার
              </label>
              <select
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-sm font-semibold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {availableSymbols.map((item) => (
                  <option key={item.symbol} value={item.symbol}>
                    {item.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Timeframe Select */}
            <div className="flex flex-col gap-1">
              <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                টাইমফ্রেম
              </label>
              <div className="flex gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                <button
                  type="button"
                  onClick={() => setTf(60)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    tf === 60
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  1 মিনিট (60s)
                </button>
                <button
                  type="button"
                  onClick={() => setTf(300)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                    tf === 300
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  5 মিনিট (300s)
                </button>
              </div>
            </div>
          </div>

          {/* Action button based on active subTab */}
          <div className="flex items-center gap-2">
            {subTab === 'signal' && (
              <button
                type="button"
                onClick={handleGenerateSignal}
                disabled={isAnalyzing}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl text-sm font-bold bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white shadow-md shadow-blue-500/20 transition-all flex items-center justify-center gap-2"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    ক্যান্ডেল বিশ্লেষণ হচ্ছে...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    সিগন্যাল বিশ্লেষণ করুন
                  </>
                )}
              </button>
            )}

            {subTab === 'backtest' && (
              <button
                type="button"
                onClick={handleRunBacktest}
                disabled={isBacktesting}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl text-sm font-bold bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white shadow-md shadow-purple-500/20 transition-all flex items-center justify-center gap-2"
              >
                {isBacktesting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    ব্যাকটেস্ট হিসেব হচ্ছে...
                  </>
                ) : (
                  <>
                    <BarChart2 className="w-4 h-4" />
                    ওয়াক-ফরওয়ার্ড ব্যাকটেস্ট চালান
                  </>
                )}
              </button>
            )}

            {subTab === 'history' && (
              <button
                type="button"
                onClick={handleAutoVerifyHistory}
                disabled={isVerifyingHistory}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-sm font-bold bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white shadow-md shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
              >
                {isVerifyingHistory ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    ক্যান্ডেল ফলাফল মেলানো হচ্ছে...
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    ফলাফল স্বয়ংক্রিয় যাচাই করুন
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 3. Sub-Tab 1: SIGNAL VIEW */}
      {subTab === 'signal' && (
        <div className="space-y-6">
          {signalError && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">সিগন্যাল ত্রুটি</p>
                <p className="text-xs mt-0.5">{signalError}</p>
              </div>
            </div>
          )}

          {!currentSignal && !isAnalyzing && (
            <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-4">
                <Zap className="w-7 h-7" />
              </div>
              <h2 className="text-base font-bold text-slate-800 dark:text-slate-200">
                কোনো লাইভ সিগন্যাল লোড করা হয়নি
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1.5 mb-5">
                উপরে আপনার পছন্দের অ্যাসেট ও টাইমফ্রেম নির্বাচন করে <b>সিগন্যাল বিশ্লেষণ করুন</b> বাটনে ক্লিক করুন। OTCharts থেকে বন্ধ ক্যান্ডেল ডেটা নিয়ে অ্যালগরিদম ৪টি ফ্যাক্টর বিচার করবে।
              </p>
              <button
                type="button"
                onClick={handleGenerateSignal}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-blue-600 text-white hover:bg-blue-500 shadow-sm transition-all inline-flex items-center gap-2"
              >
                <Zap className="w-4 h-4" />
                এখনই বিশ্লেষণ শুরু করুন
              </button>
            </div>
          )}

          {currentSignal && (
            <div className="space-y-6">
              {/* Main Signal Result Card */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-4">
                    {/* Direction Badge */}
                    <div
                      className={`px-5 py-3 rounded-2xl font-black text-xl flex items-center gap-2 border ${
                        currentSignal.direction === 'UP'
                          ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30'
                          : currentSignal.direction === 'DOWN'
                          ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30'
                          : 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30'
                      }`}
                    >
                      {currentSignal.direction === 'UP' && <TrendingUp className="w-6 h-6 stroke-[2.5]" />}
                      {currentSignal.direction === 'DOWN' && <TrendingDown className="w-6 h-6 stroke-[2.5]" />}
                      {currentSignal.direction === 'NO TRADE' && <ShieldAlert className="w-6 h-6 stroke-[2.5]" />}
                      <span>{currentSignal.direction}</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-slate-800 dark:text-slate-100">
                          {currentSignal.symbol}
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono">
                          {currentSignal.tf}s
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        {/* Confidence */}
                        <span
                          className={`text-xs px-2 py-0.5 rounded font-semibold ${
                            currentSignal.confidence === 'HIGH'
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                              : currentSignal.confidence === 'MODERATE'
                              ? 'bg-blue-500/10 text-blue-600 dark:text-blue-400'
                              : 'bg-amber-500/10 text-amber-600 dark:text-amber-400'
                          }`}
                        >
                          আত্মবিশ্বাস: {currentSignal.confidence}
                        </span>
                        {/* Market Condition */}
                        <span className="text-xs px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-medium">
                          বাজার: {currentSignal.market_condition === 'TRENDING' ? 'ট্রেন্ডিং' : currentSignal.market_condition === 'RANGING' ? 'রেঞ্জিং' : 'চপি'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Countdown Timer Card */}
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between sm:justify-end gap-5">
                    <div className="text-left sm:text-right">
                      <p className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                        ক্যান্ডেল সমাপ্তির কাউন্টডাউন
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        টার্গেট ক্যান্ডেল বন্ধ: <b>{formatTime(currentSignal.targetCloseTime)}</b>
                      </p>
                    </div>

                    <div className="flex items-center gap-2 font-mono">
                      <Clock className="w-5 h-5 text-blue-500 animate-pulse" />
                      <span className="text-xl font-bold text-slate-900 dark:text-slate-100 min-w-16">
                        {secondsRemaining !== null ? formatCountdown(secondsRemaining) : '--:--'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Counter trend or No trade warning */}
                {currentSignal.counter_trend && (
                  <div className="mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-600 dark:text-amber-400 text-xs flex items-center gap-2 font-medium">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>
                      <b>কাউন্টার-ট্রেন্ড ঝুঁকি:</b> এই সিগন্যালটি মূল ট্রেন্ডের বিপরীত অভিমুখে তৈরি হয়েছে। সতর্কতা অবলম্বন করুন বা ছোট সাইজে ট্রেড নিন।
                    </span>
                  </div>
                )}

                {currentSignal.noTradeReason && (
                  <div className="mt-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-700 dark:text-amber-300 text-xs flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5 text-amber-500" />
                    <div>
                      <p className="font-bold">ট্রেড না নেওয়ার নির্দেশ (NO TRADE):</p>
                      <p className="mt-0.5">{currentSignal.noTradeReason}</p>
                    </div>
                  </div>
                )}

                {/* 4/5 Factor Votes breakdown */}
                <div className="mt-5">
                  <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
                    ফ্যাক্টর ভোটিং ও যুক্তি
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {/* Vote 1: Trend */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-500 dark:text-slate-400">১. ট্রেন্ড ভোট</span>
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                            currentSignal.votes.trend_vote === 'UP'
                              ? 'bg-emerald-500/10 text-emerald-500'
                              : currentSignal.votes.trend_vote === 'DOWN'
                              ? 'bg-rose-500/10 text-rose-500'
                              : 'bg-slate-500/10 text-slate-400'
                          }`}
                        >
                          {currentSignal.votes.trend_vote}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                        {currentSignal.votesReasoning[0]?.replace('১. ট্রেন্ড: ', '') || 'EMA20 ও EMA50 পর্যবেক্ষণ'}
                      </p>
                    </div>

                    {/* Vote 2: Pattern */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-500 dark:text-slate-400">২. প্যাটার্ন ভোট</span>
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                            currentSignal.votes.pattern_vote === 'UP'
                              ? 'bg-emerald-500/10 text-emerald-500'
                              : currentSignal.votes.pattern_vote === 'DOWN'
                              ? 'bg-rose-500/10 text-rose-500'
                              : 'bg-slate-500/10 text-slate-400'
                          }`}
                        >
                          {currentSignal.votes.pattern_vote}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                        {currentSignal.votesReasoning[1]?.replace('২. প্যাটার্ন: ', '') || 'প্রাইস অ্যাকশন ক্যান্ডেলস্টিক'}
                      </p>
                    </div>

                    {/* Vote 3: S/R */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-500 dark:text-slate-400">৩. S/R ভোট</span>
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                            currentSignal.votes.sr_vote === 'UP'
                              ? 'bg-emerald-500/10 text-emerald-500'
                              : currentSignal.votes.sr_vote === 'DOWN'
                              ? 'bg-rose-500/10 text-rose-500'
                              : 'bg-slate-500/10 text-slate-400'
                          }`}
                        >
                          {currentSignal.votes.sr_vote}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                        {currentSignal.votesReasoning[2]?.replace('৩. S/R: ', '') || 'সাপোর্ট ও রেজিস্ট্যান্স দূরত্ব'}
                      </p>
                    </div>

                    {/* Vote 4: Indicators */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-semibold text-slate-500 dark:text-slate-400">৪. ইন্ডিকেটর ভোট</span>
                        <span
                          className={`font-bold px-1.5 py-0.5 rounded text-[11px] ${
                            currentSignal.votes.indicator_vote === 'UP'
                              ? 'bg-emerald-500/10 text-emerald-500'
                              : currentSignal.votes.indicator_vote === 'DOWN'
                              ? 'bg-rose-500/10 text-rose-500'
                              : 'bg-slate-500/10 text-slate-400'
                          }`}
                        >
                          {currentSignal.votes.indicator_vote}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                        {currentSignal.votesReasoning[3]?.replace('৪. ইন্ডিকেটর: ', '') || 'RSI ও MACD মোমেন্টাম'}
                      </p>
                    </div>
                  </div>

                  {currentSignal.votes.htf_vote && (
                    <div className="mt-2 p-2.5 rounded-lg bg-blue-500/5 border border-blue-500/20 text-xs flex items-center justify-between text-blue-600 dark:text-blue-400">
                      <span className="font-semibold">৫. বড় টাইমফ্রেম ভোট (HTF {currentSignal.tf * 5}s):</span>
                      <span className="font-bold">{currentSignal.votes.htf_vote}</span>
                    </div>
                  )}
                </div>

                {/* Technical Indicator Grid */}
                <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
                  <h3 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
                    গাণিতিক ইন্ডিকেটর পরিমাপ
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-center">
                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-medium">EMA (20 / 50)</span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {currentSignal.indicators.ema20} / {currentSignal.indicators.ema50}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-medium">RSI (14)</span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {currentSignal.indicators.rsi14}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-medium">MACD Hist</span>
                      <span
                        className={`text-xs font-bold font-mono ${
                          currentSignal.indicators.macdHist >= 0 ? 'text-emerald-500' : 'text-rose-500'
                        }`}
                      >
                        {currentSignal.indicators.macdHist}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-medium">Bollinger Bandwidth</span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {currentSignal.indicators.bbBandwidth}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-medium">Efficiency Ratio</span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {currentSignal.indicators.efficiencyRatio}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-[10px] text-slate-400 block font-medium">ATR (14)</span>
                      <span className="text-xs font-bold text-slate-800 dark:text-slate-200 font-mono">
                        {currentSignal.indicators.atr14}
                      </span>
                    </div>
                  </div>

                  {/* S/R Info */}
                  <div className="mt-3 flex flex-wrap items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
                    <div>
                      নিকটবর্তী সাপোর্ট: <b className="font-mono">{currentSignal.levels.nearestSupport ?? 'নেই'}</b> ({currentSignal.levels.supportTouches} বার টেস্ট)
                    </div>
                    <div>
                      নিকটবর্তী রেজিস্ট্যান্স: <b className="font-mono">{currentSignal.levels.nearestResistance ?? 'নেই'}</b> ({currentSignal.levels.resistanceTouches} বার টেস্ট)
                    </div>
                  </div>
                </div>

                {/* Gemini AI Explain & Risk Section */}
                <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                        <Sparkles className="w-4 h-4 text-purple-500" />
                        AI ব্যাখ্যা ও সবচেয়ে শক্তিশালী বিপরীত যুক্তি
                      </h4>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Gemini AI এই গাণিতিক সিদ্ধান্তের অন্তর্নিহিত কারণ ও সম্ভাব্য ঝুঁকি ব্যাখ্যা করবে (ডিরেকশন অপরিবর্তিত থাকবে)
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleRequestExplain}
                      disabled={isExplaining}
                      className="px-4 py-2 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white shadow-xs transition-all flex items-center justify-center gap-1.5 self-start sm:self-auto"
                    >
                      {isExplaining ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          বিশ্লেষণ হচ্ছে...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          AI ব্যাখ্যা পান
                        </>
                      )}
                    </button>
                  </div>

                  {explainError && (
                    <div className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs">
                      {explainError}
                    </div>
                  )}

                  {explanation && (
                    <div className="mt-4 space-y-3">
                      <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
                        <span className="text-[11px] font-bold text-purple-600 dark:text-purple-400 uppercase tracking-wider block mb-1">
                          গাণিতিক বিশ্লেষণের ব্যাখ্যা
                        </span>
                        <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                          {explanation.text}
                        </p>
                      </div>

                      <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20">
                        <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400 uppercase tracking-wider flex items-center gap-1 mb-1">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          সবচেয়ে শক্তিশালী বিপরীত যুক্তি / ঝুঁকি (Counter-Argument)
                        </span>
                        <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                          {explanation.counter}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 4. Sub-Tab 2: BACKTEST VIEW */}
      {subTab === 'backtest' && (
        <div className="space-y-6">
          {backtestError && (
            <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-600 dark:text-rose-400 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">ব্যাকটেস্ট ত্রুটি</p>
                <p className="text-xs mt-0.5">{backtestError}</p>
              </div>
            </div>
          )}

          {!backtestResult && !isBacktesting && (
            <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-purple-500/10 text-purple-600 dark:text-purple-400 flex items-center justify-center mb-4">
                <BarChart2 className="w-7 h-7" />
              </div>
              <h2 className="text-base font-bold text-slate-800 dark:text-slate-200">
                ওয়াক-ফরওয়ার্ড ব্যাকটেস্টিং
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-lg mx-auto mt-1.5 mb-5">
                অ্যালগরিদমের আসল কার্যকারিতা পরিমাপ করতে OTCharts-এর সাম্প্রতিক বন্ধ ক্যান্ডেলগুলোর ওপর ওয়াক-ফরওয়ার্ড টেস্ট চালানো হয়। ডেটাটিকে ৭০% ডেভেলপমেন্ট সেট ও ৩০% আউট-অব-স্যাম্পল ভ্যালিডেশন সেটে ভাগ করা হবে।
              </p>
              <button
                type="button"
                onClick={handleRunBacktest}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-purple-600 text-white hover:bg-purple-500 shadow-sm transition-all inline-flex items-center gap-2"
              >
                <BarChart2 className="w-4 h-4" />
                ব্যাকটেস্ট শুরু করুন
              </button>
            </div>
          )}

          {backtestResult && (
            <div className="space-y-6">
              {/* Overall Summary Card */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                        {backtestResult.symbol} ({backtestResult.tf}s) ব্যাকটেস্ট ফলাফল
                      </h2>
                      {backtestResult.development.totalSignals + backtestResult.outOfSample.totalSignals < 30 && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
                          ⚠️ কম স্যাম্পল (n &lt; ৩০)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      মোট প্রাপ্ত ক্যান্ডেল: {backtestResult.totalCandlesReceived}টি | কার্যকর পরীক্ষিত সিগন্যাল:{' '}
                      {backtestResult.development.totalSignals + backtestResult.outOfSample.totalSignals}টি
                    </p>
                  </div>

                  <div className="text-left sm:text-right">
                    <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
                      সামগ্রিক উইন রেট (Overall Win Rate)
                    </span>
                    <span className="text-2xl font-black text-blue-600 dark:text-blue-400 font-mono">
                      {backtestResult.overallWinRate !== null ? `${backtestResult.overallWinRate}%` : 'N/A'}
                    </span>
                  </div>
                </div>

                {/* Break-even Note as explicitly requested */}
                <div className="mt-4 p-3 rounded-xl bg-blue-500/5 border border-blue-500/20 text-xs text-blue-600 dark:text-blue-400 flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 shrink-0" />
                  <span>
                    <b>ব্রেক-ইভেন মানদণ্ড:</b> বাইনারি অপশনে ৮০-৮৫% পেআউটের জন্য দীর্ঘমেয়াদী লাভজনকতার ক্ষেত্রে ব্রেক-ইভেন উইন রেট আনুমানিক <b>৫৭% - ৫৯%</b>।
                  </span>
                </div>

                {/* 70% Dev vs 30% OOS Comparative Cards */}
                <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Development (70%) */}
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-700/60">
                      <div>
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                          {backtestResult.development.name}
                        </span>
                        <span className="text-[11px] text-slate-500">ইন-স্যাম্পল ট্রেনিং ও ফিল্টারিং</span>
                      </div>
                      <span className="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400">
                        {backtestResult.development.winRate !== null
                          ? `${backtestResult.development.winRate}%`
                          : 'N/A'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 mt-3 text-center text-xs">
                      <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] block">সঠিক (Win)</span>
                        <b className="text-emerald-500">{backtestResult.development.correctCount}</b>
                      </div>
                      <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] block">ভুল (Loss)</span>
                        <b className="text-rose-500">{backtestResult.development.wrongCount}</b>
                      </div>
                      <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 text-[10px] block">ড্র (Draw)</span>
                        <b className="text-amber-500">{backtestResult.development.drawCount}</b>
                      </div>
                    </div>
                  </div>

                  {/* Out-of-Sample (30%) */}
                  <div className="p-4 rounded-xl bg-purple-500/5 border border-purple-500/20">
                    <div className="flex items-center justify-between pb-3 border-b border-purple-500/20">
                      <div>
                        <span className="text-xs font-bold text-purple-700 dark:text-purple-300 block">
                          {backtestResult.outOfSample.name}
                        </span>
                        <span className="text-[11px] text-purple-500/80">অদেখা ডেটায় বাস্তব ভ্যালিডেশন</span>
                      </div>
                      <span className="text-lg font-bold font-mono text-purple-600 dark:text-purple-400">
                        {backtestResult.outOfSample.winRate !== null
                          ? `${backtestResult.outOfSample.winRate}%`
                          : 'N/A'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 mt-3 text-center text-xs">
                      <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-purple-500/20">
                        <span className="text-slate-400 text-[10px] block">সঠিক (Win)</span>
                        <b className="text-emerald-500">{backtestResult.outOfSample.correctCount}</b>
                      </div>
                      <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-purple-500/20">
                        <span className="text-slate-400 text-[10px] block">ভুল (Loss)</span>
                        <b className="text-rose-500">{backtestResult.outOfSample.wrongCount}</b>
                      </div>
                      <div className="p-2 rounded-lg bg-white dark:bg-slate-900 border border-purple-500/20">
                        <span className="text-slate-400 text-[10px] block">ড্র (Draw)</span>
                        <b className="text-amber-500">{backtestResult.outOfSample.drawCount}</b>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Subgroup Breakdowns for Out-of-Sample */}
                <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
                  <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider mb-3">
                    আউট-অব-স্যাম্পল গ্রুপ ব্রেকডাউন (Subgroup Performance)
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* By Confidence */}
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                        ১. আত্মবিশ্বাস স্তর অনুযায়ী
                      </span>
                      <div className="space-y-1.5 text-xs">
                        {backtestResult.outOfSample.byConfidence.map((g) => (
                          <div key={g.label} className="flex items-center justify-between py-1 border-b border-slate-200/50 dark:border-slate-700/40">
                            <span className="font-semibold">{g.label} ({g.total}টি)</span>
                            <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                              {g.winRate !== null ? `${g.winRate}% (${g.correct}W / ${g.wrong}L)` : 'ডেটা নেই'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* By Direction */}
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                        ২. ডিরেকশন অনুযায়ী (UP / DOWN)
                      </span>
                      <div className="space-y-1.5 text-xs">
                        {backtestResult.outOfSample.byDirection.map((g) => (
                          <div key={g.label} className="flex items-center justify-between py-1 border-b border-slate-200/50 dark:border-slate-700/40">
                            <span className="font-semibold">{g.label} ({g.total}টি)</span>
                            <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                              {g.winRate !== null ? `${g.winRate}% (${g.correct}W / ${g.wrong}L)` : 'ডেটা নেই'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* By Agreement */}
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                        ৩. ভোটের সম্মতি স্তর (Agreement Count)
                      </span>
                      <div className="space-y-1.5 text-xs">
                        {backtestResult.outOfSample.byAgreement.map((g) => (
                          <div key={g.label} className="flex items-center justify-between py-1 border-b border-slate-200/50 dark:border-slate-700/40">
                            <span className="font-semibold">{g.label} ({g.total}টি)</span>
                            <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                              {g.winRate !== null ? `${g.winRate}% (${g.correct}W / ${g.wrong}L)` : 'ডেটা নেই'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* By Trend Alignment */}
                    <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                        ৪. ট্রেন্ড সারিবদ্ধতা
                      </span>
                      <div className="space-y-1.5 text-xs">
                        {backtestResult.outOfSample.byTrendAlignment.map((g) => (
                          <div key={g.label} className="flex items-center justify-between py-1 border-b border-slate-200/50 dark:border-slate-700/40">
                            <span className="font-semibold">{g.label} ({g.total}টি)</span>
                            <span className="font-mono font-bold text-blue-600 dark:text-blue-400">
                              {g.winRate !== null ? `${g.winRate}% (${g.correct}W / ${g.wrong}L)` : 'ডেটা নেই'}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 5. Sub-Tab 3: LIVE HISTORY VIEW */}
      {subTab === 'history' && (
        <div className="space-y-6">
          {historyNotice && (
            <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-600 dark:text-blue-400 text-xs flex items-center justify-between">
              <span>{historyNotice}</span>
              <button
                type="button"
                onClick={() => setHistoryNotice(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                ✕
              </button>
            </div>
          )}

          {/* History Statistics Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block font-medium">মোট সিগন্যাল</span>
              <span className="text-xl font-black text-slate-900 dark:text-slate-100 font-mono">
                {totalSignals}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 block font-medium">সঠিক (Win)</span>
              <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono">
                {correctSignals}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-[11px] text-rose-600 dark:text-rose-400 block font-medium">ভুল (Loss)</span>
              <span className="text-xl font-black text-rose-600 dark:text-rose-400 font-mono">
                {wrongSignals}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-[11px] text-amber-600 dark:text-amber-400 block font-medium">ড্র (Draw)</span>
              <span className="text-xl font-black text-amber-600 dark:text-amber-400 font-mono">
                {drawSignals}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-[11px] text-blue-600 dark:text-blue-400 block font-medium">পেন্ডিং</span>
              <span className="text-xl font-black text-blue-600 dark:text-blue-400 font-mono">
                {pendingSignals}
              </span>
            </div>

            <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center">
              <span className="text-[11px] text-purple-600 dark:text-purple-400 block font-medium">উইন রেট</span>
              <span className="text-xl font-black text-purple-600 dark:text-purple-400 font-mono">
                {liveWinRate !== null ? `${liveWinRate}%` : 'N/A'}
              </span>
            </div>
          </div>

          {/* Action Header */}
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              সংরক্ষিত লাইভ সিগন্যাল তালিকা
            </h3>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleAutoVerifyHistory}
                disabled={isVerifyingHistory || pendingSignals === 0}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 text-white hover:bg-emerald-500 disabled:opacity-50 flex items-center gap-1.5 transition-all"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                ফলাফল যাচাই করুন
              </button>
              {totalSignals > 0 && (
                <button
                  type="button"
                  onClick={handleClearHistory}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-500 hover:bg-rose-500/10 border border-rose-500/20 flex items-center gap-1 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  ইতিহাস পরিষ্কার
                </button>
              )}
            </div>
          </div>

          {/* Record List */}
          {historyRecords.length === 0 ? (
            <div className="p-12 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl">
              <Clock className="w-8 h-8 mx-auto text-slate-400 mb-2" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">কোনো লাইভ ইতিহাস নেই</p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                "সিগন্যাল" ট্যাবে গিয়ে নতুন সিগন্যাল বিশ্লেষণ করলে তা এখানে সংরক্ষিত হবে।
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {historyRecords.map((record) => {
                const isExpanded = expandedRecordId === record.id;
                const sig = record.signal;

                return (
                  <div
                    key={record.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs transition-all"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        {/* Direction Badge */}
                        <div
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 ${
                            sig.direction === 'UP'
                              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                              : sig.direction === 'DOWN'
                              ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                              : 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                          }`}
                        >
                          {sig.direction === 'UP' && <TrendingUp className="w-3.5 h-3.5" />}
                          {sig.direction === 'DOWN' && <TrendingDown className="w-3.5 h-3.5" />}
                          {sig.direction === 'NO TRADE' && <ShieldAlert className="w-3.5 h-3.5" />}
                          <span>{sig.direction}</span>
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                              {record.symbol}
                            </span>
                            <span className="text-[11px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-mono">
                              {record.tf}s
                            </span>
                            <span className="text-xs text-slate-400">
                              {new Date(record.createdAt).toLocaleTimeString('bn-BD', {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                            <span>কনফিডেন্স: <b>{sig.confidence}</b></span>
                            <span>•</span>
                            <span>টার্গেট ক্লোজ: <b>{formatTime(record.targetCloseTime)}</b></span>
                          </div>
                        </div>
                      </div>

                      {/* Outcome Controls */}
                      <div className="flex items-center gap-2">
                        {record.outcome === 'CORRECT' && (
                          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            WIN
                          </span>
                        )}

                        {record.outcome === 'WRONG' && (
                          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 border border-rose-500/30 flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" />
                            LOSS
                          </span>
                        )}

                        {record.outcome === 'DRAW' && (
                          <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
                            DRAW
                          </span>
                        )}

                        {record.outcome === 'PENDING' && (
                          <div className="flex items-center gap-1">
                            <span className="px-2 py-1 rounded-lg text-xs font-semibold bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center gap-1">
                              <Clock className="w-3 h-3 animate-spin" />
                              পেন্ডিং
                            </span>

                            {/* Manual quick buttons if user wants */}
                            <button
                              type="button"
                              onClick={() => handleManualOutcome(record.id, 'CORRECT')}
                              className="px-2 py-1 text-[11px] rounded bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 font-bold"
                            >
                              জিত
                            </button>
                            <button
                              type="button"
                              onClick={() => handleManualOutcome(record.id, 'WRONG')}
                              className="px-2 py-1 text-[11px] rounded bg-rose-500/10 text-rose-600 hover:bg-rose-500/20 font-bold"
                            >
                              হার
                            </button>
                          </div>
                        )}

                        {record.outcome === 'NOT_APPLICABLE' && (
                          <span className="px-2 py-0.5 rounded text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-400">
                            ট্রেড প্রযোজ্য নয়
                          </span>
                        )}

                        {/* Collapsible toggle */}
                        <button
                          type="button"
                          onClick={() => setExpandedRecordId(isExpanded ? null : record.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                        >
                          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                        </button>

                        {/* Delete button */}
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(record.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Collapsible Details */}
                    {isExpanded && (
                      <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/80 text-xs space-y-2.5">
                        <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40">
                          <span className="font-semibold block mb-1 text-slate-700 dark:text-slate-300">
                            ভোট ও কারণ:
                          </span>
                          <ul className="space-y-0.5 text-slate-600 dark:text-slate-400">
                            {sig.votesReasoning.map((r, i) => (
                              <li key={i}>{r}</li>
                            ))}
                          </ul>
                        </div>

                        {record.resolvedOpenPrice !== undefined && record.resolvedClosePrice !== undefined && (
                          <div className="p-2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono text-[11px] flex justify-between">
                            <span>টার্গেট ক্যান্ডেল ওপেন: {record.resolvedOpenPrice}</span>
                            <span>টার্গেট ক্যান্ডেল ক্লোজ: {record.resolvedClosePrice}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
