import React, { useState, useRef, useEffect } from 'react';
import {
  Upload,
  Camera,
  X,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Clock,
  CheckCircle2,
  Maximize2,
  Minimize2,
  FileQuestion,
  Layers,
  Activity,
  ShieldAlert,
  Search,
  Scale,
} from 'lucide-react';
import { AnalysisResult, HistoryRecord } from '../types';
import { createThumbnail, saveHistoryRecord, compressImage } from '../utils/storage';

interface AnalyzeViewProps {
  onRecordSaved: (record: HistoryRecord) => void;
  history?: HistoryRecord[];
}

export const AnalyzeView: React.FC<AnalyzeViewProps> = ({ onRecordSaved, history = [] }) => {
  // Primary (Entry chart)
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  // Higher Timeframe (Optional)
  const [higherTfFile, setHigherTfFile] = useState<File | null>(null);
  const [higherTfPreviewUrl, setHigherTfPreviewUrl] = useState<string | null>(null);

  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [progressText, setProgressText] = useState<string>('');
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [resultTimestamp, setResultTimestamp] = useState<number | null>(null);
  const [savedSuccessMessage, setSavedSuccessMessage] = useState<string | null>(null);
  const [isImageExpanded, setIsImageExpanded] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const higherTfFileInputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const handleFileChange = (file: File | undefined) => {
    if (!file) return;

    setError(null);
    setResult(null);
    setSavedSuccessMessage(null);

    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError('অনুগ্রহ করে JPEG, PNG বা WebP ফরম্যাটে ছবি আপলোড করুন।');
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      setError('ছবির আকার ২০ মেগাবাইট সীমা অতিক্রম করেছে। অনুগ্রহ করে ছোট স্ক্রিনশট নির্বাচন করুন।');
      return;
    }

    setSelectedFile(file);

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setPreviewUrl(dataUrl);
    };
    reader.onerror = () => {
      setError('ছবির ফাইলটি পড়া সম্ভব হয়নি।');
    };
    reader.readAsDataURL(file);
  };

  const handleHigherTfFileChange = (file: File | undefined) => {
    if (!file) return;

    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setError('বড় চার্টের জন্য JPEG, PNG বা WebP ফরম্যাটে ছবি দিন।');
      return;
    }

    if (file.size > 20 * 1024 * 1024) {
      setError('বড় চার্টের আকার ২০ মেগাবাইট সীমা অতিক্রম করেছে।');
      return;
    }

    setHigherTfFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setHigherTfPreviewUrl(dataUrl);
    };
    reader.onerror = () => {
      setError('বড় চার্টের ফাইলটি পড়া সম্ভব হয়নি।');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setError(null);
    setResult(null);
    setSavedSuccessMessage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const handleRemoveHigherTfImage = () => {
    setHigherTfFile(null);
    setHigherTfPreviewUrl(null);
    if (higherTfFileInputRef.current) higherTfFileInputRef.current.value = '';
  };

  const runAnalysis = async () => {
    if (!previewUrl || !selectedFile || isAnalyzing) return;

    setIsAnalyzing(true);
    setError(null);
    setResult(null);
    setSavedSuccessMessage(null);
    setElapsedSeconds(0);
    setProgressText('ছবি কমপ্রেস করে ভিশন মডেলের জন্য প্রস্তুত হচ্ছে...');

    const progressSteps = [
      'ছবি কমপ্রেস করে ভিশন মডেলের জন্য প্রস্তুত হচ্ছে...',
      'ক্যান্ডেলস্টিক গঠন ও উইক রিজেকশন পরীক্ষা করা হচ্ছে...',
      'চলতি ট্রেন্ড ও সাপোর্ট/রেজিস্ট্যান্স শনাক্ত করা হচ্ছে...',
      'মাল্টি-ফ্যাক্টর কনফ্লুয়েন্স ভোট মূল্যায়ন করা হচ্ছে...',
      'উল্টো পক্ষের যুক্তি যাচাই করা হচ্ছে (আত্ম-পর্যালোচনা)...',
      'সতর্ক টেকনিক্যাল বিশ্লেষণ প্রস্তুত করা হচ্ছে...',
    ];

    let currentStep = 0;
    timerRef.current = setInterval(() => {
      setElapsedSeconds((prev) => {
        const next = prev + 1;
        if (next % 4 === 0 && currentStep < progressSteps.length - 1) {
          currentStep += 1;
          setProgressText(progressSteps[currentStep]);
        }
        return next;
      });
    }, 1000);

    try {
      // Compress both images client-side before sending to prevent exceeding payload/storage limits
      const compressedEntry = await compressImage(previewUrl, 1400, 0.85);
      let compressedHtf: string | null = null;
      if (higherTfPreviewUrl) {
        compressedHtf = await compressImage(higherTfPreviewUrl, 1400, 0.85);
      }

      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({
          imageBase64: compressedEntry,
          mimeType: 'image/jpeg',
          higherTfImageBase64: compressedHtf || undefined,
          higherTfMimeType: compressedHtf ? 'image/jpeg' : undefined,
        }),
      });

      const rawText = await response.text();
      let data: any = null;
      try {
        data = JSON.parse(rawText);
      } catch {
        if (!response.ok) {
          throw new Error(
            `বিশ্লেষণ অনুরোধ ব্যর্থ হয়েছে (HTTP ${response.status}: ${response.statusText || 'Error'})। অনুগ্রহ করে আবার চেষ্টা করুন।`
          );
        }
        if (rawText.trim().startsWith('<')) {
          throw new Error('সার্ভার পুনরায় চালু হচ্ছে বা লোড নিচ্ছে। অনুগ্রহ করে কয়েক সেকেন্ড অপেক্ষা করে আবার চেষ্টা করুন।');
        }
        throw new Error('বিশ্লেষণ পরিষেবা অনুরোধটি সম্পন্ন করতে পারেনি। অনুগ্রহ করে স্পষ্ট চার্ট স্ক্রিনশট দিয়ে আবার চেষ্টা করুন।');
      }

      if (!response.ok || !data?.success) {
        let errorMsg = data?.error || 'চার্ট স্ক্রিনশট বিশ্লেষণ ব্যর্থ হয়েছে।';
        if (typeof errorMsg === 'string' && (errorMsg.includes('quota') || errorMsg.includes('429') || errorMsg.includes('RESOURCE_EXHAUSTED'))) {
          errorMsg = 'Gemini API দৈনিক কোটা সীমা শেষ হয়েছে। অনুগ্রহ করে পরে চেষ্টা করুন বা আপনার API কি চেক করুন।';
        }
        throw new Error(errorMsg);
      }

      const analysisData: AnalysisResult = data.analysis;
      const timestamp: number = data.timestamp || Date.now();

      setResult(analysisData);
      setResultTimestamp(timestamp);

      // Create thumbnails and save to IndexedDB
      try {
        const entryThumbnail = await createThumbnail(compressedEntry, 320);
        let htfThumbnail: string | undefined = undefined;
        if (compressedHtf) {
          htfThumbnail = await createThumbnail(compressedHtf, 320);
        }

        const recordId = typeof crypto !== 'undefined' && crypto.randomUUID
          ? crypto.randomUUID()
          : `analysis_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

        const newRecord: HistoryRecord = {
          id: recordId,
          timestamp,
          imageDataUrl: compressedEntry,
          thumbnailDataUrl: entryThumbnail,
          analysis: analysisData,
          outcome: 'PENDING',
          higherTfImageDataUrl: compressedHtf || undefined,
          higherTfThumbnailDataUrl: htfThumbnail || undefined,
        };

        await saveHistoryRecord(newRecord);
        onRecordSaved(newRecord);
        setSavedSuccessMessage('বিশ্লেষণ স্থানীয় ইতিহাসে সংরক্ষিত হয়েছে।');
      } catch (saveErr: any) {
        console.warn('Storage warning:', saveErr);
        setSavedSuccessMessage(
          'বিশ্লেষণ সম্পন্ন হয়েছে, তবে ডিভাইসের স্টোরেজে সংরক্ষণ করা যায়নি।'
        );
      }
    } catch (err: any) {
      console.error('Analysis request error:', err);
      setError(
        err?.message ||
          'বিশ্লেষণ ইঞ্জিনের সাথে সংযোগ করা যায়নি। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করে পুনরায় চেষ্টা করুন।'
      );
    } finally {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      setIsAnalyzing(false);
      setProgressText('');
    }
  };

  const formatTrend = (trend?: string) => {
    switch (trend) {
      case 'UPTREND':
        return 'ঊর্ধ্বমুখী (UPTREND)';
      case 'DOWNTREND':
        return 'নিম্নমুখী (DOWNTREND)';
      case 'SIDEWAYS':
        return 'পার্শ্বমুখী (SIDEWAYS)';
      case 'UNCLEAR':
      default:
        return 'অস্পষ্ট (UNCLEAR)';
    }
  };

  const formatQuality = (quality?: string) => {
    switch (quality) {
      case 'GOOD':
        return 'ভালো (GOOD)';
      case 'LIMITED':
        return 'সীমিত (LIMITED)';
      case 'POOR':
        return 'ত্রুটিপূর্ণ / অস্পষ্ট (POOR)';
      default:
        return quality || 'সীমিত';
    }
  };

  const getVoteBadge = (vote?: string) => {
    if (vote === 'UP') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-400">
          <TrendingUp className="w-3 h-3" /> UP
        </span>
      );
    }
    if (vote === 'DOWN') {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-rose-500/15 text-rose-700 dark:text-rose-400">
          <TrendingDown className="w-3 h-3" /> DOWN
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
        NEUTRAL
      </span>
    );
  };

  const getConfluenceSummary = (res: AnalysisResult) => {
    const list = [
      res.trend_vote,
      res.pattern_vote,
      res.sr_vote,
      res.htf_vote,
      res.indicator_vote,
    ].filter((v): v is 'UP' | 'DOWN' | 'NEUTRAL' => Boolean(v));

    const N = list.length;
    const threshold = Math.ceil((2 / 3) * N);
    const upVotes = list.filter((v) => v === 'UP').length;
    const downVotes = list.filter((v) => v === 'DOWN').length;

    if (upVotes >= threshold) {
      return `${N}টির মধ্যে ${upVotes}টি ভোট UP-এর পক্ষে একমত (কনফ্লুয়েন্স অর্জিত)`;
    }
    if (downVotes >= threshold) {
      return `${N}টির মধ্যে ${downVotes}টি ভোট DOWN-এর পক্ষে একমত (কনফ্লুয়েন্স অর্জিত)`;
    }
    return `পর্যাপ্ত কনফ্লুয়েন্স নেই (${N}টিতে ${Math.max(upVotes, downVotes)}/${threshold} ভোট) -> NO TRADE`;
  };

  // UPDATE 6: Historical advisory check
  const getHistoricalAdvisory = () => {
    if (!result || !history || history.length === 0) return null;

    const verifiedRecords = history.filter(
      (h) =>
        (h.outcome === 'CORRECT' || h.outcome === 'WRONG') &&
        (h.analysis.direction === 'UP' || h.analysis.direction === 'DOWN')
    );

    if (verifiedRecords.length === 0) return null;

    const warnings: string[] = [];

    // 1. Timeframe
    if (result.timeframe && result.timeframe !== 'UNKNOWN') {
      const tfRecords = verifiedRecords.filter((h) => h.analysis.timeframe === result.timeframe);
      if (tfRecords.length >= 10) {
        const correct = tfRecords.filter((h) => h.outcome === 'CORRECT').length;
        const rate = Math.round((correct / tfRecords.length) * 100);
        if (rate < 50) {
          warnings.push(`টাইমফ্রেম ${result.timeframe}-এ সঠিকতার হার কম (${rate}%, ${tfRecords.length}টির মধ্যে)`);
        }
      }
    }

    // 2. Confidence
    if (result.confidence_label) {
      const confRecords = verifiedRecords.filter(
        (h) => h.analysis.confidence_label === result.confidence_label
      );
      if (confRecords.length >= 10) {
        const correct = confRecords.filter((h) => h.outcome === 'CORRECT').length;
        const rate = Math.round((correct / confRecords.length) * 100);
        if (rate < 50) {
          warnings.push(`আস্থা স্তর ${result.confidence_label}-এ সঠিকতার হার কম (${rate}%, ${confRecords.length}টির মধ্যে)`);
        }
      }
    }

    // 3. Direction
    if (result.direction === 'UP' || result.direction === 'DOWN') {
      const dirRecords = verifiedRecords.filter((h) => h.analysis.direction === result.direction);
      if (dirRecords.length >= 10) {
        const correct = dirRecords.filter((h) => h.outcome === 'CORRECT').length;
        const rate = Math.round((correct / dirRecords.length) * 100);
        if (rate < 50) {
          warnings.push(`দিক ${result.direction}-এ সঠিকতার হার কম (${rate}%, ${dirRecords.length}টির মধ্যে)`);
        }
      }
    }

    // 4. Market condition
    if (result.market_condition) {
      const mktRecords = verifiedRecords.filter(
        (h) => h.analysis.market_condition === result.market_condition
      );
      if (mktRecords.length >= 10) {
        const correct = mktRecords.filter((h) => h.outcome === 'CORRECT').length;
        const rate = Math.round((correct / mktRecords.length) * 100);
        if (rate < 50) {
          warnings.push(`বাজার অবস্থা ${result.market_condition}-এ সঠিকতার হার কম (${rate}%, ${mktRecords.length}টির মধ্যে)`);
        }
      }
    }

    return warnings.length > 0 ? warnings : null;
  };

  const historicalWarnings = getHistoricalAdvisory();

  return (
    <div className="w-full max-w-2xl mx-auto pb-24 pt-4 px-4 sm:px-6 space-y-4">
      {/* Upload & Preview Card */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs transition-colors">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-slate-900 dark:text-slate-100">
            ক্যান্ডেলস্টিক চার্ট বিশ্লেষণ
          </h2>
          {previewUrl && !isAnalyzing && (
            <button
              type="button"
              onClick={handleRemoveImage}
              className="text-xs font-medium text-slate-500 hover:text-rose-600 dark:text-slate-400 dark:hover:text-rose-400 transition-colors flex items-center gap-1 min-h-[36px] px-2"
            >
              <X className="w-3.5 h-3.5" />
              মুছে ফেলুন
            </button>
          )}
        </div>

        {/* Slot A: Entry Chart (Mandatory) */}
        <div className="space-y-2 mb-4">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
            <span>(ক) এন্ট্রি চার্ট (ছোট টাইমফ্রেম) <span className="text-rose-500">*বাধ্যতামূলক</span></span>
          </label>

          {!previewUrl ? (
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                  handleFileChange(e.dataTransfer.files[0]);
                }
              }}
              className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 rounded-xl p-6 text-center transition-colors bg-slate-50/50 dark:bg-slate-950/40"
            >
              <div className="mx-auto w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-2">
                <Upload className="w-5 h-5" />
              </div>
              <p className="text-xs font-medium text-slate-800 dark:text-slate-200 mb-0.5">
                এন্ট্রি চার্ট নির্বাচন বা ড্রপ করুন
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                JPEG, PNG, WebP (সর্বোচ্চ ২০ মেগাবাইট)
              </p>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  className="hidden"
                  onChange={(e) => handleFileChange(e.target.files?.[0])}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="min-h-[40px] px-3.5 py-1.5 text-xs font-medium bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 rounded-lg hover:bg-slate-800 dark:hover:bg-white transition-colors flex items-center gap-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                >
                  <Upload className="w-3.5 h-3.5" />
                  ছবি নির্বাচন করুন
                </button>

                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => handleFileChange(e.target.files?.[0])}
                />
                <button
                  type="button"
                  onClick={() => cameraInputRef.current?.click()}
                  className="min-h-[40px] px-3.5 py-1.5 text-xs font-medium border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                >
                  <Camera className="w-3.5 h-3.5" />
                  ছবি তুলুন
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="relative rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-950 flex items-center justify-center group">
                <img
                  src={previewUrl}
                  alt="এন্ট্রি চার্ট"
                  className={`w-full object-contain transition-all duration-200 ${
                    isImageExpanded ? 'max-h-[500px]' : 'max-h-60'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setIsImageExpanded(!isImageExpanded)}
                  aria-label={isImageExpanded ? 'প্রিভিউ ছোট করুন' : 'প্রিভিউ বড় করুন'}
                  className="absolute top-2 right-2 min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg bg-black/60 text-white hover:bg-black/80 transition-colors backdrop-blur-xs"
                >
                  {isImageExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              </div>

              {!isAnalyzing && (
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="truncate max-w-[200px]">{selectedFile?.name}</span>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="text-emerald-600 dark:text-emerald-400 hover:underline font-medium min-h-[32px] flex items-center"
                  >
                    ছবি পরিবর্তন করুন
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Slot B: Higher Timeframe Chart (Optional - Update 1) */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 block">
                (খ) বড় টাইমফ্রেম চার্ট <span className="text-slate-400 font-normal">(ঐচ্ছিক)</span>
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 block">
                বড় টাইমফ্রেমের মূল ট্রেন্ড ও প্রধান S/R কনফ্লুয়েন্সের জন্য
              </span>
            </div>

            {higherTfPreviewUrl && !isAnalyzing && (
              <button
                type="button"
                onClick={handleRemoveHigherTfImage}
                className="text-xs text-rose-600 dark:text-rose-400 hover:underline min-h-[32px] flex items-center gap-1"
              >
                <X className="w-3.5 h-3.5" />
                সরান
              </button>
            )}
          </div>

          {!higherTfPreviewUrl ? (
            <div>
              <input
                ref={higherTfFileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp"
                className="hidden"
                onChange={(e) => handleHigherTfFileChange(e.target.files?.[0])}
              />
              <button
                type="button"
                onClick={() => higherTfFileInputRef.current?.click()}
                className="w-full min-h-[40px] px-3 py-2 text-xs font-medium border border-dashed border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded-lg hover:bg-white dark:hover:bg-slate-900 transition-colors flex items-center justify-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5 text-slate-400" />
                <span>বড় চার্ট নির্বাচন করুন (ঐচ্ছিক)</span>
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-3 bg-white dark:bg-slate-900 p-2 rounded-lg border border-slate-200 dark:border-slate-800">
              <div className="w-16 h-12 rounded overflow-hidden bg-slate-950 shrink-0 border border-slate-200 dark:border-slate-800">
                <img
                  src={higherTfPreviewUrl}
                  alt="বড় চার্ট থাম্বনেইল"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0 text-xs">
                <p className="font-medium text-slate-800 dark:text-slate-200 truncate">
                  {higherTfFile?.name}
                </p>
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400">
                  যুক্ত হয়েছে (মাল্টি-টাইমফ্রেম চালু)
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Primary Action Button */}
        {previewUrl && (
          <div className="mt-4">
            <button
              type="button"
              disabled={isAnalyzing}
              onClick={runAnalysis}
              className="w-full min-h-[48px] py-3 px-4 rounded-xl font-medium text-sm text-white bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed disabled:active:scale-100 transition-all flex items-center justify-center gap-2 shadow-xs focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>বিশ্লেষণ চলছে... ({elapsedSeconds} সেকেন্ড)</span>
                </>
              ) : (
                <span>
                  {higherTfPreviewUrl ? 'উভয় চার্ট বিশ্লেষণ করুন (Multi-TF)' : 'স্ক্রিনশট বিশ্লেষণ করুন'}
                </span>
              )}
            </button>
          </div>
        )}
      </section>

      {/* Loading Progress State with Step 2 mention */}
      {isAnalyzing && (
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl text-center space-y-3 animate-in fade-in duration-200">
          <div className="inline-flex p-3 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
            <RefreshCw className="w-6 h-6 animate-spin" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              {progressText || 'বিশ্লেষণ চলছে...'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 tabular-nums">
              লক্ষ্য প্রতিক্রিয়া সময় ৩০ সেকেন্ডের মধ্যে · অতিবাহিত: {elapsedSeconds} সেকেন্ড
            </p>
          </div>
        </div>
      )}

      {/* Error Banner */}
      {error && !isAnalyzing && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/60 rounded-2xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-rose-800 dark:text-rose-200">
              বিশ্লেষণ বিজ্ঞপ্তি
            </p>
            <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5 leading-relaxed">
              {error}
            </p>
            {previewUrl && (
              <button
                type="button"
                onClick={runAnalysis}
                className="mt-2 text-xs font-semibold text-rose-800 dark:text-rose-200 underline hover:no-underline min-h-[36px] flex items-center"
              >
                পুনরায় চেষ্টা করুন
              </button>
            )}
          </div>
        </div>
      )}

      {/* Saved to History Notification */}
      {savedSuccessMessage && (
        <div className="px-4 py-2.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/50 rounded-xl text-xs text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
          <span>{savedSuccessMessage}</span>
        </div>
      )}

      {/* Analysis Results Display */}
      {result && !isAnalyzing && (
        <section className="space-y-4 animate-in fade-in duration-300">
          {/* UPDATE 6: Historical Advisory Warning if triggered */}
          {historicalWarnings && historicalWarnings.length > 0 && (
            <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/60 rounded-2xl flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1 text-xs">
                <span className="font-bold text-amber-900 dark:text-amber-200 block mb-1">
                  সতর্কতা: আপনার ইতিহাসে এই ধরনের বিশ্লেষণে সঠিকতা কম
                </span>
                <ul className="space-y-0.5 text-amber-800 dark:text-amber-300">
                  {historicalWarnings.map((w, i) => (
                    <li key={i} className="flex items-start gap-1">
                      <span>•</span>
                      <span>{w}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-1 text-[11px] text-amber-700 dark:text-amber-400 italic">
                  পরামর্শ: এই ট্রেডে অতিরিক্ত সতর্কতা অবলম্বন করুন বা এড়িয়ে চলুন।
                </p>
              </div>
            </div>
          )}

          {/* Main Direction Banner */}
          <div
            className={`p-5 rounded-2xl border transition-colors ${
              result.direction === 'UP'
                ? 'bg-emerald-500/10 border-emerald-500/30 dark:border-emerald-500/30'
                : result.direction === 'DOWN'
                ? 'bg-rose-500/10 border-rose-500/30 dark:border-rose-500/30'
                : 'bg-amber-500/10 border-amber-500/30 dark:border-amber-500/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 block mb-1">
                  পরবর্তী ক্যান্ডেলের পূর্বাভাস
                </span>
                <div className="flex items-center gap-2">
                  {result.direction === 'UP' && (
                    <TrendingUp className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
                  )}
                  {result.direction === 'DOWN' && (
                    <TrendingDown className="w-7 h-7 text-rose-600 dark:text-rose-400" />
                  )}
                  {result.direction === 'NO TRADE' && (
                    <FileQuestion className="w-7 h-7 text-amber-600 dark:text-amber-400" />
                  )}
                  <h3
                    className={`text-2xl font-bold tracking-tight ${
                      result.direction === 'UP'
                        ? 'text-emerald-700 dark:text-emerald-300'
                        : result.direction === 'DOWN'
                        ? 'text-rose-700 dark:text-rose-300'
                        : 'text-amber-700 dark:text-amber-300'
                    }`}
                  >
                    {result.direction}
                  </h3>
                </div>
              </div>

              {/* Confidence Tag & Market Condition */}
              <div className="text-right space-y-1">
                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-md inline-block ${
                    result.confidence_label === 'HIGH'
                      ? 'bg-emerald-500/20 text-emerald-800 dark:text-emerald-200'
                      : result.confidence_label === 'MODERATE'
                      ? 'bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200'
                      : 'bg-amber-500/20 text-amber-800 dark:text-amber-200'
                  }`}
                >
                  আস্থা: {result.confidence_label}
                </span>

                {/* Market Condition Tag */}
                {result.market_condition && (
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400">
                    বাজার: {result.market_condition === 'TRENDING' ? 'ট্রেন্ডিং' : result.market_condition === 'CHOPPY' ? 'এলোমেলো (CHOPPY)' : 'রেঞ্জিং'}
                  </div>
                )}
              </div>
            </div>

            {/* Explanation Summary */}
            <p className="mt-3 text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-normal">
              {result.summary}
            </p>

            {/* Confidence Disclaimer */}
            <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 italic">
              নোট: {result.confidence_note}
            </p>
          </div>

          {/* UPDATE 2: Self-Review & Counter-argument Card */}
          {(result.counter_argument || result.review_verdict) && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-2">
              <div className="flex items-center justify-between pb-1.5 border-b border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900 dark:text-slate-100">
                  <Scale className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                  <span>দ্বিতীয় ধাপ: আত্ম-পর্যালোচনা ও উল্টো যুক্তি</span>
                </div>
                {result.review_verdict && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      result.review_verdict === 'KEPT'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                        : result.review_verdict === 'DOWNGRADED'
                        ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                        : result.review_verdict === 'NO_TRADE'
                        ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    ফল: {result.review_verdict === 'KEPT' ? 'বহাল' : result.review_verdict === 'DOWNGRADED' ? 'আস্থা হ্রাস' : result.review_verdict === 'NO_TRADE' ? 'NO TRADE' : 'বাদ'}
                  </span>
                )}
              </div>

              {result.counter_argument && (
                <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pt-1">
                  <span className="font-semibold text-rose-600 dark:text-rose-400">উল্টো যুক্তি: </span>
                  <span>{result.counter_argument}</span>
                </div>
              )}
            </div>
          )}

          {/* Factor Votes Card (Confluence Rule) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900 dark:text-slate-100">
                <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>ফ্যাক্টর ভোট (Confluence নিয়ম)</span>
              </div>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                {getConfluenceSummary(result)}
              </span>
            </div>

            {/* Vote Chips Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {/* 1. Trend */}
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">১. ট্রেন্ড</span>
                <div>{getVoteBadge(result.trend_vote)}</div>
              </div>

              {/* 2. Pattern */}
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">২. প্যাটার্ন</span>
                <div>{getVoteBadge(result.pattern_vote)}</div>
              </div>

              {/* 3. S/R */}
              <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-700 dark:text-slate-300">৩. S/R লেভেল</span>
                <div>{getVoteBadge(result.sr_vote)}</div>
              </div>

              {/* 4. HTF (Optional) */}
              {result.htf_vote && (
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-700 dark:text-slate-300">৪. বড় টাইমফ্রেম</span>
                  <div>{getVoteBadge(result.htf_vote)}</div>
                </div>
              )}

              {/* 5. Indicators (Optional) */}
              {result.indicator_vote && (
                <div className="p-2 rounded-xl bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-700 dark:text-slate-300">৫. ইন্ডিকেটর</span>
                  <div>{getVoteBadge(result.indicator_vote)}</div>
                </div>
              )}
            </div>

            {/* Visible Indicators list if present */}
            {result.indicators_visible && result.indicators_visible.length > 0 && (
              <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800 text-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">
                  দৃশ্যমান ইন্ডিকেটর ও অবস্থা:
                </span>
                <ul className="space-y-0.5 text-slate-600 dark:text-slate-400">
                  {result.indicators_visible.map((ind, i) => (
                    <li key={i} className="flex items-center gap-1.5">
                      <Search className="w-3 h-3 text-slate-400" />
                      <span>{ind}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Votes Reasoning */}
            {result.votes_reasoning && result.votes_reasoning.length > 0 && (
              <div className="pt-1">
                <span className="text-[10px] uppercase font-semibold text-slate-400 block mb-1">
                  ভোটের কারণসমূহ:
                </span>
                <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
                  {result.votes_reasoning.map((r, i) => (
                    <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                      <span className="text-slate-400">·</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* UPDATE 4: Level Quality & Momentum Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200 pb-2 border-b border-slate-100 dark:border-slate-800">
              <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>লেভেলের গুণমান ও ক্যান্ডেল মোমেন্টাম</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2.5 text-xs">
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/80">
                <span className="text-[10px] text-slate-400 block">লেভেল স্পর্শ</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {result.level_touch_count || 'UNKNOWN'}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/80">
                <span className="text-[10px] text-slate-400 block">লেভেলের শক্তি</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {result.level_strength || 'UNKNOWN'}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/80">
                <span className="text-[10px] text-slate-400 block">মোমেন্টাম</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {result.momentum || 'UNKNOWN'}
                </span>
              </div>
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/80">
                <span className="text-[10px] text-slate-400 block">ব্রেকআউট অবস্থা</span>
                <span
                  className={`font-semibold ${
                    result.breakout_type === 'FAKE_SUSPECTED'
                      ? 'text-rose-600 dark:text-rose-400'
                      : 'text-slate-800 dark:text-slate-200'
                  }`}
                >
                  {result.breakout_type === 'FAKE_SUSPECTED' ? 'সন্দেহজনক ফেকআউট' : result.breakout_type || 'NONE'}
                </span>
              </div>
            </div>
          </div>

          {/* Observations & Evidence Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
            {/* Trend & Timeframe Row */}
            <div className="grid grid-cols-2 gap-3 pb-3 border-b border-slate-100 dark:border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 dark:text-slate-500 uppercase tracking-wider block text-[10px]">
                  দৃশ্যমান ট্রেন্ড
                </span>
                <span className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5 block">
                  {formatTrend(result.trend)}
                </span>
              </div>
              <div>
                <span className="text-slate-400 dark:text-slate-500 uppercase tracking-wider block text-[10px]">
                  চিহ্নিত টাইমফ্রেম
                </span>
                <span className="font-semibold text-slate-900 dark:text-slate-100 mt-0.5 block">
                  {result.timeframe}
                </span>
              </div>
            </div>

            {/* Observations */}
            {result.observations.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  দৃশ্যমান ক্যান্ডেলস্টিক পর্যবেক্ষণ
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  {result.observations.map((obs, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-slate-400 mt-1">·</span>
                      <span className="leading-relaxed">{obs}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Supporting vs Conflicting Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="bg-slate-50 dark:bg-slate-950/50 rounded-xl p-3 border border-slate-100 dark:border-slate-800/80">
                <h5 className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider mb-2">
                  পক্ষে প্রমাণ
                </h5>
                <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  {result.supporting_evidence.length > 0 ? (
                    result.supporting_evidence.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-500 mt-0.5">✓</span>
                        <span className="leading-relaxed">{item}</span>
                      </li>
                    ))
                  ) : (
                    <li className="text-slate-400 text-xs">কোনো জোরালো পক্ষের প্রমাণ দৃশ্যমান নয়।</li>
                  )}
                </ul>
              </div>

              <div className="bg-slate-50 dark:bg-slate-950/50 rounded-xl p-3 border border-slate-100 dark:border-slate-800/80">
                <h5 className="text-[11px] font-semibold text-rose-700 dark:text-rose-400 uppercase tracking-wider mb-2">
                  বিপক্ষে ঝুঁকি ও অনিশ্চয়তা
                </h5>
                <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                  {result.conflicting_evidence.length > 0 ? (
                    result.conflicting_evidence.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-rose-500 mt-0.5">!</span>
                        <span className="leading-relaxed">{item}</span>
                      </li>
                    ))
                  ) : (
                    <li className="text-slate-400 text-xs">কোনো বড় ধরনের বিপরীতমুখী সংকেত দেখা যায়নি।</li>
                  )}
                </ul>
              </div>
            </div>

            {/* Quality & Limitations */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span>
                  ছবির মান:{' '}
                  <strong className="text-slate-800 dark:text-slate-200">
                    {formatQuality(result.image_quality)}
                  </strong>
                </span>
                {resultTimestamp && (
                  <span className="flex items-center gap-1 tabular-nums">
                    <Clock className="w-3 h-3" />
                    {new Date(resultTimestamp).toLocaleTimeString('bn-BD', {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    })}
                  </span>
                )}
              </div>

              {result.limitations.length > 0 && (
                <div className="mt-2">
                  <span className="text-[10px] uppercase font-semibold text-slate-400 dark:text-slate-500 block mb-1">
                    সীমাবদ্ধতা ও সতর্কবার্তা
                  </span>
                  <ul className="space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
                    {result.limitations.map((lim, idx) => (
                      <li key={idx}>· {lim}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* Educational Disclaimer */}
          <div className="px-4 py-3 bg-slate-100/60 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl text-[11px] text-slate-500 dark:text-slate-400 leading-normal text-center">
            শুধুমাত্র চার্টের দৃশ্যমান পিক্সেল ও তথ্যের ভিত্তিতে তৈরি সম্ভাবনামূলক টেকনিক্যাল বিশ্লেষণ। এটি কোনো আর্থিক পরামর্শ, নিশ্চিত লাভ বা স্বয়ংক্রিয় ট্রেডিং নির্দেশনা নয়।
          </div>
        </section>
      )}
    </div>
  );
};
