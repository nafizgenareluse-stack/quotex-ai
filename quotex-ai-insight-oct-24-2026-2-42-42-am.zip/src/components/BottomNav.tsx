import React from 'react';
import { ScanLine, History, Activity } from 'lucide-react';
import { NavTab } from '../types';

interface BottomNavProps {
  currentTab: NavTab;
  onChangeTab: (tab: NavTab) => void;
  historyCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onChangeTab,
  historyCount = 0,
}) => {
  return (
    <nav
      aria-label="মূল নেভিগেশন"
      className="fixed bottom-0 left-0 right-0 z-30 border-t backdrop-blur-md transition-colors border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95"
    >
      <div className="max-w-2xl mx-auto px-6 h-16 grid grid-cols-3 items-center">
        {/* Tab 1: Analyze */}
        <button
          type="button"
          onClick={() => onChangeTab('analyze')}
          className={`min-h-[44px] flex flex-col items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg ${
            currentTab === 'analyze'
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <ScanLine className="w-5 h-5 mb-1" />
          <span className="text-xs tracking-tight whitespace-nowrap">বিশ্লেষণ</span>
        </button>

        {/* Tab 2: Live */}
        <button
          type="button"
          onClick={() => onChangeTab('live')}
          className={`min-h-[44px] flex flex-col items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg ${
            currentTab === 'live'
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <Activity className="w-5 h-5 mb-1" />
          <span className="text-xs tracking-tight whitespace-nowrap">লাইভ</span>
        </button>

        {/* Tab 3: History */}
        <button
          type="button"
          onClick={() => onChangeTab('history')}
          className={`min-h-[44px] flex flex-col items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg relative ${
            currentTab === 'history'
              ? 'text-emerald-600 dark:text-emerald-400 font-semibold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
          }`}
        >
          <div className="relative">
            <History className="w-5 h-5 mb-1" />
            {historyCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1.5 py-0.2 min-w-4 text-[10px] font-bold rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 tabular-nums text-center">
                {historyCount > 99 ? '99+' : historyCount}
              </span>
            )}
          </div>
          <span className="text-xs tracking-tight whitespace-nowrap">ইতিহাস</span>
        </button>
      </div>
    </nav>
  );
};
